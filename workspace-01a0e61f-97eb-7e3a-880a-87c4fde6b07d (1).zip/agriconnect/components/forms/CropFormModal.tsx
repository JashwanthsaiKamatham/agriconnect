"use client";

import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import { ImagePlus } from "lucide-react";
import Modal from "@/components/ui/Modal";
import Button from "@/components/ui/Button";
import { Field, Input, Select, Textarea } from "@/components/ui/Form";
import { useApp } from "@/lib/context/AppContext";
import { GROWTH_STAGES, type Crop, type GrowthStage, type IrrigationType, type SoilType } from "@/lib/types";
import { cropEmoji } from "@/lib/utils";

const SOILS: SoilType[] = ["Black", "Red", "Alluvial", "Sandy loam", "Loamy", "Laterite"];
const IRRIGATIONS: IrrigationType[] = ["Rain-fed", "Canal", "Borewell", "Drip", "Sprinkler", "Flood"];

export interface CropFormValues {
  name: string;
  variety: string;
  image?: string;
  area: number;
  areaUnit: "acres" | "hectares";
  plantingDate: string;
  harvestDate: string;
  stage: GrowthStage;
  irrigation: IrrigationType;
  soil: SoilType;
  estimatedYield: number;
  notes: string;
}

const EMPTY: CropFormValues = {
  name: "",
  variety: "",
  image: undefined,
  area: 1,
  areaUnit: "acres",
  plantingDate: "",
  harvestDate: "",
  stage: "Planned",
  irrigation: "Rain-fed",
  soil: "Black",
  estimatedYield: 0,
  notes: "",
};

type Errors = Partial<Record<keyof CropFormValues, string>>;

function validate(v: CropFormValues): Errors {
  const e: Errors = {};
  if (!v.name.trim()) e.name = "Crop name is required";
  if (!v.area || v.area <= 0) e.area = "Enter a land area greater than 0";
  if (!v.plantingDate) e.plantingDate = "Planting date is required";
  if (!v.harvestDate) e.harvestDate = "Expected harvest date is required";
  if (v.plantingDate && v.harvestDate && v.harvestDate <= v.plantingDate)
    e.harvestDate = "Harvest date must be after the planting date";
  if (v.estimatedYield < 0) e.estimatedYield = "Yield cannot be negative";
  return e;
}

export default function CropFormModal({
  open,
  onClose,
  editing,
}: {
  open: boolean;
  onClose: () => void;
  editing?: Crop | null;
}) {
  const { addCrop, updateCrop, toast } = useApp();
  const [values, setValues] = useState<CropFormValues>(EMPTY);
  const [errors, setErrors] = useState<Errors>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setValues(
        editing
          ? {
              name: editing.name,
              variety: editing.variety,
              image: editing.image,
              area: editing.area,
              areaUnit: editing.areaUnit,
              plantingDate: editing.plantingDate,
              harvestDate: editing.harvestDate,
              stage: editing.stage,
              irrigation: editing.irrigation,
              soil: editing.soil,
              estimatedYield: editing.estimatedYield,
              notes: editing.notes ?? "",
            }
          : EMPTY
      );
      setErrors({});
    }
  }, [open, editing]);

  const set = (key: keyof CropFormValues) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const val = e.target.value;
    setValues((v) => ({ ...v, [key]: key === "area" || key === "estimatedYield" ? Number(val) : val }));
    setErrors((er) => ({ ...er, [key]: "" }));
  };

  const onPhoto = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setValues((v) => ({ ...v, image: URL.createObjectURL(file) }));
    }
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const errs = validate(values);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    setSaving(true);
    await new Promise((r) => setTimeout(r, 650)); // simulate cropService.save
    if (editing) {
      updateCrop(editing.id, values);
      toast(`"${values.name}" updated successfully.`);
    } else {
      addCrop(values);
      toast(`"${values.name}" added to your farm.`);
    }
    setSaving(false);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide
      title={editing ? `Edit ${editing.name}` : "Add a new crop"}
      subtitle="All details can be updated anytime as the crop grows."
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button type="submit" form="crop-form" loading={saving}>
            {editing ? "Save changes" : "Add crop"}
          </Button>
        </div>
      }
    >
      <form id="crop-form" onSubmit={onSubmit} noValidate className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Crop name" htmlFor="crop-name" required error={errors.name}>
            <Input id="crop-name" value={values.name} onChange={set("name")} placeholder="e.g. Tomato, Paddy, Cotton" error={errors.name} />
          </Field>
          <Field label="Variety" htmlFor="crop-variety" hint={`Shown as ${cropEmoji(values.name || "x")} on your crop card`}>
            <Input id="crop-variety" value={values.variety} onChange={set("variety")} placeholder="e.g. Arka Rakshak" />
          </Field>
        </div>

        <Field label="Crop photo" htmlFor="crop-image">
          <div className="flex items-center gap-4">
            {values.image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={values.image} alt="Crop preview" className="h-20 w-28 rounded-xl border border-charcoal-100 object-cover" />
            ) : (
              <span className="flex h-20 w-28 items-center justify-center rounded-xl border-2 border-dashed border-charcoal-200 bg-beige-100 text-3xl">
                {cropEmoji(values.name || "seedling")}
              </span>
            )}
            <label className="focus-ring inline-flex cursor-pointer items-center gap-2 rounded-xl border border-charcoal-200 bg-white px-4 py-2.5 text-sm font-semibold text-charcoal-700 hover:border-forest-400 hover:text-forest-700">
              <ImagePlus className="h-4 w-4" aria-hidden />
              {values.image ? "Change photo" : "Upload photo"}
              <input id="crop-image" type="file" accept="image/*" className="sr-only" onChange={onPhoto} />
            </label>
          </div>
        </Field>

        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Land area" htmlFor="crop-area" required error={errors.area}>
            <Input id="crop-area" type="number" min="0" step="0.1" value={values.area} onChange={set("area")} error={errors.area} />
          </Field>
          <Field label="Unit" htmlFor="crop-unit">
            <Select id="crop-unit" value={values.areaUnit} onChange={set("areaUnit")}>
              <option value="acres">Acres</option>
              <option value="hectares">Hectares</option>
            </Select>
          </Field>
          <Field label="Estimated yield (tonnes)" htmlFor="crop-yield" error={errors.estimatedYield}>
            <Input id="crop-yield" type="number" min="0" step="0.1" value={values.estimatedYield} onChange={set("estimatedYield")} error={errors.estimatedYield} />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Planting date" htmlFor="crop-planting" required error={errors.plantingDate}>
            <Input id="crop-planting" type="date" value={values.plantingDate} onChange={set("plantingDate")} error={errors.plantingDate} />
          </Field>
          <Field label="Expected harvest date" htmlFor="crop-harvest" required error={errors.harvestDate}>
            <Input id="crop-harvest" type="date" value={values.harvestDate} onChange={set("harvestDate")} error={errors.harvestDate} />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Current growth stage" htmlFor="crop-stage">
            <Select id="crop-stage" value={values.stage} onChange={set("stage")}>
              {GROWTH_STAGES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Irrigation type" htmlFor="crop-irrigation">
            <Select id="crop-irrigation" value={values.irrigation} onChange={set("irrigation")}>
              {IRRIGATIONS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Soil type" htmlFor="crop-soil">
            <Select id="crop-soil" value={values.soil} onChange={set("soil")}>
              {SOILS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          </Field>
        </div>

        <Field label="Notes" htmlFor="crop-notes" hint="Fertilizer plans, pest sightings, reminders…">
          <Textarea id="crop-notes" value={values.notes} onChange={set("notes")} placeholder="e.g. Second urea split due next week" />
        </Field>
      </form>
    </Modal>
  );
}
