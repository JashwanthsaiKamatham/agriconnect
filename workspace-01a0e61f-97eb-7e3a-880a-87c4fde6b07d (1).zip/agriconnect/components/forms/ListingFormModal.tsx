"use client";

import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import { ImagePlus } from "lucide-react";
import Modal from "@/components/ui/Modal";
import Button from "@/components/ui/Button";
import { Field, Input, Select, Textarea } from "@/components/ui/Form";
import { useApp } from "@/lib/context/AppContext";
import { cropEmoji, formatINR } from "@/lib/utils";

export interface ListingFormValues {
  crop: string;
  variety: string;
  quantity: number;
  unit: string;
  price: number;
  grade: "A" | "B";
  organic: boolean;
  harvestDate: string;
  location: string;
  district: string;
  state: string;
  description: string;
  image?: string;
}

const EMPTY: ListingFormValues = {
  crop: "",
  variety: "",
  quantity: 0,
  unit: "quintals",
  price: 0,
  grade: "A",
  organic: false,
  harvestDate: "",
  location: "",
  district: "",
  state: "Andhra Pradesh",
  description: "",
  image: undefined,
};

type Errors = Partial<Record<keyof ListingFormValues, string>>;

function validate(v: ListingFormValues): Errors {
  const e: Errors = {};
  if (!v.crop.trim()) e.crop = "Crop name is required";
  if (!v.quantity || v.quantity <= 0) e.quantity = "Enter the quantity you want to sell";
  if (!v.price || v.price <= 0) e.price = "Enter your expected price per quintal";
  if (!v.harvestDate) e.harvestDate = "Harvest / ready date is required";
  if (!v.location.trim()) e.location = "Village or town is required";
  if (!v.district.trim()) e.district = "District is required";
  return e;
}

export default function ListingFormModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const { addListing, user, toast } = useApp();
  const [values, setValues] = useState<ListingFormValues>(EMPTY);
  const [errors, setErrors] = useState<Errors>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setValues({
        ...EMPTY,
        location: user?.farm?.village ?? "",
        district: user?.farm?.district ?? "",
        state: user?.farm?.state ?? "Andhra Pradesh",
      });
      setErrors({});
    }
  }, [open, user]);

  const set = (key: keyof ListingFormValues) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const target = e.target;
    const val =
      target instanceof HTMLInputElement && target.type === "checkbox" ? target.checked : target.value;
    setValues((v) => ({
      ...v,
      [key]: key === "quantity" || key === "price" ? Number(val) : val,
    }));
    setErrors((er) => ({ ...er, [key]: "" }));
  };

  const onPhoto = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setValues((v) => ({ ...v, image: URL.createObjectURL(file) }));
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const errs = validate(values);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    setSaving(true);
    await new Promise((r) => setTimeout(r, 750)); // simulate listingService.create
    addListing({ ...values, emoji: cropEmoji(values.crop) });
    setSaving(false);
    toast("Listing published! Buyers can now find your produce.", "success");
    onClose();
  };

  const total = values.quantity > 0 && values.price > 0 ? values.quantity * values.price : 0;

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide
      title="Add produce listing"
      subtitle="Describe your produce clearly — good listings sell 3× faster."
      footer={
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          {total > 0 && (
            <p className="text-sm font-semibold text-charcoal-700">
              Expected value: <span className="text-forest-700">{formatINR(total)}</span>
            </p>
          )}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose} disabled={saving}>
              Cancel
            </Button>
            <Button type="submit" form="listing-form" loading={saving}>
              Submit listing
            </Button>
          </div>
        </div>
      }
    >
      <form id="listing-form" onSubmit={onSubmit} noValidate className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Crop name" htmlFor="ls-crop" required error={errors.crop}>
            <Input id="ls-crop" value={values.crop} onChange={set("crop")} placeholder="e.g. Tomato, Chilli, Paddy" error={errors.crop} />
          </Field>
          <Field label="Variety" htmlFor="ls-variety">
            <Input id="ls-variety" value={values.variety} onChange={set("variety")} placeholder="e.g. Teja S-17" />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Quantity" htmlFor="ls-qty" required error={errors.quantity}>
            <Input id="ls-qty" type="number" min="0" step="0.1" value={values.quantity || ""} onChange={set("quantity")} placeholder="e.g. 25" error={errors.quantity} />
          </Field>
          <Field label="Unit" htmlFor="ls-unit">
            <Select id="ls-unit" value={values.unit} onChange={set("unit")}>
              <option value="quintals">Quintals</option>
              <option value="kg">Kilograms</option>
              <option value="tonnes">Tonnes</option>
              <option value="crates">Crates</option>
            </Select>
          </Field>
          <Field label="Expected price (₹/quintal)" htmlFor="ls-price" required error={errors.price}>
            <Input id="ls-price" type="number" min="0" step="10" value={values.price || ""} onChange={set("price")} placeholder="e.g. 1550" error={errors.price} />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Quality grade" htmlFor="ls-grade">
            <Select id="ls-grade" value={values.grade} onChange={set("grade")}>
              <option value="A">Grade A — premium</option>
              <option value="B">Grade B — standard</option>
            </Select>
          </Field>
          <Field label="Harvest / ready date" htmlFor="ls-date" required error={errors.harvestDate}>
            <Input id="ls-date" type="date" value={values.harvestDate} onChange={set("harvestDate")} error={errors.harvestDate} />
          </Field>
        </div>

        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Village / town" htmlFor="ls-village" required error={errors.location}>
            <Input id="ls-village" value={values.location} onChange={set("location")} error={errors.location} />
          </Field>
          <Field label="District" htmlFor="ls-district" required error={errors.district}>
            <Input id="ls-district" value={values.district} onChange={set("district")} error={errors.district} />
          </Field>
          <Field label="State" htmlFor="ls-state">
            <Select id="ls-state" value={values.state} onChange={set("state")}>
              <option>Andhra Pradesh</option>
              <option>Telangana</option>
              <option>Karnataka</option>
              <option>Tamil Nadu</option>
              <option>Maharashtra</option>
            </Select>
          </Field>
        </div>

        <Field label="Description" htmlFor="ls-desc" hint="Mention size, moisture, packing, transport options…">
          <Textarea id="ls-desc" value={values.description} onChange={set("description")} placeholder="e.g. Firm deep-red tomatoes, crate packing, farm pickup or APMC delivery" />
        </Field>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <Field label="Photo (optional)" htmlFor="ls-image">
            <div className="flex items-center gap-3">
              {values.image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={values.image} alt="Produce preview" className="h-16 w-24 rounded-xl border border-charcoal-100 object-cover" />
              ) : (
                <span className="flex h-16 w-24 items-center justify-center rounded-xl border-2 border-dashed border-charcoal-200 bg-beige-100 text-2xl">
                  {cropEmoji(values.crop || "x")}
                </span>
              )}
              <label className="focus-ring inline-flex cursor-pointer items-center gap-2 rounded-xl border border-charcoal-200 bg-white px-3.5 py-2 text-sm font-semibold text-charcoal-700 hover:border-forest-400">
                <ImagePlus className="h-4 w-4" aria-hidden />
                Upload
                <input id="ls-image" type="file" accept="image/*" className="sr-only" onChange={onPhoto} />
              </label>
            </div>
          </Field>
          <label className="flex cursor-pointer items-center gap-2.5 pb-1 text-sm font-medium text-charcoal-700">
            <input type="checkbox" checked={values.organic} onChange={set("organic")} className="h-4 w-4 rounded border-charcoal-300 text-forest-600 focus:ring-forest-500" />
            This produce is organic / pesticide-free
          </label>
        </div>
      </form>
    </Modal>
  );
}
