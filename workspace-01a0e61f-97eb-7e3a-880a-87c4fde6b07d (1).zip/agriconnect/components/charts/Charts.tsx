"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export const CHART_COLORS = {
  forest: "#31704c",
  leaf: "#22c55e",
  earth: "#b0825c",
  sun: "#d99e1b",
  sky: "#0284c7",
  orange: "#ea580c",
};

const AXIS = { fontSize: 11, fill: "#5c665f" };
const TOOLTIP_STYLE = {
  borderRadius: 12,
  border: "1px solid #e3e6e3",
  boxShadow: "0 8px 24px -12px rgba(28,42,32,.2)",
  fontSize: 12,
  padding: "8px 12px",
} as const;

/* ------------------------------ Area (revenue) ---------------------------- */

export function RevenueAreaChart({
  data,
  height = 260,
  colorKey = "revenue",
}: {
  data: Array<Record<string, string | number>>;
  height?: number;
  colorKey?: string;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <defs>
          <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={CHART_COLORS.forest} stopOpacity={0.32} />
            <stop offset="100%" stopColor={CHART_COLORS.forest} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e3e6e3" vertical={false} />
        <XAxis dataKey="month" tick={AXIS} axisLine={false} tickLine={false} />
        <YAxis tick={AXIS} axisLine={false} tickLine={false} width={44} />
        <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v) => [`₹${v}K`, "Revenue"]} />
        <Area
          type="monotone"
          dataKey={colorKey}
          stroke={CHART_COLORS.forest}
          strokeWidth={2.5}
          fill="url(#revGrad)"
          activeDot={{ r: 5 }}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

/* -------------------------------- Bar (yield) ----------------------------- */

export function SimpleBarChart({
  data,
  xKey,
  yKey,
  color = CHART_COLORS.forest,
  height = 260,
  tooltipLabel,
}: {
  data: Array<Record<string, string | number>>;
  xKey: string;
  yKey: string;
  color?: string;
  height?: number;
  tooltipLabel?: string;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e3e6e3" vertical={false} />
        <XAxis dataKey={xKey} tick={AXIS} axisLine={false} tickLine={false} />
        <YAxis tick={AXIS} axisLine={false} tickLine={false} width={44} />
        <Tooltip
          contentStyle={TOOLTIP_STYLE}
          cursor={{ fill: "rgba(49,112,76,0.06)" }}
          formatter={(v) => [v, tooltipLabel ?? yKey]}
        />
        <Bar dataKey={yKey} fill={color} radius={[6, 6, 0, 0]} maxBarSize={42} />
      </BarChart>
    </ResponsiveContainer>
  );
}

/* ------------------------------- Line (trends) ---------------------------- */

export function SimpleLineChart({
  data,
  xKey,
  yKey,
  color = CHART_COLORS.forest,
  height = 260,
  tooltipLabel,
  yFmt,
}: {
  data: Array<Record<string, string | number>>;
  xKey: string;
  yKey: string;
  color?: string;
  height?: number;
  tooltipLabel?: string;
  yFmt?: (v: number) => string;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e3e6e3" vertical={false} />
        <XAxis dataKey={xKey} tick={AXIS} axisLine={false} tickLine={false} />
        <YAxis
          tick={AXIS}
          axisLine={false}
          tickLine={false}
          width={52}
          domain={["dataMin - 40", "dataMax + 40"]}
          tickFormatter={(v: number) => (yFmt ? yFmt(v) : String(v))}
        />
        <Tooltip
          contentStyle={TOOLTIP_STYLE}
          formatter={(v) => (yFmt ? yFmt(Number(v)) : v)}
        />
        <Line
          type="monotone"
          dataKey={yKey}
          stroke={color}
          strokeWidth={2.5}
          dot={false}
          activeDot={{ r: 5 }}
          name={tooltipLabel}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

/* ----------------------------- Composed (profit) -------------------------- */

export function ProfitChart({
  data,
  height = 260,
}: {
  data: Array<Record<string, string | number>>;
  height?: number;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <ComposedChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e3e6e3" vertical={false} />
        <XAxis dataKey="month" tick={AXIS} axisLine={false} tickLine={false} />
        <YAxis tick={AXIS} axisLine={false} tickLine={false} width={44} />
        <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v) => [`₹${v}K`, undefined]} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar dataKey="revenue" name="Revenue" fill={CHART_COLORS.forest} radius={[6, 6, 0, 0]} maxBarSize={26} />
        <Bar dataKey="expenses" name="Expenses" fill={CHART_COLORS.earth} radius={[6, 6, 0, 0]} maxBarSize={26} />
        <Line
          type="monotone"
          dataKey="profit"
          name="Profit"
          stroke={CHART_COLORS.sun}
          strokeWidth={2.5}
          dot={{ r: 3 }}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}

/* -------------------------------- Donut (stages) -------------------------- */

export function DonutChart({
  data,
  height = 220,
}: {
  data: Array<{ name: string; value: number; color: string }>;
  height?: number;
}) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie
          data={data}
          dataKey="value"
          nameKey="name"
          innerRadius="62%"
          outerRadius="88%"
          paddingAngle={3}
          strokeWidth={0}
        >
          {data.map((d) => (
            <Cell key={d.name} fill={d.color} />
          ))}
        </Pie>
        <Tooltip contentStyle={TOOLTIP_STYLE} />
      </PieChart>
    </ResponsiveContainer>
  );
}

/* ------------------------------ Mini sparkline ---------------------------- */

/** Tiny dependency-free SVG sparkline for price cards. */
export function MiniSparkline({
  data,
  positive,
  width = 96,
  height = 32,
}: {
  data: number[];
  positive: boolean;
  width?: number;
  height?: number;
}) {
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const pts = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * (width - 4) + 2;
      const y = height - 3 - ((v - min) / range) * (height - 6);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  const color = positive ? "#16a34a" : "#dc2626";
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} aria-hidden className="overflow-visible">
      <polyline points={pts} fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
