import type { CSSProperties, ReactNode } from "react";

/**
 * ChartFrame — makes wide charts friendly on small screens.
 * On phones the chart keeps a minimum width and scrolls horizontally
 * (with a thin scrollbar); from `sm:` up it stretches to the container
 * exactly as before. Visual output on desktop is unchanged.
 */
export default function ChartFrame({
  children,
  minWidth = 560,
  label,
}: {
  children: ReactNode;
  minWidth?: number;
  label?: string;
}) {
  return (
    <div className="overflow-x-auto scrollbar-thin" aria-label={label} tabIndex={0}>
      <div
        className="chart-scroll-inner"
        style={{ "--chart-min": `${minWidth}px` } as CSSProperties}
      >
        {children}
      </div>
    </div>
  );
}
