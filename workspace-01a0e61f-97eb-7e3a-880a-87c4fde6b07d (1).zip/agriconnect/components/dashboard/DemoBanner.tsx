"use client";

import { useState } from "react";
import { Info, X } from "lucide-react";

/** Dismissible banner separating sample data from future live data. */
export default function DemoBanner() {
  const [dismissed, setDismissed] = useState(false);
  if (dismissed) return null;
  return (
    <div
      role="note"
      className="mb-5 flex items-start gap-3 rounded-2xl border border-sun-200 bg-sun-100/70 px-4 py-3"
    >
      <Info className="mt-0.5 h-[18px] w-[18px] shrink-0 text-sun-600" aria-hidden />
      <p className="flex-1 text-xs font-semibold leading-relaxed text-sun-600 sm:text-sm">
        You&apos;re viewing <strong>realistic sample data</strong>. Live mandi prices, weather and
        disease AI arrive with the next release — the layout is exactly what you&apos;ll get.
      </p>
      <button
        type="button"
        onClick={() => setDismissed(true)}
        aria-label="Dismiss sample data notice"
        className="focus-ring rounded-full p-1 text-sun-600 hover:bg-sun-200/60"
      >
        <X className="h-4 w-4" aria-hidden />
      </button>
    </div>
  );
}
