"use client";

import Link from "next/link";
import { Mail, Phone, MapPin, Facebook, Instagram, Twitter, Youtube } from "lucide-react";
import Logo from "@/components/layout/Logo";
import LanguageSelector from "@/components/layout/LanguageSelector";
import { contactInfo } from "@/lib/data/landing";
import { NAV_ITEMS, navLabel } from "@/components/layout/nav-items";
import { useApp } from "@/lib/context/AppContext";

const SOCIALS = [
  { icon: Facebook, label: "Facebook" },
  { icon: Instagram, label: "Instagram" },
  { icon: Twitter, label: "Twitter" },
  { icon: Youtube, label: "YouTube" },
];

export default function Footer() {
  const { t } = useApp();
  return (
    <footer className="border-t border-charcoal-800 bg-charcoal-950 text-charcoal-300">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Logo dark />
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-charcoal-400">
              {t("footer.tagline")} Built for Indian farmers, buyers and the entire agri
              ecosystem — in your language.
            </p>
            <div className="mt-5 flex gap-2">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href="#"
                  aria-label={s.label}
                  className="focus-ring rounded-xl bg-white/5 p-2.5 text-charcoal-300 transition-colors hover:bg-forest-700 hover:text-white"
                >
                  <s.icon className="h-[18px] w-[18px]" aria-hidden />
                </a>
              ))}
            </div>
          </div>

          <nav aria-label="Platform links">
            <h3 className="text-xs font-bold uppercase tracking-[0.14em] text-charcoal-500">Platform</h3>
            <ul className="mt-4 space-y-2.5">
              {NAV_ITEMS.slice(0, 6).map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="focus-ring rounded text-sm text-charcoal-400 hover:text-white">
                    {navLabel(t, item)}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="More links">
            <h3 className="text-xs font-bold uppercase tracking-[0.14em] text-charcoal-500">Explore</h3>
            <ul className="mt-4 space-y-2.5">
              {NAV_ITEMS.slice(6).map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="focus-ring rounded text-sm text-charcoal-400 hover:text-white">
                    {navLabel(t, item)}
                  </Link>
                </li>
              ))}
              <li>
                <Link href="/login" className="focus-ring rounded text-sm text-charcoal-400 hover:text-white">
                  {t("common.login")}
                </Link>
              </li>
            </ul>
          </nav>

          <div>
            <h3 className="text-xs font-bold uppercase tracking-[0.14em] text-charcoal-500">Contact</h3>
            <ul className="mt-4 space-y-3 text-sm">
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 shrink-0 text-forest-400" aria-hidden />
                <a href={`mailto:${contactInfo.email}`} className="focus-ring rounded text-charcoal-400 hover:text-white">
                  {contactInfo.email}
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 shrink-0 text-forest-400" aria-hidden />
                <a href={`tel:${contactInfo.phone.replace(/\s/g, "")}`} className="focus-ring rounded text-charcoal-400 hover:text-white">
                  {contactInfo.phone}
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-forest-400" aria-hidden />
                <span className="text-charcoal-400">{contactInfo.address}</span>
              </li>
            </ul>
            <div className="mt-5">
              <p className="mb-2 text-xs font-bold uppercase tracking-[0.14em] text-charcoal-500">Language</p>
              <LanguageSelector dark />
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-6">
          <p className="text-xs leading-relaxed text-charcoal-500">
            Demo application — all market prices, weather, schemes, listings and statistics shown are
            realistic sample data, not live figures. Always verify scheme details on official
            government portals before applying.
          </p>
          <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs text-charcoal-500">© 2026 AgriConnect Technologies Pvt. Ltd.</p>
            <div className="flex gap-4 text-xs text-charcoal-500">
              <a href="#" className="focus-ring rounded hover:text-charcoal-300">Privacy Policy</a>
              <a href="#" className="focus-ring rounded hover:text-charcoal-300">Terms of Service</a>
              <a href="#" className="focus-ring rounded hover:text-charcoal-300">Support</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
