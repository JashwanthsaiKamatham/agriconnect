"use client";

import { Star, Quote } from "lucide-react";
import Avatar from "@/components/ui/Avatar";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import { useApp } from "@/lib/context/AppContext";
import { testimonials } from "@/lib/data/landing";

export function Testimonials() {
  return (
    <section id="testimonials" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
      <div className="mx-auto max-w-2xl text-center">
        <Badge variant="success">Real impact</Badge>
        <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-charcoal-900 sm:text-4xl">
          Farmers who switched to direct selling
        </h2>
      </div>
      <div className="mt-12 grid gap-5 md:grid-cols-3">
        {testimonials.map((t) => (
          <figure
            key={t.name}
            className="flex flex-col rounded-2xl border border-charcoal-100 bg-white p-6 shadow-card"
          >
            <Quote className="h-7 w-7 text-forest-200" aria-hidden />
            <div className="mt-3 flex gap-0.5" aria-label={`${t.rating} out of 5 stars`}>
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${i < t.rating ? "fill-sun-400 text-sun-400" : "text-charcoal-200"}`}
                  aria-hidden
                />
              ))}
            </div>
            <blockquote className="mt-3 flex-1 text-sm leading-relaxed text-charcoal-700">
              “{t.quote}”
            </blockquote>
            <figcaption className="mt-5 flex items-center gap-3 border-t border-charcoal-100 pt-4">
              <Avatar name={t.name} size="md" />
              <div>
                <p className="text-sm font-bold text-charcoal-900">{t.name}</p>
                <p className="text-xs text-charcoal-500">{t.detail}</p>
              </div>
            </figcaption>
          </figure>
        ))}
      </div>
      <p className="mt-6 text-center text-xs font-medium text-charcoal-400">
        Stories illustrated with sample data for the product demo.
      </p>
    </section>
  );
}

export function CTABanner() {
  const { t } = useApp();
  return (
    <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-forest-700 via-forest-800 to-forest-950 px-6 py-14 text-center shadow-lift sm:px-12">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-leaf-500/10 blur-2xl" aria-hidden />
        <div className="absolute -bottom-20 -left-10 h-64 w-64 rounded-full bg-sun-400/10 blur-2xl" aria-hidden />
        <h2 className="relative mx-auto max-w-2xl text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
          Ready to grow smarter this season?
        </h2>
        <p className="relative mx-auto mt-4 max-w-xl text-base text-charcoal-200">
          Join 52,000+ farmers already selling direct, saving on inputs and farming with data.
        </p>
        <div className="relative mt-8 flex flex-col justify-center gap-3 sm:flex-row">
          <Button href="/signup" variant="sun" size="lg">
            {t("common.getStarted")} — it&apos;s free
          </Button>
          <Button
            href="/login"
            size="lg"
            variant="outline"
            className="!border-white/30 !bg-white/10 !text-white hover:!border-white/60 hover:!text-white"
          >
            {t("common.demoLogin")}
          </Button>
        </div>
      </div>
    </section>
  );
}
