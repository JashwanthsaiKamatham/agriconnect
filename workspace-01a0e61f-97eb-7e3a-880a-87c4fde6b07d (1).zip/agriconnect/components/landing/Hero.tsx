"use client";

import Button from "@/components/ui/Button";
import { useApp } from "@/lib/context/AppContext";
import { platformStats } from "@/lib/data/landing";

export default function Hero() {
  const { t } = useApp();
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-forest-50/70 via-beige-50 to-beige-50 pt-28 sm:pt-32">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 pb-16 sm:px-6 lg:grid-cols-2 lg:gap-10 lg:px-8 lg:pb-24">
        {/* Copy */}
        <div className="animate-fade-in-up">
          <span className="inline-flex items-center gap-2 rounded-full border border-forest-200 bg-white px-3.5 py-1.5 text-xs font-bold text-forest-700 shadow-sm">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-leaf-500 opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-leaf-500" />
            </span>
            Now live in Andhra Pradesh · Telangana · Karnataka
          </span>
          <h1 className="mt-5 text-4xl font-extrabold leading-[1.08] tracking-tight text-charcoal-900 sm:text-5xl lg:text-[3.4rem]">
            Grow Smarter. <span className="text-forest-600">Sell Better.</span> Connect Directly.
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-charcoal-600 sm:text-lg">
            AgriConnect is built for Indian farmers — get live mandi prices, village-level weather,
            AI crop-disease scans, direct buyers, nearby equipment for rent, expert advice in your
            language, and every government scheme in one place.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button href="/signup" size="lg">
              {t("common.getStarted")}
            </Button>
            <Button href="/marketplace" variant="outline" size="lg">
              {t("common.exploreMarketplace")}
            </Button>
          </div>
          <p className="mt-4 text-xs font-medium text-charcoal-400">
            Free for farmers · Works on any smartphone · Available in తెలుగు, ಕನ್ನಡ & हिन्दी
          </p>
        </div>

        {/* Visual */}
        <div className="relative animate-fade-in-up">
          <div className="overflow-hidden rounded-3xl shadow-lift">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/images/hero.jpg"
              alt="Indian farmer standing in a lush green paddy field at golden hour"
              className="h-[340px] w-full object-cover sm:h-[440px] lg:h-[520px]"
            />
          </div>

          {/* Floating weather card */}
          <div className="absolute -left-2 top-8 hidden rounded-2xl border border-charcoal-100 bg-white/95 p-3.5 shadow-lift backdrop-blur sm:block lg:-left-8">
            <p className="text-[11px] font-bold uppercase tracking-wide text-charcoal-400">Veldurthi · Now</p>
            <div className="mt-1 flex items-center gap-2">
              <span aria-hidden className="text-2xl">⛅</span>
              <div>
                <p className="text-lg font-extrabold leading-none text-charcoal-900">29°C</p>
                <p className="text-[11px] font-semibold text-sky-600">Rain Wed — 80%</p>
              </div>
            </div>
          </div>

          {/* Floating price card */}
          <div className="absolute -bottom-5 right-2 rounded-2xl border border-charcoal-100 bg-white/95 p-3.5 shadow-lift backdrop-blur sm:right-6">
            <p className="text-[11px] font-bold uppercase tracking-wide text-charcoal-400">Kurnool APMC · Cotton</p>
            <div className="mt-1 flex items-center gap-2">
              <span aria-hidden className="text-2xl">☁️</span>
              <div>
                <p className="text-lg font-extrabold leading-none text-charcoal-900">₹7,020<span className="text-xs font-bold text-charcoal-400">/q</span></p>
                <p className="text-[11px] font-bold text-leaf-600">▲ 3.8% today</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats band */}
      <div className="border-t border-earth-100 bg-white/70">
        <dl className="mx-auto grid max-w-7xl grid-cols-2 gap-x-4 gap-y-6 px-4 py-8 sm:px-6 md:grid-cols-4 lg:px-8">
          {platformStats.map((s) => (
            <div key={s.label} className="text-center md:text-left">
              <dt className="order-2 text-xs font-semibold uppercase tracking-wide text-charcoal-500">{s.label}</dt>
              <dd className="order-1 text-2xl font-extrabold tracking-tight text-forest-700 sm:text-3xl">{s.value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
