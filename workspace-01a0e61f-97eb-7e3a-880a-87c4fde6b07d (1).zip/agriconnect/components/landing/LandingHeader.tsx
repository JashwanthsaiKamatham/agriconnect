"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import Logo from "@/components/layout/Logo";
import LanguageSelector from "@/components/layout/LanguageSelector";
import Button from "@/components/ui/Button";
import { useApp } from "@/lib/context/AppContext";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "#features", label: "Features" },
  { href: "#roles", label: "For every role" },
  { href: "#how", label: "How it works" },
  { href: "#testimonials", label: "Stories" },
];

export default function LandingHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { user, t } = useApp();

  /* Lock body scroll while the mobile menu is open */
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all",
        scrolled ? "border-b border-charcoal-100 bg-white/90 shadow-panel backdrop-blur" : "bg-transparent"
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
        <Logo />
        <nav aria-label="Landing navigation" className="ml-6 hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="focus-ring rounded-xl px-3.5 py-2 text-sm font-semibold text-charcoal-600 hover:bg-forest-50 hover:text-forest-800"
            >
              {l.label}
            </a>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <LanguageSelector />
          {user ? (
            <Button href="/dashboard" size="sm" className="hidden sm:inline-flex">
              {t("nav.dashboard")}
            </Button>
          ) : (
            <>
              <Link
                href="/login"
                className="focus-ring hidden rounded-xl px-3.5 py-2 text-sm font-bold text-charcoal-700 hover:text-forest-700 sm:inline-flex"
              >
                {t("common.login")}
              </Link>
              <Button href="/signup" size="sm" className="hidden sm:inline-flex">
                {t("common.getStarted")}
              </Button>
            </>
          )}
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            className="focus-ring rounded-xl p-2 text-charcoal-700 hover:bg-charcoal-100 lg:hidden"
          >
            {open ? <X className="h-5 w-5" aria-hidden /> : <Menu className="h-5 w-5" aria-hidden />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-charcoal-100 bg-white px-4 pb-4 pt-2 shadow-panel lg:hidden">
          <nav aria-label="Mobile landing navigation" className="flex flex-col">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="focus-ring rounded-xl px-3 py-3 text-sm font-semibold text-charcoal-700 hover:bg-forest-50"
              >
                {l.label}
              </a>
            ))}
            <div className="mt-2 flex gap-2 border-t border-charcoal-100 pt-3">
              <Button href="/login" variant="outline" size="sm" fullWidth>
                {t("common.login")}
              </Button>
              <Button href="/signup" size="sm" fullWidth>
                {t("common.getStarted")}
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
