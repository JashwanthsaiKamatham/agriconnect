"use client";

import Link from "next/link";
import {
  IndianRupee,
  CloudSun,
  Microscope,
  Store,
  Tractor,
  GraduationCap,
  UserRound,
  Briefcase,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import { useApp } from "@/lib/context/AppContext";
import {
  features,
  roles,
  howItWorks,
  farmerBenefits,
  buyerBenefits,
} from "@/lib/data/landing";

const FEATURE_ICONS: Record<string, LucideIcon> = {
  market: IndianRupee,
  weather: CloudSun,
  disease: Microscope,
  marketplace: Store,
  equipment: Tractor,
  expert: GraduationCap,
};

const ROLE_ICONS: Record<string, LucideIcon> = {
  farmer: UserRound,
  buyer: Briefcase,
  expert: GraduationCap,
  supplier: Tractor,
  logistics: Store,
  admin: UserRound,
};

export function Features() {
  return (
    <section id="features" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
      <div className="mx-auto max-w-2xl text-center">
        <Badge variant="forest">Everything in one app</Badge>
        <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-charcoal-900 sm:text-4xl">
          Built around how farming actually works
        </h2>
        <p className="mt-4 text-base text-charcoal-600">
          From sowing to selling, each tool removes one more middleman, guesswork or wasted trip.
        </p>
      </div>
      <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((f) => {
          const Icon = FEATURE_ICONS[f.icon] ?? Store;
          return (
            <article
              key={f.title}
              className="group rounded-2xl border border-charcoal-100 bg-white p-6 shadow-card transition-all hover:-translate-y-0.5 hover:shadow-lift"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-forest-600 text-white shadow-sm transition-transform group-hover:scale-105">
                <Icon className="h-6 w-6" aria-hidden />
              </span>
              <h3 className="mt-4 text-lg font-bold text-charcoal-900">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-charcoal-600">{f.body}</p>
            </article>
          );
        })}
      </div>
    </section>
  );
}

export function Roles() {
  return (
    <section id="roles" className="scroll-mt-20 bg-forest-950 py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Badge variant="success" className="!bg-forest-900 !text-leaf-300">One platform, whole ecosystem</Badge>
          <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            Made for every hand that feeds India
          </h2>
          <p className="mt-4 text-base text-charcoal-300">
            The farmer experience is live today. Every other role is on the 2027 roadmap.
          </p>
        </div>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {roles.map((r) => {
            const Icon = ROLE_ICONS[r.icon] ?? UserRound;
            return (
              <article
                key={r.title}
                className={`rounded-2xl border p-6 ${
                  r.active
                    ? "border-leaf-500/60 bg-gradient-to-br from-forest-900 to-forest-800 shadow-lift"
                    : "border-white/10 bg-white/[0.04]"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`flex h-11 w-11 items-center justify-center rounded-xl ${r.active ? "bg-leaf-500 text-forest-950" : "bg-white/10 text-charcoal-300"}`}>
                    <Icon className="h-[22px] w-[22px]" aria-hidden />
                  </span>
                  {r.active ? (
                    <Badge variant="success" className="!bg-leaf-500/15 !text-leaf-300">● Live now</Badge>
                  ) : (
                    <Badge variant="neutral" className="!bg-white/10 !text-charcoal-300">Coming soon</Badge>
                  )}
                </div>
                <h3 className={`mt-4 text-lg font-bold ${r.active ? "text-white" : "text-charcoal-200"}`}>{r.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-charcoal-400">{r.body}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function HowItWorks() {
  return (
    <section id="how" className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
      <div className="mx-auto max-w-2xl text-center">
        <Badge variant="earth">From field to payment in 4 steps</Badge>
        <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-charcoal-900 sm:text-4xl">
          How AgriConnect works
        </h2>
      </div>
      <ol className="relative mx-auto mt-14 max-w-3xl space-y-8">
        {howItWorks.map((s, i) => (
          <li key={s.step} className="relative flex gap-5">
            {i < howItWorks.length - 1 && (
              <span className="absolute left-[26px] top-14 h-[calc(100%-2rem)] w-0.5 bg-gradient-to-b from-forest-300 to-transparent" aria-hidden />
            )}
            <span className="flex h-[52px] w-[52px] shrink-0 items-center justify-center rounded-2xl bg-forest-600 text-lg font-extrabold text-white shadow-card">
              {s.step}
            </span>
            <div className="rounded-2xl border border-charcoal-100 bg-white p-5 shadow-card">
              <h3 className="text-base font-bold text-charcoal-900">{s.title}</h3>
              <p className="mt-1 text-sm leading-relaxed text-charcoal-600">{s.body}</p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}

export function Benefits() {
  return (
    <section className="bg-beige-100 py-16 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div className="order-2 lg:order-1">
            <Badge variant="forest">For farmers</Badge>
            <h2 className="mt-3 text-2xl font-extrabold tracking-tight text-charcoal-900 sm:text-3xl">
              Keep more of what you grow
            </h2>
            <ul className="mt-6 space-y-3.5">
              {farmerBenefits.map((b) => (
                <li key={b} className="flex items-start gap-3">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-leaf-600" aria-hidden />
                  <span className="text-sm leading-relaxed text-charcoal-700">{b}</span>
                </li>
              ))}
            </ul>
            <Button href="/signup" className="mt-7">
              Start free as a farmer
            </Button>
          </div>
          <div className="order-1 lg:order-2">
            <div className="overflow-hidden rounded-3xl shadow-lift">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/crops/tomato.jpg"
                alt="Ripe tomatoes ready for harvest on the vine"
                className="h-64 w-full object-cover sm:h-80"
              />
            </div>
          </div>
        </div>

        <div className="mt-20 grid items-center gap-10 lg:grid-cols-2">
          <div>
            <div className="overflow-hidden rounded-3xl shadow-lift">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/crops/onion.jpg"
                alt="Freshly harvested red onions packed in a crate"
                className="h-64 w-full object-cover sm:h-80"
              />
            </div>
          </div>
          <div>
            <Badge variant="earth">For buyers & traders</Badge>
            <h2 className="mt-3 text-2xl font-extrabold tracking-tight text-charcoal-900 sm:text-3xl">
              Source better, straight from the farm
            </h2>
            <ul className="mt-6 space-y-3.5">
              {buyerBenefits.map((b) => (
                <li key={b} className="flex items-start gap-3">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-earth-600" aria-hidden />
                  <span className="text-sm leading-relaxed text-charcoal-700">{b}</span>
                </li>
              ))}
            </ul>
            <Link
              href="/marketplace"
              className="focus-ring mt-7 inline-flex items-center gap-2 text-sm font-bold text-forest-700 hover:text-forest-800"
            >
              Explore the marketplace
              <ArrowRight className="h-4 w-4" aria-hidden />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
