"use client";

import { useEffect, useRef, useState } from "react";
import { Globe } from "lucide-react";
import { LANGUAGES } from "@/lib/i18n/translations";
import { useApp } from "@/lib/context/AppContext";
import { cn } from "@/lib/utils";

/** Dropdown language switcher — English default, plus తెలుగు / ಕನ್ನಡ / हिन्दी. */
export default function LanguageSelector({ dark = false }: { dark?: boolean }) {
  const { lang, setLang } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const current = LANGUAGES.find((l) => l.code === lang) ?? LANGUAGES[0];

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Select language"
        className={cn(
          "focus-ring flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-sm font-semibold transition-colors",
          dark
            ? "text-white/90 hover:bg-white/10"
            : "border border-charcoal-200 bg-white text-charcoal-700 hover:border-forest-400 hover:text-forest-700"
        )}
      >
        <Globe className="h-4 w-4" aria-hidden />
        <span className="hidden sm:inline">{current.native}</span>
        <svg className="h-3.5 w-3.5 opacity-60" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
          <path d="m5 8 5 5 5-5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>

      {open && (
        <ul
          role="listbox"
          aria-label="Languages"
          className="absolute right-0 z-50 mt-2 w-44 overflow-hidden rounded-2xl border border-charcoal-100 bg-white py-1.5 shadow-lift"
        >
          {LANGUAGES.map((l) => (
            <li key={l.code}>
              <button
                type="button"
                role="option"
                aria-selected={l.code === lang}
                onClick={() => {
                  setLang(l.code);
                  setOpen(false);
                }}
                className={cn(
                  "focus-ring flex w-full items-center justify-between px-4 py-2.5 text-sm",
                  l.code === lang
                    ? "bg-forest-50 font-bold text-forest-700"
                    : "text-charcoal-700 hover:bg-charcoal-50"
                )}
              >
                <span>{l.native}</span>
                <span className="text-xs text-charcoal-400">{l.label}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
