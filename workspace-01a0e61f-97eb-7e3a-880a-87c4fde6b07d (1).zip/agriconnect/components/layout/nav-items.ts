import {
  BarChart3,
  CloudSun,
  IndianRupee,
  Landmark,
  LayoutDashboard,
  Microscope,
  Sprout,
  Store,
  Tractor,
  Truck,
  UserRound,
  GraduationCap,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface NavItem {
  href: string;
  labelKey: string;
  fallback: string;
  icon: LucideIcon;
  group: "main" | "market" | "grow" | "account";
}

export const NAV_ITEMS: NavItem[] = [
  { href: "/dashboard", labelKey: "nav.dashboard", fallback: "Dashboard", icon: LayoutDashboard, group: "main" },
  { href: "/crops", labelKey: "nav.crops", fallback: "My Crops", icon: Sprout, group: "main" },
  { href: "/market", labelKey: "nav.market", fallback: "Market Prices", icon: IndianRupee, group: "main" },
  { href: "/weather", labelKey: "nav.weather", fallback: "Weather", icon: CloudSun, group: "main" },
  { href: "/disease", labelKey: "nav.disease", fallback: "Disease Detection", icon: Microscope, group: "main" },
  { href: "/marketplace", labelKey: "nav.marketplace", fallback: "Marketplace", icon: Store, group: "market" },
  { href: "/equipment", labelKey: "nav.equipment", fallback: "Equipment", icon: Tractor, group: "market" },
  { href: "/experts", labelKey: "nav.experts", fallback: "Experts", icon: GraduationCap, group: "market" },
  { href: "/logistics", labelKey: "nav.logistics", fallback: "Logistics", icon: Truck, group: "market" },
  { href: "/schemes", labelKey: "nav.schemes", fallback: "Govt. Schemes", icon: Landmark, group: "grow" },
  { href: "/analytics", labelKey: "nav.analytics", fallback: "Farm Analytics", icon: BarChart3, group: "grow" },
  { href: "/profile", labelKey: "nav.profile", fallback: "Profile", icon: UserRound, group: "account" },
];

export const GROUP_LABELS: Record<NavItem["group"], string> = {
  main: "Farm",
  market: "Buy · Sell · Consult",
  grow: "Grow & improve",
  account: "Account",
};

/** Bottom navigation on mobile (rest go into "More"). */
export const MOBILE_NAV_HREFS = ["/dashboard", "/crops", "/market", "/marketplace"];

export function navLabel(t: (k: string) => string, item: NavItem): string {
  const translated = t(item.labelKey);
  return translated === item.labelKey ? item.fallback : translated;
}
