"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import {
  Bell,
  CheckCheck,
  CloudRain,
  IndianRupee,
  Landmark,
  Menu,
  Store,
  GraduationCap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useApp } from "@/lib/context/AppContext";
import { NAV_ITEMS, navLabel } from "./nav-items";
import LanguageSelector from "./LanguageSelector";
import Logo from "./Logo";
import Avatar from "@/components/ui/Avatar";
import Badge from "@/components/ui/Badge";

const NOTIF_ICONS = {
  weather: CloudRain,
  price: IndianRupee,
  market: Store,
  scheme: Landmark,
  expert: GraduationCap,
} as const;

export default function Topbar({ onOpenMenu }: { onOpenMenu: () => void }) {
  const pathname = usePathname();
  const { notifications, markAllNotificationsRead, t } = useApp();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  const unread = notifications.filter((n) => !n.read).length;
  const current = NAV_ITEMS.find((i) => i.href === pathname);
  const title = current ? navLabel(t, current) : "AgriConnect";

  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  return (
    <header className="sticky top-0 z-30 border-b border-charcoal-100 bg-white/85 backdrop-blur">
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={onOpenMenu}
          aria-label="Open menu"
          className="focus-ring rounded-xl p-2 text-charcoal-700 hover:bg-charcoal-100 lg:hidden"
        >
          <Menu className="h-5 w-5" aria-hidden />
        </button>

        <div className="lg:hidden">
          <Logo compact href="/dashboard" />
        </div>

        <h1 className="hidden truncate text-base font-bold text-charcoal-900 lg:block">{title}</h1>

        <div className="ml-auto flex items-center gap-2">
          <LanguageSelector />

          <div ref={ref} className="relative">
            <button
              type="button"
              onClick={() => setOpen((o) => !o)}
              aria-haspopup="dialog"
              aria-expanded={open}
              aria-label={`Notifications (${unread} unread)`}
              className="focus-ring relative rounded-xl border border-charcoal-200 bg-white p-2 text-charcoal-700 hover:border-forest-400 hover:text-forest-700"
            >
              <Bell className="h-5 w-5" aria-hidden />
              {unread > 0 && (
                <span className="absolute -right-1 -top-1 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white">
                  {unread}
                </span>
              )}
            </button>

            {open && (
              <div
                role="dialog"
                aria-label="Notifications panel"
                className="absolute right-0 z-50 mt-2 w-[min(92vw,380px)] overflow-hidden rounded-2xl border border-charcoal-100 bg-white shadow-lift"
              >
                <div className="flex items-center justify-between border-b border-charcoal-100 px-4 py-3">
                  <p className="text-sm font-bold text-charcoal-900">
                    {t("dashboard.notifications")}
                    {unread > 0 && (
                      <Badge variant="danger" className="ml-2">
                        {unread} new
                      </Badge>
                    )}
                  </p>
                  <button
                    type="button"
                    onClick={markAllNotificationsRead}
                    className="focus-ring flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-semibold text-forest-700 hover:bg-forest-50"
                  >
                    <CheckCheck className="h-3.5 w-3.5" aria-hidden />
                    Mark all read
                  </button>
                </div>
                <ul className="max-h-[340px] overflow-y-auto scrollbar-thin">
                  {notifications.map((n) => {
                    const Icon = NOTIF_ICONS[n.type];
                    return (
                      <li
                        key={n.id}
                        className={cn(
                          "flex gap-3 border-b border-charcoal-50 px-4 py-3 last:border-0",
                          !n.read && "bg-forest-50/60"
                        )}
                      >
                        <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-forest-100 text-forest-700">
                          <Icon className="h-[18px] w-[18px]" aria-hidden />
                        </span>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold leading-snug text-charcoal-900">
                            {n.title}
                            {!n.read && <span className="ml-2 inline-block h-2 w-2 rounded-full bg-forest-500" aria-label="unread" />}
                          </p>
                          <p className="mt-0.5 text-xs leading-snug text-charcoal-500">{n.body}</p>
                          <p className="mt-1 text-[11px] font-medium text-charcoal-400">{n.time}</p>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}
          </div>

          <Link
            href="/profile"
            aria-label="Profile and settings"
            className="focus-ring rounded-full"
          >
            <Avatar name="Ravi Kumar" size="md" className="ring-2 ring-white hover:ring-forest-200" />
          </Link>
        </div>
      </div>
    </header>
  );
}
