"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect } from "react";
import { LogOut, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useApp } from "@/lib/context/AppContext";
import { GROUP_LABELS, NAV_ITEMS, navLabel, type NavItem } from "./nav-items";
import Logo from "./Logo";
import Avatar from "@/components/ui/Avatar";

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export default function Sidebar({ mobileOpen, onCloseMobile }: SidebarProps) {
  const pathname = usePathname();
  const { user, t, logout, toast } = useApp();

  /* Escape to close + body scroll lock while the drawer is open */
  useEffect(() => {
    if (!mobileOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCloseMobile();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [mobileOpen, onCloseMobile]);

  const groups: Array<NavItem["group"]> = ["main", "market", "grow", "account"];

  const content = (
    <div className="flex h-full flex-col bg-white">
      <div className="flex h-16 items-center justify-between border-b border-charcoal-100 px-4">
        <Logo href="/dashboard" />
        <button
          type="button"
          onClick={onCloseMobile}
          aria-label="Close menu"
          className="focus-ring rounded-full p-2 text-charcoal-500 hover:bg-charcoal-100 lg:hidden"
        >
          <X className="h-5 w-5" aria-hidden />
        </button>
      </div>

      <nav aria-label="Main navigation" className="flex-1 overflow-y-auto px-3 py-4 scrollbar-thin">
        {groups.map((group) => (
          <div key={group} className="mb-4">
            <p className="px-3 pb-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-charcoal-400">
              {GROUP_LABELS[group]}
            </p>
            <ul className="space-y-0.5">
              {NAV_ITEMS.filter((i) => i.group === group).map((item) => {
                const active = pathname === item.href;
                const Icon = item.icon;
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={onCloseMobile}
                      aria-current={active ? "page" : undefined}
                      className={cn(
                        "focus-ring group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors",
                        active
                          ? "bg-forest-600 text-white shadow-sm"
                          : "text-charcoal-600 hover:bg-forest-50 hover:text-forest-800"
                      )}
                    >
                      <Icon
                        className={cn("h-[18px] w-[18px] shrink-0", active ? "text-white" : "text-charcoal-400 group-hover:text-forest-600")}
                        aria-hidden
                      />
                      {navLabel(t, item)}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="border-t border-charcoal-100 p-3">
        <div className="mb-2 flex items-center gap-3 rounded-xl bg-beige-100 px-3 py-2.5">
          <Avatar name={user?.name ?? "Farmer"} size="md" />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold text-charcoal-900">{user?.name}</p>
            <p className="truncate text-[11px] font-medium capitalize text-earth-600">
              {user?.farm?.village ? `${user.farm.village} · ` : ""}
              {user?.role}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            logout();
            toast("You have been logged out.", "info");
          }}
          className="focus-ring flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-charcoal-600 hover:bg-red-50 hover:text-red-700"
        >
          <LogOut className="h-[18px] w-[18px]" aria-hidden />
          {t("common.logout")}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop rail */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 border-r border-charcoal-100 lg:block">
        {content}
      </aside>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[60] lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="absolute inset-0 bg-charcoal-950/50 animate-fade-in" onClick={onCloseMobile} aria-hidden />
          <aside className="absolute inset-y-0 left-0 w-[280px] max-w-[85vw] shadow-lift animate-fade-in">
            {content}
          </aside>
        </div>
      )}
    </>
  );
}
