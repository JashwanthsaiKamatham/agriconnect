import Link from "next/link";
import { Sprout } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Logo({
  href = "/",
  dark = false,
  compact = false,
  className,
}: {
  href?: string;
  dark?: boolean;
  compact?: boolean;
  className?: string;
}) {
  return (
    <Link href={href} className={cn("focus-ring flex items-center gap-2.5 rounded-xl", className)}>
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-forest-500 to-forest-700 text-white shadow-sm">
        <Sprout className="h-5 w-5" aria-hidden />
      </span>
      {!compact && (
        <span className="leading-tight">
          <span className={cn("block text-[17px] font-extrabold tracking-tight", dark ? "text-white" : "text-charcoal-900")}>
            Agri<span className="text-forest-500">Connect</span>
          </span>
          <span className={cn("block text-[10px] font-semibold uppercase tracking-[0.14em]", dark ? "text-charcoal-300" : "text-charcoal-400")}>
            Digital Agriculture
          </span>
        </span>
      )}
    </Link>
  );
}
