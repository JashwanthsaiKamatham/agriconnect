"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu } from "lucide-react";
import { cn } from "@/lib/utils";
import { useApp } from "@/lib/context/AppContext";
import { MOBILE_NAV_HREFS, NAV_ITEMS, navLabel } from "./nav-items";

/** Compact bottom navigation (mobile) — top 4 destinations + "More" sheet. */
export default function MobileNav() {
  const pathname = usePathname();
  const { t } = useApp();
  const [moreOpen, setMoreOpen] = useState(false);

  /* Escape to close + body scroll lock while the sheet is open */
  useEffect(() => {
    if (!moreOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMoreOpen(false);
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [moreOpen]);

  const items = MOBILE_NAV_HREFS.map((href) => NAV_ITEMS.find((i) => i.href === href)!);

  const linkClass = (active: boolean) =>
    cn(
      "focus-ring flex flex-1 flex-col items-center gap-0.5 rounded-xl py-1.5 text-[10px] font-bold",
      active ? "text-forest-700" : "text-charcoal-500"
    );

  return (
    <>
      <nav
        aria-label="Primary mobile navigation"
        className="fixed inset-x-0 bottom-0 z-40 border-t border-charcoal-100 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
      >
        <div className="mx-auto flex max-w-lg items-stretch px-2">
          {items.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href;
            return (
              <Link key={item.href} href={item.href} className={linkClass(active)} aria-current={active ? "page" : undefined}>
                <Icon className={cn("h-5 w-5", active && "drop-shadow")} aria-hidden />
                <span className="max-w-[72px] truncate">{navLabel(t, item)}</span>
                {active && <span className="sr-only">(current)</span>}
              </Link>
            );
          })}
          <button type="button" onClick={() => setMoreOpen(true)} className={linkClass(false)} aria-haspopup="dialog">
            <Menu className="h-5 w-5" aria-hidden />
            <span>{t("nav.more")}</span>
          </button>
        </div>
      </nav>

      {moreOpen && (
        <div className="fixed inset-0 z-[60] lg:hidden" role="dialog" aria-modal="true" aria-label="All sections">
          <div className="absolute inset-0 bg-charcoal-950/50 animate-fade-in" onClick={() => setMoreOpen(false)} aria-hidden />
          <div className="absolute inset-x-0 bottom-0 max-h-[80dvh] overflow-y-auto rounded-t-3xl bg-white p-5 pb-8 shadow-lift animate-fade-in-up scrollbar-thin">
            <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-charcoal-200" aria-hidden />
            <div className="grid grid-cols-3 gap-2">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMoreOpen(false)}
                    className={cn(
                      "focus-ring flex flex-col items-center gap-2 rounded-2xl border px-2 py-4 text-[11px] font-bold text-center",
                      active
                        ? "border-forest-300 bg-forest-50 text-forest-700"
                        : "border-charcoal-100 bg-white text-charcoal-600"
                    )}
                  >
                    <Icon className="h-5 w-5" aria-hidden />
                    {navLabel(t, item)}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
