"use client";

import { cn } from "@/lib/utils";
import { AlertCircle } from "lucide-react";
import type {
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
  TextareaHTMLAttributes,
} from "react";

const baseField =
  "w-full rounded-xl border bg-white px-3.5 py-2.5 text-sm text-charcoal-900 placeholder:text-charcoal-400 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:bg-charcoal-50";

const okField = "border-charcoal-200 focus:border-forest-500 focus:ring-forest-500";
const errField = "border-red-400 focus:border-red-500 focus:ring-red-500";

export function Label({
  htmlFor,
  children,
  required,
}: {
  htmlFor?: string;
  children: ReactNode;
  required?: boolean;
}) {
  return (
    <label htmlFor={htmlFor} className="mb-1.5 block text-xs font-semibold text-charcoal-700">
      {children}
      {required && <span className="ml-0.5 text-red-500" aria-hidden>*</span>}
    </label>
  );
}

export function FieldError({ children }: { children?: ReactNode }) {
  if (!children) return null;
  return (
    <p className="mt-1.5 flex items-center gap-1 text-xs font-medium text-red-600" role="alert">
      <AlertCircle className="h-3.5 w-3.5 shrink-0" aria-hidden />
      {children}
    </p>
  );
}

export function Field({
  label,
  htmlFor,
  required,
  error,
  hint,
  children,
  className,
}: {
  label?: ReactNode;
  htmlFor?: string;
  required?: boolean;
  error?: string;
  hint?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      {label && (
        <Label htmlFor={htmlFor} required={required}>
          {label}
        </Label>
      )}
      {children}
      {hint && !error && <p className="mt-1.5 text-xs text-charcoal-400">{hint}</p>}
      <FieldError>{error}</FieldError>
    </div>
  );
}

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  error?: string;
}

export function Input({ error, className, ...rest }: InputProps) {
  return (
    <input
      className={cn(baseField, error ? errField : okField, className)}
      aria-invalid={error ? true : undefined}
      {...rest}
    />
  );
}

export interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  error?: string;
}

export function Select({ error, className, children, ...rest }: SelectProps) {
  return (
    <select
      className={cn(baseField, "appearance-none pr-8", error ? errField : okField, className)}
      aria-invalid={error ? true : undefined}
      style={{
        backgroundImage:
          "url(\"data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='none' stroke='%235c665f' stroke-width='2'%3E%3Cpath d='m4 6 4 4 4-4'/%3E%3C/svg%3E\")",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "right 12px center",
      }}
      {...rest}
    >
      {children}
    </select>
  );
}

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  error?: string;
}

export function Textarea({ error, className, ...rest }: TextareaProps) {
  return (
    <textarea
      className={cn(baseField, "min-h-[92px] resize-y", error ? errField : okField, className)}
      aria-invalid={error ? true : undefined}
      {...rest}
    />
  );
}
