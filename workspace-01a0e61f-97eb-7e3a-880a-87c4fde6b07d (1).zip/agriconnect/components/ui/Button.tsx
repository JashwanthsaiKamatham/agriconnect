"use client";

import Link from "next/link";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes, ReactNode } from "react";

export type ButtonVariant =
  | "primary"
  | "secondary"
  | "outline"
  | "ghost"
  | "danger"
  | "sun";

export type ButtonSize = "sm" | "md" | "lg";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  href?: string;
  loading?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  fullWidth?: boolean;
}

const VARIANTS: Record<ButtonVariant, string> = {
  primary:
    "bg-forest-600 text-white hover:bg-forest-700 active:bg-forest-800 shadow-sm disabled:bg-forest-300",
  secondary:
    "bg-earth-600 text-white hover:bg-earth-700 active:bg-earth-800 shadow-sm disabled:bg-earth-300",
  outline:
    "border border-charcoal-200 bg-white text-charcoal-800 hover:border-forest-500 hover:text-forest-700 disabled:text-charcoal-300",
  ghost: "text-charcoal-700 hover:bg-charcoal-100 disabled:text-charcoal-300",
  danger: "bg-red-600 text-white hover:bg-red-700 active:bg-red-800 shadow-sm",
  sun: "bg-sun-400 text-charcoal-900 hover:bg-sun-300 shadow-sm",
};

const SIZES: Record<ButtonSize, string> = {
  sm: "text-sm px-3 py-1.5 gap-1.5 rounded-lg",
  md: "text-sm px-4 py-2.5 gap-2 rounded-xl",
  lg: "text-base px-6 py-3 gap-2 rounded-xl",
};

export default function Button({
  variant = "primary",
  size = "md",
  href,
  loading = false,
  leftIcon,
  rightIcon,
  fullWidth,
  className,
  children,
  disabled,
  onClick,
  type = "button",
  ...rest
}: ButtonProps) {
  const classes = cn(
    "inline-flex items-center justify-center font-semibold transition-colors focus-ring select-none",
    VARIANTS[variant],
    SIZES[size],
    fullWidth && "w-full",
    (disabled || loading) && "opacity-70 cursor-not-allowed",
    className
  );

  const content = (
    <>
      {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : leftIcon}
      {children}
      {!loading && rightIcon}
    </>
  );

  if (href && !disabled && !loading) {
    return (
      <Link
        href={href}
        className={classes}
        onClick={onClick as unknown as React.MouseEventHandler<HTMLAnchorElement>}
      >
        {content}
      </Link>
    );
  }

  return (
    <button type={type} className={classes} disabled={disabled || loading} {...rest}>
      {content}
    </button>
  );
}
