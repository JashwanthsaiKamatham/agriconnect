import type { ReactNode } from "react";
import { TrendingUp, TrendingDown } from "lucide-react";
import { Card } from "./Card";
import { cn } from "@/lib/utils";

const TONES = {
  forest: "bg-forest-50 text-forest-700",
  earth: "bg-earth-100 text-earth-700",
  sun: "bg-sun-100 text-sun-600",
  leaf: "bg-leaf-100 text-leaf-700",
} as const;

export default function StatCard({
  label,
  value,
  sub,
  icon,
  tone = "forest",
  trend,
  demo,
}: {
  label: string;
  value: ReactNode;
  sub?: ReactNode;
  icon: ReactNode;
  tone?: keyof typeof TONES;
  trend?: { dir: "up" | "down"; value: string };
  demo?: boolean;
}) {
  return (
    <Card className="p-4 sm:p-5">
      <div className="flex items-start justify-between gap-2">
        <span className={cn("flex h-10 w-10 items-center justify-center rounded-xl", TONES[tone])}>
          {icon}
        </span>
        {trend && (
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold",
              trend.dir === "up" ? "bg-leaf-100 text-leaf-700" : "bg-red-100 text-red-700"
            )}
          >
            {trend.dir === "up" ? (
              <TrendingUp className="h-3 w-3" aria-hidden />
            ) : (
              <TrendingDown className="h-3 w-3" aria-hidden />
            )}
            {trend.value}
          </span>
        )}
      </div>
      <p className="mt-3 text-xs font-semibold uppercase tracking-wide text-charcoal-500">
        {label}
        {demo && <span className="ml-1.5 normal-case text-sun-600">· demo</span>}
      </p>
      <p className="mt-1 text-xl font-extrabold tracking-tight text-charcoal-900 sm:text-2xl">
        {value}
      </p>
      {sub && <p className="mt-1 text-xs text-charcoal-500">{sub}</p>}
    </Card>
  );
}
