import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export type BadgeVariant =
  | "success"
  | "warning"
  | "danger"
  | "info"
  | "neutral"
  | "earth"
  | "forest";

const VARIANTS: Record<BadgeVariant, string> = {
  success: "bg-leaf-100 text-leaf-800",
  warning: "bg-sun-100 text-sun-600",
  danger: "bg-red-100 text-red-700",
  info: "bg-sky-100 text-sky-800",
  neutral: "bg-charcoal-100 text-charcoal-700",
  earth: "bg-earth-100 text-earth-800",
  forest: "bg-forest-100 text-forest-800",
};

export default function Badge({
  variant = "neutral",
  className,
  children,
  title,
}: {
  variant?: BadgeVariant;
  className?: string;
  children: ReactNode;
  title?: string;
}) {
  return (
    <span
      title={title}
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-semibold whitespace-nowrap",
        VARIANTS[variant],
        className
      )}
    >
      {children}
    </span>
  );
}

/** Small "Demo data" pill used wherever sample data is shown. */
export function DemoBadge({ className }: { className?: string }) {
  return (
    <Badge variant="warning" className={className} title="Sample data for demonstration">
      <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth="2.2" aria-hidden>
        <path d="M9 3h6M10 3v6.3L4.8 18a2 2 0 0 0 1.7 3h11a2 2 0 0 0 1.7-3L14 9.3V3" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      Demo data
    </Badge>
  );
}
