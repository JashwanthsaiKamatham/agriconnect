import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { FileSearch } from "lucide-react";

/** Friendly empty state with optional action. */
export default function EmptyState({
  icon,
  title,
  body,
  action,
  className,
}: {
  icon?: ReactNode;
  title: string;
  body: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-charcoal-200 bg-white px-6 py-12 text-center",
        className
      )}
    >
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-forest-50 text-forest-600">
        {icon ?? <FileSearch className="h-7 w-7" aria-hidden />}
      </span>
      <h3 className="mt-4 text-base font-bold text-charcoal-900">{title}</h3>
      <p className="mt-1.5 max-w-sm text-sm text-charcoal-500">{body}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

/** Full-area loading spinner (used while services "fetch" demo data). */
export function LoadingState({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-charcoal-100 bg-white px-6 py-16 text-center">
      <span className="relative flex h-12 w-12 items-center justify-center">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-forest-300 opacity-40" />
        <span className="relative inline-flex h-9 w-9 items-center justify-center rounded-full bg-forest-600 text-white">
          <svg className="h-5 w-5 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden>
            <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="3" opacity="0.3" />
            <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          </svg>
        </span>
      </span>
      <p className="mt-4 text-sm font-semibold text-charcoal-600">{label}</p>
    </div>
  );
}

/** Small inline progress bar. */
export function ProgressBar({
  percent,
  colorClass = "bg-forest-600",
  trackClass = "bg-charcoal-100",
  className,
  label,
}: {
  percent: number;
  colorClass?: string;
  trackClass?: string;
  className?: string;
  label?: string;
}) {
  return (
    <div
      className={cn("h-2 w-full overflow-hidden rounded-full", trackClass, className)}
      role="progressbar"
      aria-valuenow={Math.round(percent)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label}
    >
      <div
        className={cn("h-full rounded-full transition-all duration-500", colorClass)}
        style={{ width: `${Math.min(100, Math.max(0, percent))}%` }}
      />
    </div>
  );
}
