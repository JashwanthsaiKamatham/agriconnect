"use client";

import {
  CheckCircle2,
  Info,
  AlertTriangle,
  XCircle,
  X,
} from "lucide-react";
import { useApp } from "@/lib/context/AppContext";
import { cn } from "@/lib/utils";

const ICONS = {
  success: CheckCircle2,
  error: XCircle,
  warning: AlertTriangle,
  info: Info,
} as const;

const TONES: Record<string, string> = {
  success: "text-leaf-600",
  error: "text-red-600",
  warning: "text-sun-500",
  info: "text-sky-600",
};

/** Global toast stack, rendered once inside AppProvider. */
export default function Toaster() {
  const { toasts, dismissToast } = useApp();

  return (
    <div
      aria-live="polite"
      aria-label="Notifications"
      className="pointer-events-none fixed inset-x-4 bottom-24 z-[80] flex flex-col items-center gap-2 sm:inset-x-auto sm:bottom-5 sm:right-5 sm:items-end"
    >
      {toasts.map((t) => {
        const Icon = ICONS[t.type];
        return (
          <div
            key={t.id}
            role="status"
            className={cn(
              "pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-2xl border border-charcoal-100 bg-white px-4 py-3 shadow-lift animate-fade-in-up"
            )}
          >
            <Icon className={cn("mt-0.5 h-5 w-5 shrink-0", TONES[t.type])} aria-hidden />
            <p className="flex-1 text-sm font-medium text-charcoal-800">{t.message}</p>
            <button
              type="button"
              onClick={() => dismissToast(t.id)}
              aria-label="Dismiss notification"
              className="focus-ring rounded-full p-1 text-charcoal-400 hover:bg-charcoal-100 hover:text-charcoal-700"
            >
              <X className="h-4 w-4" aria-hidden />
            </button>
          </div>
        );
      })}
    </div>
  );
}
