import type { ReactNode } from "react";

/** Consistent page heading block used across dashboard pages. */
export default function PageHeader({
  title,
  subtitle,
  actions,
  demoNote,
}: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  demoNote?: string;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h2 className="text-xl font-extrabold tracking-tight text-charcoal-900 sm:text-2xl">{title}</h2>
        {subtitle && <p className="mt-1 max-w-2xl text-sm text-charcoal-500">{subtitle}</p>}
        {demoNote && <p className="mt-1 text-xs font-medium text-sun-600">{demoNote}</p>}
      </div>
      {actions && <div className="flex shrink-0 flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}
