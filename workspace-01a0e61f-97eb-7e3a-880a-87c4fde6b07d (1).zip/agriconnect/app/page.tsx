import LandingHeader from "@/components/landing/LandingHeader";
import Hero from "@/components/landing/Hero";
import { Benefits, Features, HowItWorks, Roles } from "@/components/landing/Sections";
import { CTABanner, Testimonials } from "@/components/landing/Testimonials";
import Footer from "@/components/landing/Footer";

export default function LandingPage() {
  return (
    <div className="bg-beige-50">
      <LandingHeader />
      <main>
        <Hero />
        <Features />
        <Roles />
        <HowItWorks />
        <Benefits />
        <Testimonials />
        <CTABanner />
      </main>
      <Footer />
    </div>
  );
}
