import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AppProvider } from "@/lib/context/AppContext";
import Toaster from "@/components/ui/Toaster";

export const metadata: Metadata = {
  title: {
    default: "AgriConnect — Digital Agriculture Platform",
    template: "%s | AgriConnect",
  },
  description:
    "AgriConnect connects Indian farmers directly with buyers, agri experts, equipment suppliers, logistics and government schemes. Grow smarter. Sell better.",
  keywords: ["agriculture", "India", "farmers", "mandi prices", "marketplace", "agritech"],
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#31704c",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AppProvider>
          {children}
          <Toaster />
        </AppProvider>
      </body>
    </html>
  );
}
