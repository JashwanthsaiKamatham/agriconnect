"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import {
  Bell,
  Globe,
  KeyRound,
  Leaf,
  Lock,
  LogOut,
  Save,
  ShieldCheck,
  Trash2,
  UserRound,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import Avatar from "@/components/ui/Avatar";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import Modal from "@/components/ui/Modal";
import { Field, Input, Select } from "@/components/ui/Form";
import { ToggleRow } from "@/components/ui/Toggle";
import LanguageSelector from "@/components/layout/LanguageSelector";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { LANGUAGES } from "@/lib/i18n/translations";
import type { AreaUnit, IrrigationType, SoilType } from "@/lib/types";
import { cn } from "@/lib/utils";

export default function ProfilePage() {
  usePageTitle("Profile & Settings");
  const router = useRouter();
  const { user, updateUser, setLang, lang, logout, toast, t } = useApp();

  /* profile + farm forms */
  const [profile, setProfile] = useState({
    name: user?.name ?? "",
    phone: user?.phone ?? "",
    email: user?.email ?? "",
  });
  const [farm, setFarm] = useState({
    village: user?.farm?.village ?? "",
    district: user?.farm?.district ?? "",
    state: user?.farm?.state ?? "Andhra Pradesh",
    pincode: user?.farm?.pincode ?? "",
    area: user?.farm?.area?.toString() ?? "",
    areaUnit: user?.farm?.areaUnit ?? "acres",
    soilType: user?.farm?.soilType ?? "Black",
    irrigationType: user?.farm?.irrigationType ?? "Borewell",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  /* notification & privacy settings (local demo state) */
  const [notif, setNotif] = useState({ sms: true, whatsapp: true, push: true, email: false, market: true, weather: true });
  const [privacy, setPrivacy] = useState({ location: true, listings: true, analytics: false });

  /* password form */
  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  const [pwErrors, setPwErrors] = useState<Record<string, string>>({});

  /* dialogs */
  const [logoutOpen, setLogoutOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);

  const saveProfile = (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!profile.name.trim()) errs.name = "Name is required";
    if (profile.phone && !/^(\+91[\s-]?)?[6-9]\d{9}$/.test(profile.phone.replace(/[\s-]/g, "")))
      errs.phone = "Enter a valid 10-digit mobile number";
    if (profile.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(profile.email))
      errs.email = "Enter a valid email address";
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    updateUser({ name: profile.name.trim(), phone: profile.phone, email: profile.email });
    toast("Profile updated.", "success");
  };

  const saveFarm = (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!farm.village.trim()) errs.village = "Village is required";
    if (!farm.district.trim()) errs.district = "District is required";
    if (!/^\d{6}$/.test(farm.pincode)) errs.pincode = "Enter a valid 6-digit PIN code";
    if (!farm.area || Number(farm.area) <= 0) errs.area = "Enter land area";
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    updateUser({
      farm: {
        ...user?.farm,
        village: farm.village.trim(),
        district: farm.district.trim(),
        state: farm.state,
        pincode: farm.pincode,
        area: Number(farm.area),
        areaUnit: farm.areaUnit,
        soilType: farm.soilType,
        irrigationType: farm.irrigationType,
      },
    });
    toast("Farm details updated.", "success");
  };

  const changePassword = (e: FormEvent) => {
    e.preventDefault();
    const errs: Record<string, string> = {};
    if (!pw.current) errs.current = "Enter your current password";
    if (pw.next.length < 8) errs.next = "Use at least 8 characters";
    if (pw.confirm !== pw.next) errs.confirm = "Passwords do not match";
    setPwErrors(errs);
    if (Object.keys(errs).length > 0) return;
    setPw({ current: "", next: "", confirm: "" });
    toast("Password changed (demo).", "success");
  };

  const doLogout = () => {
    logout();
    setLogoutOpen(false);
    router.push("/");
  };

  return (
    <div className="animate-fade-in max-w-4xl">
      <PageHeader
        title={t("nav.profile")}
        subtitle="Manage your profile, farm, language, notifications and account."
      />

      <div className="grid gap-5">
        {/* Profile card */}
        <Card>
          <CardHeader title="Profile information" icon={<UserRound className="h-5 w-5" aria-hidden />} />
          <form onSubmit={saveProfile} className="px-5 pb-5">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
              <div className="flex items-center gap-4">
                <Avatar name={profile.name || "F"} size="xl" />
                <div>
                  <p className="text-base font-extrabold text-charcoal-900">{user?.name}</p>
                  <Badge variant="forest" className="mt-1 capitalize">{user?.role}</Badge>
                  <p className="mt-1 text-[11px] font-medium text-charcoal-400">
                    Member since {user?.createdAt}
                  </p>
                </div>
              </div>
            </div>
            <div className="mt-5 grid gap-4 sm:grid-cols-3">
              <Field label="Full name" htmlFor="pf-name" required error={errors.name}>
                <Input id="pf-name" value={profile.name} onChange={(e) => setProfile((p) => ({ ...p, name: e.target.value }))} error={errors.name} />
              </Field>
              <Field label="Mobile number" htmlFor="pf-phone" error={errors.phone}>
                <Input id="pf-phone" type="tel" value={profile.phone} onChange={(e) => setProfile((p) => ({ ...p, phone: e.target.value }))} error={errors.phone} />
              </Field>
              <Field label="Email" htmlFor="pf-email" error={errors.email}>
                <Input id="pf-email" type="email" value={profile.email} onChange={(e) => setProfile((p) => ({ ...p, email: e.target.value }))} error={errors.email} />
              </Field>
            </div>
            <div className="mt-4 flex justify-end">
              <Button type="submit" leftIcon={<Save className="h-4 w-4" aria-hidden />}>
                {t("common.saveChanges")}
              </Button>
            </div>
          </form>
        </Card>

        {/* Farm card */}
        <Card>
          <CardHeader title="Farm information" subtitle="Used for weather, advisories and listings" icon={<Leaf className="h-5 w-5" aria-hidden />} />
          <form onSubmit={saveFarm} className="px-5 pb-5">
            <div className="grid gap-4 sm:grid-cols-4">
              <Field label="Village" htmlFor="fm-village" required error={errors.village} className="sm:col-span-2">
                <Input id="fm-village" value={farm.village} onChange={(e) => setFarm((f) => ({ ...f, village: e.target.value }))} error={errors.village} />
              </Field>
              <Field label="District" htmlFor="fm-district" required error={errors.district}>
                <Input id="fm-district" value={farm.district} onChange={(e) => setFarm((f) => ({ ...f, district: e.target.value }))} error={errors.district} />
              </Field>
              <Field label="State" htmlFor="fm-state">
                <Select id="fm-state" value={farm.state} onChange={(e) => setFarm((f) => ({ ...f, state: e.target.value }))}>
                  <option>Andhra Pradesh</option>
                  <option>Telangana</option>
                  <option>Karnataka</option>
                  <option>Tamil Nadu</option>
                  <option>Maharashtra</option>
                </Select>
              </Field>
              <Field label="PIN code" htmlFor="fm-pin" required error={errors.pincode}>
                <Input id="fm-pin" maxLength={6} value={farm.pincode} onChange={(e) => setFarm((f) => ({ ...f, pincode: e.target.value }))} error={errors.pincode} />
              </Field>
              <Field label="Land area" htmlFor="fm-area" required error={errors.area}>
                <Input id="fm-area" type="number" min="0" step="0.1" value={farm.area} onChange={(e) => setFarm((f) => ({ ...f, area: e.target.value }))} error={errors.area} />
              </Field>
              <Field label="Unit" htmlFor="fm-unit">
                <Select id="fm-unit" value={farm.areaUnit} onChange={(e) => setFarm((f) => ({ ...f, areaUnit: e.target.value as AreaUnit }))}>
                  <option value="acres">Acres</option>
                  <option value="hectares">Hectares</option>
                </Select>
              </Field>
              <Field label="Soil type" htmlFor="fm-soil">
                <Select id="fm-soil" value={farm.soilType} onChange={(e) => setFarm((f) => ({ ...f, soilType: e.target.value as SoilType }))}>
                  {["Black", "Red", "Alluvial", "Sandy loam", "Loamy", "Laterite"].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </Select>
              </Field>
              <Field label="Irrigation type" htmlFor="fm-irr" className="sm:col-span-2">
                <Select id="fm-irr" value={farm.irrigationType} onChange={(e) => setFarm((f) => ({ ...f, irrigationType: e.target.value as IrrigationType }))}>
                  {["Rain-fed", "Canal", "Borewell", "Drip", "Sprinkler", "Flood"].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </Select>
              </Field>
            </div>
            <div className="mt-4 flex justify-end">
              <Button type="submit" leftIcon={<Save className="h-4 w-4" aria-hidden />}>
                {t("common.saveChanges")}
              </Button>
            </div>
          </form>
        </Card>

        {/* Language + notifications */}
        <div className="grid gap-5 md:grid-cols-2">
          <Card>
            <CardHeader title="Language" subtitle="App interface language" icon={<Globe className="h-5 w-5" aria-hidden />} />
            <div className="flex items-center justify-between px-5 pb-5">
              <Select
                value={lang}
                onChange={(e) => {
                  setLang(e.target.value as typeof lang);
                  toast("Language updated.", "success");
                }}
                aria-label="Interface language"
                className="max-w-[220px]"
              >
                {LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.native} ({l.label})
                  </option>
                ))}
              </Select>
              <LanguageSelector />
            </div>
          </Card>

          <Card>
            <CardHeader title="Notification settings" icon={<Bell className="h-5 w-5" aria-hidden />} />
            <div className="divide-y divide-charcoal-50 px-5 pb-3">
              <ToggleRow title="SMS alerts" description="Weather warnings and price alerts" checked={notif.sms} onChange={(v) => setNotif((n) => ({ ...n, sms: v }))} />
              <ToggleRow title="WhatsApp updates" description="Advisories and booking updates" checked={notif.whatsapp} onChange={(v) => setNotif((n) => ({ ...n, whatsapp: v }))} />
              <ToggleRow title="Push notifications" description="On this device" checked={notif.push} onChange={(v) => setNotif((n) => ({ ...n, push: v }))} />
              <ToggleRow title="Weekly market digest" description="Every Sunday, 8 AM" checked={notif.email} onChange={(v) => setNotif((n) => ({ ...n, email: v }))} />
            </div>
          </Card>
        </div>

        {/* Privacy + password */}
        <div className="grid gap-5 md:grid-cols-2">
          <Card>
            <CardHeader title="Privacy settings" icon={<ShieldCheck className="h-5 w-5" aria-hidden />} />
            <div className="divide-y divide-charcoal-50 px-5 pb-3">
              <ToggleRow title="Show farm location" description="Buyers see village & district" checked={privacy.location} onChange={(v) => setPrivacy((p) => ({ ...p, location: v }))} />
              <ToggleRow title="Public listings" description="Anyone on AgriConnect can view your produce listings" checked={privacy.listings} onChange={(v) => setPrivacy((p) => ({ ...p, listings: v }))} />
              <ToggleRow title="Share usage analytics" description="Help improve advisories (anonymous)" checked={privacy.analytics} onChange={(v) => setPrivacy((p) => ({ ...p, analytics: v }))} />
            </div>
          </Card>

          <Card>
            <CardHeader title="Change password" icon={<KeyRound className="h-5 w-5" aria-hidden />} />
            <form onSubmit={changePassword} className="space-y-4 px-5 pb-5">
              <Field label="Current password" htmlFor="pw-current" required error={pwErrors.current}>
                <Input id="pw-current" type="password" value={pw.current} onChange={(e) => setPw((p) => ({ ...p, current: e.target.value }))} error={pwErrors.current} autoComplete="current-password" />
              </Field>
              <Field label="New password" htmlFor="pw-next" required error={pwErrors.next} hint="8+ characters">
                <Input id="pw-next" type="password" value={pw.next} onChange={(e) => setPw((p) => ({ ...p, next: e.target.value }))} error={pwErrors.next} autoComplete="new-password" />
              </Field>
              <Field label="Confirm new password" htmlFor="pw-confirm" required error={pwErrors.confirm}>
                <Input id="pw-confirm" type="password" value={pw.confirm} onChange={(e) => setPw((p) => ({ ...p, confirm: e.target.value }))} error={pwErrors.confirm} autoComplete="new-password" />
              </Field>
              <Button type="submit" variant="outline" fullWidth leftIcon={<Lock className="h-4 w-4" aria-hidden />}>
                Update password
              </Button>
            </form>
          </Card>
        </div>

        {/* Danger zone */}
        <Card className="border-red-100">
          <CardHeader title="Account actions" subtitle="These affect your demo profile on this device" icon={<Trash2 className="h-5 w-5" aria-hidden />} />
          <div className="flex flex-col gap-3 px-5 pb-5 sm:flex-row">
            <Button variant="outline" onClick={() => setLogoutOpen(true)} leftIcon={<LogOut className="h-4 w-4" aria-hidden />}>
              {t("common.logout")}
            </Button>
            <Button variant="danger" onClick={() => setDeleteOpen(true)} leftIcon={<Trash2 className="h-4 w-4" aria-hidden />}>
              Delete account
            </Button>
          </div>
        </Card>
      </div>

      {/* Logout confirm */}
      <Modal
        open={logoutOpen}
        onClose={() => setLogoutOpen(false)}
        title="Log out?"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setLogoutOpen(false)}>
              {t("common.cancel")}
            </Button>
            <Button variant="danger" onClick={doLogout}>
              {t("common.logout")}
            </Button>
          </div>
        }
      >
        <p className="text-sm leading-relaxed text-charcoal-600">
          You&apos;ll return to the home page. Your crops, listings and settings stay saved on this
          device.
        </p>
      </Modal>

      {/* Delete confirm */}
      <Modal
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        title="Delete account?"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleteOpen(false)}>
              Keep my account
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                setDeleteOpen(false);
                toast("Account deletion is disabled in this demo build.", "warning");
              }}
            >
              Delete forever
            </Button>
          </div>
        }
      >
        <div className="flex items-start gap-3">
          <span className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-100 text-red-600")}>
            <Trash2 className="h-5 w-5" aria-hidden />
          </span>
          <p className="text-sm leading-relaxed text-charcoal-600">
            This removes your profile, crops, listings and bookings permanently. In production you
            would receive a confirmation call from +91 80080 12345 before deletion.
          </p>
        </div>
      </Modal>
    </div>
  );
}
