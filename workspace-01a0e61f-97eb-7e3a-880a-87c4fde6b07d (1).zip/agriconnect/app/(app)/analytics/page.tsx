"use client";

import { useMemo, useState } from "react";
import { Download, Filter, IndianRupee, PiggyBank, Percent, Wallet } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import StatCard from "@/components/ui/StatCard";
import Badge, { DemoBadge } from "@/components/ui/Badge";
import { Select } from "@/components/ui/Form";
import Button from "@/components/ui/Button";
import {
  ProfitChart,
  RevenueAreaChart,
  SimpleBarChart,
  SimpleLineChart,
} from "@/components/charts/Charts";
import ChartFrame from "@/components/charts/ChartFrame";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import {
  expenseBreakdown,
  fertilizerUsage,
  healthTrend,
  monthlyExpenses,
  monthlyRevenue,
  waterUsage,
} from "@/lib/data/analytics";
import { marketPrices } from "@/lib/data/market";
import { cropEmoji } from "@/lib/utils";

const PERIODS = [
  { value: "6", label: "Last 6 months" },
  { value: "12", label: "Last 12 months" },
] as const;

export default function AnalyticsPage() {
  usePageTitle("Farm Analytics");
  const { crops, toast } = useApp();

  const [period, setPeriod] = useState<"6" | "12">("6");
  const [cropFilter, setCropFilter] = useState("all");
  const [priceCrop, setPriceCrop] = useState(marketPrices[3].id);

  const months = period === "6" ? 6 : 12;

  const revenue = useMemo(() => monthlyRevenue.slice(-months), [months]);
  const expenses = useMemo(() => monthlyExpenses.slice(-months), [months]);

  const profit = useMemo(
    () =>
      revenue.map((r, i) => ({
        month: r.month,
        revenue: r.revenue,
        expenses: expenses[i]?.expenses ?? 0,
        profit: r.revenue - (expenses[i]?.expenses ?? 0),
      })),
    [revenue, expenses]
  );

  const totals = useMemo(() => {
    const rev = revenue.reduce((s, r) => s + r.revenue, 0) * 1000;
    const exp = expenses.reduce((s, r) => s + r.expenses, 0) * 1000;
    return { rev, exp, profit: rev - exp, margin: rev > 0 ? Math.round(((rev - exp) / rev) * 100) : 0 };
  }, [revenue, expenses]);

  const yieldByCrop = useMemo(
    () =>
      (cropFilter === "all" ? crops : crops.filter((c) => c.name === cropFilter)).map((c) => ({
        crop: c.name,
        yield: c.estimatedYield,
      })),
    [crops, cropFilter]
  );

  const selectedPrice = marketPrices.find((p) => p.id === priceCrop) ?? marketPrices[0];
  const priceData = selectedPrice.history.slice(-30).map((v, i) => ({ day: `D${i + 1}`, price: v }));

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Farm Analytics"
        subtitle="Understand yield, costs, water and profit — season over season."
        demoNote="All figures are sample data for the demo farm."
        actions={
          <>
            <Select
              value={period}
              onChange={(e) => setPeriod(e.target.value as "6" | "12")}
              aria-label="Date range"
              className="w-40"
            >
              {PERIODS.map((p) => (
                <option key={p.value} value={p.value}>
                  {p.label}
                </option>
              ))}
            </Select>
            <Select
              value={cropFilter}
              onChange={(e) => setCropFilter(e.target.value)}
              aria-label="Crop filter"
              className="w-40"
            >
              <option value="all">All crops</option>
              {crops.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </Select>
            <Button
              variant="outline"
              leftIcon={<Download className="h-4 w-4" aria-hidden />}
              onClick={() => toast("Report download is a UI demo — PDF export arrives with live data.", "info")}
            >
              Download report
            </Button>
          </>
        }
      />

      {/* KPIs */}
      <section className="mb-6 grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <StatCard label="Total revenue" value={`₹${(totals.rev / 100000).toFixed(1)} L`} icon={<IndianRupee className="h-5 w-5" aria-hidden />} tone="forest" trend={{ dir: "up", value: "+18%" }} />
        <StatCard label="Total expenses" value={`₹${(totals.exp / 100000).toFixed(1)} L`} icon={<Wallet className="h-5 w-5" aria-hidden />} tone="earth" trend={{ dir: "down", value: "-6%" }} />
        <StatCard label="Net profit" value={`₹${(totals.profit / 100000).toFixed(1)} L`} icon={<PiggyBank className="h-5 w-5" aria-hidden />} tone="leaf" trend={{ dir: "up", value: "+24%" }} />
        <StatCard label="Profit margin" value={`${totals.margin}%`} icon={<Percent className="h-5 w-5" aria-hidden />} tone="sun" demo />
      </section>

      {/* Charts */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Monthly revenue" subtitle={`Last ${months} months · ₹ thousands`} action={<DemoBadge />} />
          <div className="px-3 pb-4">
              <ChartFrame minWidth={540} label="Monthly revenue chart">
                <RevenueAreaChart data={revenue as unknown as Array<Record<string, string | number>>} />
              </ChartFrame>
            </div>
        </Card>

        <Card>
          <CardHeader title="Monthly expenses" subtitle={`Last ${months} months · ₹ thousands`} action={<DemoBadge />} />
          <div className="px-3 pb-4">
              <ChartFrame minWidth={540} label="Monthly expenses chart">
                <SimpleBarChart
                  data={expenses as unknown as Array<Record<string, string | number>>}
                  xKey="month"
                  yKey="expenses"
                  color="#b0825c"
                  tooltipLabel="Expenses ₹K"
                />
              </ChartFrame>
            </div>
        </Card>

        <Card>
          <CardHeader title="Profit estimate" subtitle="Revenue vs expenses vs profit" action={<DemoBadge />} />
          <div className="px-3 pb-4">
              <ChartFrame minWidth={560} label="Profit estimate chart">
                <ProfitChart data={profit as unknown as Array<Record<string, string | number>>} />
              </ChartFrame>
            </div>
        </Card>

        <Card>
          <CardHeader
            title="Crop-wise yield"
            subtitle="Estimated tonnes this season"
            icon={<Filter className="h-5 w-5" aria-hidden />}
            action={<Badge variant="neutral">{yieldByCrop.length} crops</Badge>}
          />
          <div className="px-3 pb-4">
            {yieldByCrop.length > 0 ? (
              <ChartFrame minWidth={520} label="Crop-wise yield chart">
                <SimpleBarChart
                  data={yieldByCrop as unknown as Array<Record<string, string | number>>}
                  xKey="crop"
                  yKey="yield"
                  color="#31704c"
                  tooltipLabel="Tonnes"
                />
              </ChartFrame>
            ) : (
              <p className="py-16 text-center text-sm text-charcoal-400">No crops match this filter</p>
            )}
          </div>
        </Card>

        <Card>
          <CardHeader title="Water usage" subtitle="Kilolitres per month · all plots" action={<DemoBadge />} />
          <div className="px-3 pb-4">
              <ChartFrame minWidth={480} label="Water usage chart">
                <SimpleBarChart
                  data={waterUsage as unknown as Array<Record<string, string | number>>}
                  xKey="label"
                  yKey="usage"
                  color="#0284c7"
                  tooltipLabel="kL"
                />
              </ChartFrame>
            </div>
        </Card>

        <Card>
          <CardHeader title="Fertilizer usage" subtitle="Kilograms of NPK per month" action={<DemoBadge />} />
          <div className="px-3 pb-4">
              <ChartFrame minWidth={480} label="Fertilizer usage chart">
                <SimpleBarChart
                  data={fertilizerUsage as unknown as Array<Record<string, string | number>>}
                  xKey="label"
                  yKey="usage"
                  color="#d99e1b"
                  tooltipLabel="kg"
                />
              </ChartFrame>
            </div>
        </Card>

        <Card>
          <CardHeader title="Crop health trend" subtitle="Weekly field health index (0–100)" action={<DemoBadge />} />
          <div className="px-3 pb-4">
              <ChartFrame minWidth={480} label="Crop health trend chart">
                <SimpleLineChart
                  data={healthTrend as unknown as Array<Record<string, string | number>>}
                  xKey="week"
                  yKey="health"
                  color="#16a34a"
                  tooltipLabel="Health index"
                />
              </ChartFrame>
            </div>
        </Card>

        <Card>
          <CardHeader
            title="Market price trend"
            subtitle={`${selectedPrice.crop} · ₹ per quintal (30 days)`}
            action={
              <Select value={priceCrop} onChange={(e) => setPriceCrop(e.target.value)} aria-label="Choose crop for price trend" className="!w-40 !py-1.5 text-xs">
                {marketPrices.map((p) => (
                  <option key={p.id} value={p.id}>
                    {cropEmoji(p.crop)} {p.crop}
                  </option>
                ))}
              </Select>
            }
          />
          <div className="px-3 pb-4">
              <ChartFrame minWidth={560} label="Market price trend chart">
                <SimpleLineChart
                  data={priceData}
                  xKey="day"
                  yKey="price"
                  color="#31704c"
                  tooltipLabel={`${selectedPrice.crop} ₹/q`}
                  yFmt={(v) => `₹${Math.round(v)}`}
                />
              </ChartFrame>
            </div>
        </Card>
      </div>

      {/* Expense breakdown */}
      <Card className="mt-4">
        <CardHeader title="Where your money goes" subtitle="Share of seasonal expenses" action={<DemoBadge />} />
        <ul className="grid gap-3 px-5 pb-5 sm:grid-cols-3 lg:grid-cols-6">
          {expenseBreakdown.map((e, i) => (
            <li key={e.name} className="rounded-2xl bg-beige-100 p-3.5 text-center">
              <p className="text-xl font-extrabold text-charcoal-900">{e.value}%</p>
              <p className="mt-0.5 text-[11px] font-bold text-charcoal-500">{e.name}</p>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white">
                <div
                  className={`h-full rounded-full ${
                    ["bg-forest-600", "bg-earth-500", "bg-sun-400", "bg-leaf-500", "bg-sky-500", "bg-charcoal-400"][i]
                  }`}
                  style={{ width: `${e.value * 3}%` }}
                />
              </div>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
