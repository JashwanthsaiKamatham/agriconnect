"use client";

import { useState, type FormEvent } from "react";
import {
  ArrowRight,
  Check,
  MapPin,
  Package,
  Phone,
  Star,
  Truck,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import { Field, Input, Select } from "@/components/ui/Form";
import EmptyState from "@/components/ui/Feedback";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { logisticsProviders } from "@/lib/data/logistics";
import type { Shipment, ShipmentStatus } from "@/lib/types";
import { cn, formatDate } from "@/lib/utils";

const GOODS_TYPES = ["Vegetables", "Fruits", "Grains (Paddy/Wheat/Maize)", "Cotton / Kapas", "Onion / Potato", "Chilli / Spices", "Other produce"];

export default function LogisticsPage() {
  usePageTitle("Logistics");
  const { shipments, addShipment, toast, user } = useApp();

  const [form, setForm] = useState({
    pickup: user?.farm ? `${user.farm.village}, ${user.farm.district}` : "",
    drop: "",
    goods: GOODS_TYPES[0],
    quantity: "",
    date: "",
    vehicle: "Any (cheapest)",
    contactName: user?.name ?? "",
    contactPhone: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    setErrors((er) => ({ ...er, [key]: "" }));
  };

  const requestQuote = (provider: string) => {
    setForm((f) => ({ ...f, vehicle: provider }));
    document.getElementById("logistics-request-form")?.scrollIntoView({ behavior: "smooth" });
    toast(`${provider} selected — complete the request form.`, "info");
  };

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    const e: Record<string, string> = {};
    if (!form.pickup.trim()) e.pickup = "Pickup location is required";
    if (!form.drop.trim()) e.drop = "Delivery location is required";
    if (!form.quantity.trim()) e.quantity = "Quantity is required";
    if (!form.date) e.date = "Preferred date is required";
    if (!/^(\+91[\s-]?)?[6-9]\d{9}$/.test(form.contactPhone.replace(/[\s-]/g, "")))
      e.contactPhone = "Enter a valid 10-digit mobile number";
    setErrors(e);
    if (Object.keys(e).length > 0) return;
    setSaving(true);
    await new Promise((r) => setTimeout(r, 750));
    addShipment({
      goods: form.goods,
      quantity: form.quantity.trim(),
      pickup: form.pickup.trim(),
      drop: form.drop.trim(),
      date: form.date,
      eta: "Within 24 hours of pickup",
      vehicle: form.vehicle !== "Any (cheapest)" ? form.vehicle : undefined,
    });
    setSaving(false);
    toast("Transport request created! Providers are being notified.", "success");
    setForm((f) => ({ ...f, drop: "", quantity: "", date: "" }));
  };

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Logistics"
        subtitle="Move produce from your farm to any market — tracked at every step."
        demoNote="Demo providers and shipments with sample rates."
      />

      <div className="grid gap-5 lg:grid-cols-[1.15fr_1fr]">
        {/* Left column: providers + request form */}
        <div className="space-y-5">
          <Card>
            <CardHeader title="Logistics providers" subtitle="Verified fleets serving your district" icon={<Truck className="h-5 w-5" aria-hidden />} />
            <ul className="space-y-3 px-5 pb-5">
              {logisticsProviders.map((p) => (
                <li key={p.id} className="rounded-2xl border border-charcoal-100 p-4 transition-colors hover:border-forest-200">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="text-sm font-extrabold text-charcoal-900">{p.name}</h3>
                        <Badge variant={p.available ? "success" : "neutral"}>
                          {p.available ? "Available" : "On trip"}
                        </Badge>
                      </div>
                      <p className="mt-0.5 text-xs font-semibold text-charcoal-600">
                        {p.vehicle} · {p.capacity}
                      </p>
                      <p className="mt-1 text-[11px] font-medium text-charcoal-400">
                        Serves: {p.serviceArea.join(" · ")}
                      </p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="flex items-center justify-end gap-1 text-sm font-extrabold text-charcoal-900">
                        <Star className="h-3.5 w-3.5 fill-sun-400 text-sun-400" aria-hidden />
                        {p.rating}
                      </p>
                      <p className="text-xs font-extrabold text-forest-700">{p.priceEstimate}</p>
                      <p className="text-[10px] font-semibold text-charcoal-400">{p.trips} trips</p>
                    </div>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button
                      size="sm"
                      fullWidth
                      disabled={!p.available}
                      onClick={() => requestQuote(p.name)}
                    >
                      Request quote
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      aria-label={`Call ${p.name}`}
                      onClick={() => toast("Calling is disabled in the demo.", "info")}
                    >
                      <Phone className="h-4 w-4" aria-hidden />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          </Card>

          <Card>
            <CardHeader id-="x" title="Request transport" subtitle="Get quotes from up to 3 providers" icon={<Package className="h-5 w-5" aria-hidden />} />
            <form id="logistics-request-form" onSubmit={submit} noValidate className="space-y-4 px-5 pb-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Pickup location" htmlFor="lg-pickup" required error={errors.pickup}>
                  <Input id="lg-pickup" value={form.pickup} onChange={set("pickup")} error={errors.pickup} placeholder="Village, district" />
                </Field>
                <Field label="Delivery location" htmlFor="lg-drop" required error={errors.drop}>
                  <Input id="lg-drop" value={form.drop} onChange={set("drop")} error={errors.drop} placeholder="Market / warehouse city" />
                </Field>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Crop or goods type" htmlFor="lg-goods">
                  <Select id="lg-goods" value={form.goods} onChange={set("goods")}>
                    {GOODS_TYPES.map((g) => (
                      <option key={g}>{g}</option>
                    ))}
                  </Select>
                </Field>
                <Field label="Quantity" htmlFor="lg-qty" required error={errors.quantity}>
                  <Input id="lg-qty" value={form.quantity} onChange={set("quantity")} error={errors.quantity} placeholder="e.g. 12 tonnes / 40 quintals" />
                </Field>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Preferred date" htmlFor="lg-date" required error={errors.date}>
                  <Input id="lg-date" type="date" value={form.date} onChange={set("date")} error={errors.date} />
                </Field>
                <Field label="Vehicle requirement" htmlFor="lg-vehicle">
                  <Select id="lg-vehicle" value={form.vehicle} onChange={set("vehicle")}>
                    <option>Any (cheapest)</option>
                    <option>Tractor-trolley (≤5 t)</option>
                    <option>Mini truck (≤3 t)</option>
                    <option>Covered truck (7–10 t)</option>
                    <option>Reefer / cold chain</option>
                    {logisticsProviders.map((p) => (
                      <option key={p.id}>{p.name}</option>
                    ))}
                  </Select>
                </Field>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Contact name" htmlFor="lg-name">
                  <Input id="lg-name" value={form.contactName} onChange={set("contactName")} />
                </Field>
                <Field label="Contact mobile" htmlFor="lg-phone" required error={errors.contactPhone}>
                  <Input id="lg-phone" type="tel" value={form.contactPhone} onChange={set("contactPhone")} error={errors.contactPhone} placeholder="98480 11223" />
                </Field>
              </div>
              <Button type="submit" fullWidth size="lg" loading={saving} rightIcon={<ArrowRight className="h-4 w-4" aria-hidden />}>
                Request transport
              </Button>
            </form>
          </Card>
        </div>

        {/* Right column: tracking */}
        <div>
          <Card className="lg:sticky lg:top-24">
            <CardHeader title="Shipment tracking" subtitle={`${shipments.length} shipments`} icon={<MapPin className="h-5 w-5" aria-hidden />} />
            {shipments.length === 0 ? (
              <div className="px-5 pb-6">
                <EmptyState
                  icon={<Truck className="h-7 w-7" aria-hidden />}
                  title="No shipments yet"
                  body="Request transport above and track every step here."
                  className="border-0 bg-beige-50"
                />
              </div>
            ) : (
              <ul className="space-y-4 px-5 pb-5">
                {shipments.map((s) => (
                  <ShipmentCard key={s.id} shipment={s} />
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

function ShipmentCard({ shipment }: { shipment: Shipment }) {
  const currentIdx = shipment.updates.filter((u) => u.done).length - 1;
  const delivered = shipment.status === "Delivered";
  return (
    <li className="rounded-2xl border border-charcoal-100 p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="flex items-center gap-2 text-sm font-extrabold text-charcoal-900">
            {shipment.id}
            <Badge variant={delivered ? "success" : "warning"}>{shipment.status}</Badge>
          </p>
          <p className="mt-0.5 text-xs font-semibold text-charcoal-600">
            {shipment.goods} · {shipment.quantity}
          </p>
        </div>
        <p className="shrink-0 text-[11px] font-bold text-charcoal-400">{formatDate(shipment.date)}</p>
      </div>

      <div className="mt-2.5 flex items-center gap-2 rounded-xl bg-beige-100 px-3 py-2 text-xs font-semibold text-charcoal-700">
        <MapPin className="h-3.5 w-3.5 shrink-0 text-forest-600" aria-hidden />
        <span className="truncate">{shipment.pickup}</span>
        <ArrowRight className="h-3.5 w-3.5 shrink-0 text-charcoal-400" aria-hidden />
        <span className="truncate">{shipment.drop}</span>
      </div>

      {shipment.provider && (
        <p className="mt-2 text-[11px] font-bold text-charcoal-500">
          {shipment.provider}
          {shipment.vehicle && <span className="font-semibold text-charcoal-400"> · {shipment.vehicle}</span>}
        </p>
      )}

      {/* Status timeline */}
      <ol className="mt-3.5 space-y-0" aria-label={`Status: ${shipment.status}`}>
        {shipment.updates.map((u, i) => {
          const isCurrent = i === currentIdx && !delivered;
          return (
            <li key={u.label} className="flex gap-2.5">
              <div className="flex flex-col items-center">
                <span
                  className={cn(
                    "flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 text-[10px]",
                    u.done
                      ? isCurrent
                        ? "border-forest-600 bg-forest-600 text-white ring-4 ring-forest-100"
                        : "border-leaf-600 bg-leaf-600 text-white"
                      : "border-charcoal-200 bg-white text-charcoal-300"
                  )}
                >
                  {u.done ? <Check className="h-3 w-3" aria-hidden /> : i + 1}
                </span>
                {i < shipment.updates.length - 1 && (
                  <span className={cn("h-5 w-0.5", u.done ? "bg-leaf-500" : "bg-charcoal-100")} aria-hidden />
                )}
              </div>
              <div className="pb-1">
                <p className={cn("text-[11px] font-bold leading-5", u.done ? "text-charcoal-800" : "text-charcoal-400")}>
                  {u.label}
                  {isCurrent && <span className="ml-1.5 text-forest-700">● current</span>}
                </p>
                {u.time && <p className="text-[10px] font-semibold text-charcoal-400">{u.time}</p>}
              </div>
            </li>
          );
        })}
      </ol>

      {shipment.eta && !delivered && (
        <p className="mt-2 rounded-xl bg-forest-50 px-3 py-2 text-[11px] font-extrabold text-forest-800">
          ETA: {shipment.eta}
        </p>
      )}
    </li>
  );
}
