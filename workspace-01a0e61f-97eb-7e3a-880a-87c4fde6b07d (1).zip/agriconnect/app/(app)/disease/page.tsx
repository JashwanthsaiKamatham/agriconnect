"use client";

import { useCallback, useRef, useState, type DragEvent, type ChangeEvent } from "react";
import {
  Camera,
  CheckCircle2,
  ImageUp,
  Microscope,
  RotateCcw,
  ScanSearch,
  ShieldAlert,
  Stethoscope,
  TriangleAlert,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import { Field, Select } from "@/components/ui/Form";
import { ProgressBar } from "@/components/ui/Feedback";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { diseaseService, DISEASE_DISCLAIMER } from "@/lib/services";
import type { Diagnosis } from "@/lib/types";
import { cn } from "@/lib/utils";

const SAMPLE_CROPS = ["Tomato", "Paddy", "Cotton", "Maize", "Other"];

export default function DiseasePage() {
  usePageTitle("Disease Detection");
  const { toast } = useApp();

  const [cropType, setCropType] = useState("Tomato");
  const [image, setImage] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<Diagnosis | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const acceptFile = useCallback((file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast("Please upload an image file (JPG or PNG).", "error");
      return;
    }
    setImage(URL.createObjectURL(file));
    setResult(null);
  }, [toast]);

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    acceptFile(e.dataTransfer.files?.[0]);
  };

  const onPick = (e: ChangeEvent<HTMLInputElement>) => acceptFile(e.target.files?.[0]);

  const analyze = async () => {
    if (!image) {
      toast("Upload a leaf photo first.", "warning");
      return;
    }
    setAnalyzing(true);
    setResult(null);
    setProgress(8);
    const timer = setInterval(() => setProgress((p) => Math.min(p + Math.random() * 14, 92)), 220);
    const diagnosis = await diseaseService.analyze(cropType);
    clearInterval(timer);
    setProgress(100);
    setTimeout(() => {
      setAnalyzing(false);
      setResult(diagnosis);
      toast("Scan complete — review the demo result below.", "info");
    }, 350);
  };

  const reset = () => {
    setImage(null);
    setResult(null);
    setProgress(0);
    if (inputRef.current) inputRef.current.value = "";
  };

  const severityVariant = (s: Diagnosis["severity"]) => (s === "High" ? "danger" : s === "Medium" ? "warning" : "success");

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Crop Disease Detection"
        subtitle="Upload a photo of the affected leaf — get an instant AI-assisted diagnosis and treatment plan."
        demoNote="Demo AI — results are sample diagnoses for interface demonstration."
      />

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Upload panel */}
        <Card>
          <CardHeader
            title="Scan a leaf"
            subtitle="JPG or PNG · one clear photo of the affected part"
            icon={<Camera className="h-5 w-5" aria-hidden />}
          />
          <div className="px-5 pb-5">
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
              className={cn(
                "flex min-h-[240px] cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-6 text-center transition-colors",
                dragOver ? "border-forest-500 bg-forest-50" : "border-charcoal-200 bg-beige-50 hover:border-forest-400"
              )}
              onClick={() => inputRef.current?.click()}
              role="button"
              tabIndex={0}
              aria-label="Upload leaf image — click or drop a file"
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
              }}
            >
              {image ? (
                <div className="w-full">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={image} alt="Uploaded leaf for analysis" className="mx-auto max-h-56 rounded-xl border border-charcoal-100 object-contain" />
                  <p className="mt-3 text-xs font-semibold text-charcoal-500">Click to replace the photo</p>
                </div>
              ) : (
                <>
                  <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-forest-100 text-forest-700">
                    <ImageUp className="h-7 w-7" aria-hidden />
                  </span>
                  <p className="mt-3 text-sm font-bold text-charcoal-800">
                    Drop a leaf photo here, or <span className="text-forest-700 underline">browse</span>
                  </p>
                  <p className="mt-1 text-xs text-charcoal-400">Works best in natural light, leaf filling the frame</p>
                </>
              )}
              <input ref={inputRef} type="file" accept="image/*" className="sr-only" onChange={onPick} />
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <Field label="Crop type" htmlFor="dd-crop">
                <Select id="dd-crop" value={cropType} onChange={(e) => setCropType(e.target.value)}>
                  {SAMPLE_CROPS.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </Select>
              </Field>
              <div className="flex items-end gap-2">
                <Button onClick={analyze} loading={analyzing} fullWidth leftIcon={<ScanSearch className="h-4 w-4" aria-hidden />} disabled={!image}>
                  Analyze
                </Button>
                <Button variant="outline" onClick={reset} aria-label="Reset scan">
                  <RotateCcw className="h-4 w-4" aria-hidden />
                </Button>
              </div>
            </div>

            {!image && (
              <div className="mt-4">
                <p className="text-xs font-bold text-charcoal-500">No leaf handy? Try a sample photo:</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setImage("/images/crops/tomato.jpg");
                      setCropType("Tomato");
                      setResult(null);
                    }}
                    className="focus-ring rounded-full border border-charcoal-200 bg-white px-3 py-1.5 text-xs font-bold text-charcoal-700 hover:border-forest-400"
                  >
                    🍅 Tomato leaf
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setImage("/images/crops/rice.jpg");
                      setCropType("Paddy");
                      setResult(null);
                    }}
                    className="focus-ring rounded-full border border-charcoal-200 bg-white px-3 py-1.5 text-xs font-bold text-charcoal-700 hover:border-forest-400"
                  >
                    🌾 Paddy leaf
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setImage("/images/crops/cotton.jpg");
                      setCropType("Cotton");
                      setResult(null);
                    }}
                    className="focus-ring rounded-full border border-charcoal-200 bg-white px-3 py-1.5 text-xs font-bold text-charcoal-700 hover:border-forest-400"
                  >
                    ☁️ Cotton leaf
                  </button>
                </div>
              </div>
            )}
          </div>
        </Card>

        {/* Result panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader title="Diagnosis result" subtitle="AI-assisted · demo output" icon={<Microscope className="h-5 w-5" aria-hidden />} />
            <div className="px-5 pb-5">
              {analyzing ? (
                <div className="py-8 text-center" role="status">
                  <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-forest-100 text-forest-700">
                    <ScanSearch className="h-7 w-7 animate-pulse" aria-hidden />
                  </span>
                  <p className="mt-4 text-sm font-bold text-charcoal-800">Scanning leaf patterns…</p>
                  <p className="mt-1 text-xs text-charcoal-500">Comparing against 40,000+ labelled images</p>
                  <div className="mx-auto mt-4 max-w-xs">
                    <ProgressBar percent={progress} label="Analysis progress" />
                    <p className="mt-1.5 text-xs font-bold text-forest-700">{Math.round(progress)}%</p>
                  </div>
                </div>
              ) : result ? (
                <div className="animate-fade-in">
                  {/* Disclaimer — required */}
                  <div role="alert" className="mb-4 flex items-start gap-2.5 rounded-2xl border border-sun-200 bg-sun-100/80 px-4 py-3">
                    <TriangleAlert className="mt-0.5 h-[18px] w-[18px] shrink-0 text-sun-600" aria-hidden />
                    <p className="text-xs font-bold leading-relaxed text-sun-600">{DISEASE_DISCLAIMER}</p>
                  </div>

                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <h3 className="text-lg font-extrabold text-charcoal-900">{result.disease}</h3>
                      {result.scientificName && (
                        <p className="text-xs italic text-charcoal-500">{result.scientificName}</p>
                      )}
                    </div>
                    <Badge variant={severityVariant(result.severity)} className="!px-3 !py-1 !text-xs">
                      {result.severity} severity
                    </Badge>
                  </div>

                  <div className="mt-4">
                    <div className="mb-1 flex justify-between text-xs font-bold text-charcoal-600">
                      <span>Model confidence</span>
                      <span className="text-forest-700">{result.confidence}%</span>
                    </div>
                    <ProgressBar percent={result.confidence} colorClass="bg-forest-600" label="Model confidence" />
                  </div>

                  {[
                    { title: "Symptoms to confirm", items: result.symptoms },
                    { title: "Recommended actions", items: result.actions },
                    { title: "Prevention tips", items: result.prevention },
                  ].map((group, gi) => (
                    <div key={group.title} className="mt-4 rounded-2xl bg-beige-50 p-4">
                      <p className="text-xs font-extrabold uppercase tracking-wide text-charcoal-500">{group.title}</p>
                      <ul className="mt-2 space-y-1.5">
                        {group.items.map((item, i) => (
                          <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-charcoal-700">
                            <span
                              className={cn(
                                "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-[9px] font-extrabold text-white",
                                gi === 0 ? "bg-charcoal-400" : gi === 1 ? "bg-forest-600" : "bg-leaf-600"
                              )}
                              aria-hidden
                            >
                              {i + 1}
                            </span>
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}

                  <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                    <Button href="/experts" fullWidth leftIcon={<Stethoscope className="h-4 w-4" aria-hidden />}>
                      Consult an expert
                    </Button>
                    <Button href="/market" variant="outline" fullWidth>
                      Check market prices
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="py-10 text-center">
                  <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-beige-100 text-charcoal-400">
                    <ScanSearch className="h-7 w-7" aria-hidden />
                  </span>
                  <p className="mt-4 text-sm font-bold text-charcoal-700">No scan yet</p>
                  <p className="mx-auto mt-1 max-w-xs text-xs leading-relaxed text-charcoal-500">
                    Upload a leaf photo and press <strong>Analyze</strong>. You&apos;ll get the disease
                    name, confidence, severity and a treatment plan.
                  </p>
                  <ul className="mx-auto mt-4 max-w-xs space-y-1.5 text-left">
                    {["Works offline-friendly with sample scans", "Always free expert second opinion", "History saved on your device"].map((point) => (
                      <li key={point} className="flex items-center gap-2 text-xs font-medium text-charcoal-600">
                        <CheckCircle2 className="h-3.5 w-3.5 text-leaf-600" aria-hidden />
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </Card>

          <div className="flex items-start gap-3 rounded-2xl border border-earth-200 bg-earth-50 px-4 py-3.5">
            <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-earth-600" aria-hidden />
            <p className="text-xs leading-relaxed text-earth-800">
              <strong>How it works:</strong> this demo simulates the AI service defined in{" "}
              <code className="rounded bg-white px-1 py-0.5 text-[10px]">lib/services → diseaseService</code>.
              Connect your model or a vision API via{" "}
              <code className="rounded bg-white px-1 py-0.5 text-[10px]">AI_DISEASE_API_KEY</code> to go live —
              and always confirm with a real agronomist.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
