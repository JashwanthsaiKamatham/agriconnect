"use client";

import { useEffect, useMemo, useState } from "react";
import { MapPin, RefreshCw, Search, TrendingDown, TrendingUp } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import Badge, { DemoBadge } from "@/components/ui/Badge";
import EmptyState, { LoadingState } from "@/components/ui/Feedback";
import { Input, Select } from "@/components/ui/Form";
import { SimpleLineChart, MiniSparkline } from "@/components/charts/Charts";
import ChartFrame from "@/components/charts/ChartFrame";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { marketService } from "@/lib/services";
import type { MarketPrice } from "@/lib/types";
import { cn } from "@/lib/utils";

export default function MarketPage() {
  usePageTitle("Market Prices");
  const { toast } = useApp();

  const [prices, setPrices] = useState<MarketPrice[] | null>(null);
  const [query, setQuery] = useState("");
  const [stateFilter, setStateFilter] = useState("all");
  const [districtFilter, setDistrictFilter] = useState("all");
  const [selected, setSelected] = useState<MarketPrice | null>(null);
  const [range, setRange] = useState<7 | 30>(30);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    let live = true;
    marketService.prices().then((data) => {
      if (!live) return;
      setPrices(data);
      setSelected(data[0] ?? null);
    });
    return () => {
      live = false;
    };
  }, []);

  const states = useMemo(() => (prices ? Array.from(new Set(prices.map((p) => p.state))) : []), [prices]);
  const districts = useMemo(
    () => (prices ? Array.from(new Set(prices.map((p) => p.district))) : []),
    [prices]
  );

  const filtered = useMemo(() => {
    if (!prices) return [];
    let list = prices;
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((p) => p.crop.toLowerCase().includes(q) || (p.variety ?? "").toLowerCase().includes(q));
    if (stateFilter !== "all") list = list.filter((p) => p.state === stateFilter);
    if (districtFilter !== "all") list = list.filter((p) => p.district === districtFilter);
    return list;
  }, [prices, query, stateFilter, districtFilter]);

  const refresh = async () => {
    setRefreshing(true);
    await marketService.prices();
    setRefreshing(false);
    toast("Prices refreshed from the demo feed.", "info");
  };

  const chartData = useMemo(() => {
    if (!selected) return [];
    return selected.history.slice(-range).map((v, i) => ({ day: `D${i + 1}`, price: v }));
  }, [selected, range]);

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Live Market Prices"
        subtitle="Modal, minimum and maximum prices across major mandis near you."
        demoNote="Demo feed — connect a live Agmarknet / eNAM API via lib/services for real-time prices."
        actions={
          <button
            type="button"
            onClick={refresh}
            className="focus-ring inline-flex items-center gap-2 rounded-xl border border-charcoal-200 bg-white px-3.5 py-2 text-sm font-semibold text-charcoal-700 hover:border-forest-400 hover:text-forest-700"
            disabled={refreshing}
          >
            <RefreshCw className={cn("h-4 w-4", refreshing && "animate-spin")} aria-hidden />
            Refresh
          </button>
        }
      />

      {/* Filters */}
      <div className="mb-5 grid gap-3 rounded-2xl border border-charcoal-100 bg-white p-3 shadow-panel sm:grid-cols-2 lg:grid-cols-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal-400" aria-hidden />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search crop…" aria-label="Search crops" className="pl-9" />
        </div>
        <Select value={stateFilter} onChange={(e) => setStateFilter(e.target.value)} aria-label="Filter by state">
          <option value="all">All states</option>
          {states.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </Select>
        <Select value={districtFilter} onChange={(e) => setDistrictFilter(e.target.value)} aria-label="Filter by district">
          <option value="all">All districts</option>
          {districts.map((d) => (
            <option key={d}>{d}</option>
          ))}
        </Select>
        <div className="flex items-center justify-between rounded-xl bg-beige-100 px-4 py-2.5">
          <span className="text-xs font-bold text-charcoal-600">Prices in ₹ / quintal</span>
          <DemoBadge />
        </div>
      </div>

      {/* Content */}
      {!prices ? (
        <LoadingState label="Fetching today's mandi prices…" />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No crops match your filters"
          body="Try clearing the search or choosing a different state or district."
          action={
            <button
              type="button"
              onClick={() => {
                setQuery("");
                setStateFilter("all");
                setDistrictFilter("all");
              }}
              className="focus-ring rounded-xl border border-charcoal-200 bg-white px-4 py-2.5 text-sm font-semibold text-charcoal-700 hover:border-forest-400"
            >
              Clear filters
            </button>
          }
        />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {filtered.map((p) => {
            const positive = p.changePct >= 0;
            const isSelected = selected?.id === p.id;
            return (
              <Card
                key={p.id}
                className={cn(
                  "cursor-pointer p-4 transition-all hover:-translate-y-0.5 hover:shadow-lift",
                  isSelected && "ring-2 ring-forest-500"
                )}
              >
                <button
                  type="button"
                  onClick={() => {
                    setSelected(p);
                    document.getElementById("price-history")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="focus-ring w-full rounded-xl text-left"
                  aria-label={`View ${p.crop} price history`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2.5">
                      <span aria-hidden className="text-2xl">{p.emoji}</span>
                      <div>
                        <p className="text-sm font-extrabold text-charcoal-900">{p.crop}</p>
                        <p className="text-[11px] font-medium text-charcoal-400">{p.variety ?? p.market}</p>
                      </div>
                    </div>
                    <Badge variant={positive ? "success" : "danger"}>
                      {positive ? <TrendingUp className="h-3 w-3" aria-hidden /> : <TrendingDown className="h-3 w-3" aria-hidden />}
                      {Math.abs(p.changePct)}%
                    </Badge>
                  </div>

                  <p className="mt-3 text-2xl font-extrabold tracking-tight text-charcoal-900">
                    ₹{p.modal.toLocaleString("en-IN")}
                    <span className="ml-1 text-xs font-bold text-charcoal-400">/q</span>
                  </p>

                  <div className="mt-2 grid grid-cols-3 gap-2 text-center">
                    <div className="rounded-lg bg-beige-100 py-1.5">
                      <p className="text-[10px] font-bold uppercase text-charcoal-400">Min</p>
                      <p className="text-xs font-extrabold text-charcoal-800">₹{p.min.toLocaleString("en-IN")}</p>
                    </div>
                    <div className="rounded-lg bg-beige-100 py-1.5">
                      <p className="text-[10px] font-bold uppercase text-charcoal-400">Avg</p>
                      <p className="text-xs font-extrabold text-charcoal-800">₹{p.avg.toLocaleString("en-IN")}</p>
                    </div>
                    <div className="rounded-lg bg-beige-100 py-1.5">
                      <p className="text-[10px] font-bold uppercase text-charcoal-400">Max</p>
                      <p className="text-xs font-extrabold text-charcoal-800">₹{p.max.toLocaleString("en-IN")}</p>
                    </div>
                  </div>

                  <div className="mt-3 flex items-end justify-between">
                    <div>
                      <MiniSparkline data={p.history.slice(-14)} positive={positive} />
                      <p className="mt-1 text-[10px] font-semibold text-charcoal-400">{p.updatedLabel}</p>
                    </div>
                    <span className="text-[11px] font-bold text-forest-700">View trend →</span>
                  </div>
                </button>
              </Card>
            );
          })}
        </ul>
      )}

      {/* Desktop comparison table (cards above serve phones & tablets) */}
      {filtered.length > 0 && (
        <Card className="mb-6 hidden overflow-hidden lg:block">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full min-w-[720px] text-left text-sm">
              <caption className="sr-only">Mandi price comparison, rupees per quintal</caption>
              <thead>
                <tr className="border-b border-charcoal-100 bg-beige-100 text-[11px] uppercase tracking-wide text-charcoal-500">
                  <th scope="col" className="px-5 py-3 font-bold">Crop</th>
                  <th scope="col" className="px-4 py-3 font-bold">Market</th>
                  <th scope="col" className="px-4 py-3 font-bold">Min</th>
                  <th scope="col" className="px-4 py-3 font-bold">Average</th>
                  <th scope="col" className="px-4 py-3 font-bold">Modal</th>
                  <th scope="col" className="px-4 py-3 font-bold">Change</th>
                  <th scope="col" className="px-5 py-3 font-bold">Updated</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p2) => {
                  const pos = p2.changePct >= 0;
                  const isSel = selected?.id === p2.id;
                  return (
                    <tr
                      key={p2.id}
                      onClick={() => setSelected(p2)}
                      className={`cursor-pointer border-b border-charcoal-50 transition-colors last:border-0 hover:bg-forest-50/50 ${isSel ? "bg-forest-50" : ""}`}
                    >
                      <th scope="row" className="whitespace-nowrap px-5 py-3.5 font-bold text-charcoal-900">
                        <span aria-hidden className="mr-2">{p2.emoji}</span>
                        {p2.crop}
                        {p2.variety && <span className="ml-2 text-xs font-medium text-charcoal-400">{p2.variety}</span>}
                      </th>
                      <td className="whitespace-nowrap px-4 py-3.5 text-xs font-semibold text-charcoal-500">
                        {p2.market}, {p2.district}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3.5 font-semibold text-charcoal-600">₹{p2.min.toLocaleString("en-IN")}</td>
                      <td className="whitespace-nowrap px-4 py-3.5 font-semibold text-charcoal-600">₹{p2.avg.toLocaleString("en-IN")}</td>
                      <td className="whitespace-nowrap px-4 py-3.5 font-extrabold text-forest-700">₹{p2.modal.toLocaleString("en-IN")}</td>
                      <td className={`whitespace-nowrap px-4 py-3.5 font-bold ${pos ? "text-leaf-600" : "text-red-600"}`}>
                        {pos ? "▲" : "▼"} {Math.abs(p2.changePct)}%
                      </td>
                      <td className="whitespace-nowrap px-5 py-3.5 text-xs font-medium text-charcoal-400">{p2.updatedLabel}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* History chart + nearby markets */}
      {selected && (
        <section id="price-history" className="mt-8 grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader
              title={`${selected.crop} — ${range}-day price trend`}
              subtitle={`${selected.market}, ${selected.district} · ₹ per quintal · demo history`}
              action={
                <div className="flex gap-1 rounded-xl bg-charcoal-100 p-1">
                  {([7, 30] as const).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setRange(r)}
                      aria-pressed={range === r}
                      className={cn(
                        "focus-ring rounded-lg px-3 py-1 text-xs font-bold",
                        range === r ? "bg-white text-forest-700 shadow-sm" : "text-charcoal-500"
                      )}
                    >
                      {r}D
                    </button>
                  ))}
                </div>
              }
            />
            <div className="px-3 pb-4">
              <ChartFrame minWidth={560} label={`${selected.crop} price history chart`}>
                <SimpleLineChart
                  data={chartData}
                  xKey="day"
                  yKey="price"
                  tooltipLabel={`${selected.crop} price`}
                  yFmt={(v) => `₹${Math.round(v)}`}
                />
              </ChartFrame>
            </div>
          </Card>

          <Card>
            <CardHeader title="Nearby markets" subtitle={`Best ${selected.crop} prices around you`} icon={<MapPin className="h-5 w-5" aria-hidden />} />
            <ul className="px-4 pb-5">
              {selected.nearby.map((m) => {
                const positive = m.changePct >= 0;
                return (
                  <li key={m.market} className="flex items-center justify-between gap-3 border-b border-charcoal-50 py-3 last:border-0">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-bold text-charcoal-900">{m.market}</p>
                      <p className="text-[11px] text-charcoal-400">
                        {m.district}
                        {m.distanceKm > 0 && ` · ${m.distanceKm} km away`}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-extrabold text-charcoal-900">₹{m.modal.toLocaleString("en-IN")}</p>
                      <p className={cn("text-[11px] font-bold", positive ? "text-leaf-600" : "text-red-600")}>
                        {positive ? "▲" : "▼"} {Math.abs(m.changePct)}%
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
          </Card>
        </section>
      )}
    </div>
  );
}
