"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  CloudLightning,
  CloudRain,
  CloudSun,
  Cloudy,
  Cloud,
  Droplets,
  MapPin,
  Navigation,
  Sprout,
  Sun,
  Sunrise,
  Sunset,
  TriangleAlert,
  Wind,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import Badge, { DemoBadge } from "@/components/ui/Badge";
import { LoadingState } from "@/components/ui/Feedback";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { weatherService } from "@/lib/services";
import type { WeatherCondition, WeatherData } from "@/lib/types";
import { cn } from "@/lib/utils";

const CONDITION_ICONS: Record<WeatherCondition, { Icon: LucideIcon; class: string }> = {
  sunny: { Icon: Sun, class: "text-sun-500" },
  "partly cloudy": { Icon: CloudSun, class: "text-sky-500" },
  cloudy: { Icon: Cloudy, class: "text-charcoal-400" },
  "light rain": { Icon: CloudRain, class: "text-sky-600" },
  "heavy rain": { Icon: CloudLightning, class: "text-indigo-600" },
  thunderstorm: { Icon: CloudLightning, class: "text-violet-600" },
};

const RECO_ICONS: Record<string, LucideIcon> = {
  droplets: Droplets,
  spray: Sprout,
  harvest: CloudSun,
  bug: Sprout,
  sun: Sun,
};

export default function WeatherPage() {
  usePageTitle("Weather");
  const { user, toast } = useApp();
  const [data, setData] = useState<WeatherData | null>(null);

  useEffect(() => {
    let live = true;
    weatherService.current().then((d) => {
      if (live) setData(d);
    });
    return () => {
      live = false;
    };
  }, []);

  if (!data) {
    return (
      <div className="animate-fade-in">
        <PageHeader title="Weather Intelligence" />
        <LoadingState label="Reading village-level forecast…" />
      </div>
    );
  }

  const { current, daily, alerts, recommendations } = data;
  const farm = user?.farm;

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Weather Intelligence"
        subtitle="Village-level forecast with farming advisories for the week ahead."
        demoNote="Sample forecast — plug an IMD / OpenWeatherMap key into weatherService for live data."
      />

      {/* Alerts */}
      {alerts.map((a) => (
        <div
          key={a.title}
          role="alert"
          className={cn(
            "mb-4 flex items-start gap-3 rounded-2xl border px-4 py-3.5",
            a.type === "rain"
              ? "border-orange-200 bg-orange-50"
              : a.type === "heat"
                ? "border-red-200 bg-red-50"
                : "border-sky-200 bg-sky-50"
          )}
        >
          <TriangleAlert
            className={cn(
              "mt-0.5 h-5 w-5 shrink-0",
              a.type === "rain" ? "text-orange-500" : a.type === "heat" ? "text-red-500" : "text-sky-500"
            )}
            aria-hidden
          />
          <div>
            <p className={cn("text-sm font-extrabold", a.type === "rain" ? "text-orange-700" : a.type === "heat" ? "text-red-700" : "text-sky-700")}>
              {a.title}
            </p>
            <p className="mt-0.5 text-xs leading-relaxed text-charcoal-600">{a.body}</p>
          </div>
        </div>
      ))}

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Current conditions */}
        <Card className="lg:col-span-2">
          <div className="flex flex-col gap-5 p-5 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              {(() => {
                const { Icon, class: cls } = CONDITION_ICONS[current.condition];
                return <Icon className={cn("h-16 w-16", cls)} aria-hidden />;
              })()}
              <div>
                <p className="text-5xl font-extrabold tracking-tight text-charcoal-900">
                  {current.tempC}°<span className="text-2xl text-charcoal-400">C</span>
                </p>
                <p className="mt-1 text-sm font-semibold capitalize text-charcoal-500">
                  {current.condition} · feels like {current.feelsLikeC}°
                </p>
                <p className="text-xs font-medium text-charcoal-400">{data.farm} · {data.updatedAtLabel}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="rounded-2xl bg-sun-100 p-3 text-center">
                <Sunrise className="mx-auto h-5 w-5 text-sun-600" aria-hidden />
                <p className="mt-1 text-sm font-extrabold text-charcoal-900">{current.sunrise}</p>
                <p className="text-[10px] font-bold uppercase text-charcoal-400">Sunrise</p>
              </div>
              <div className="rounded-2xl bg-orange-100 p-3 text-center">
                <Sunset className="mx-auto h-5 w-5 text-orange-600" aria-hidden />
                <p className="mt-1 text-sm font-extrabold text-charcoal-900">{current.sunset}</p>
                <p className="text-[10px] font-bold uppercase text-charcoal-400">Sunset</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 px-5 pb-5 sm:grid-cols-4">
            {[
              { icon: Droplets, label: "Humidity", value: `${current.humidity}%`, tone: "bg-sky-50 text-sky-600" },
              { icon: CloudRain, label: "Rain chance", value: `${current.rainChance}%`, tone: "bg-indigo-50 text-indigo-600" },
              { icon: Wind, label: "Wind", value: `${current.windKmph} km/h`, tone: "bg-leaf-100 text-leaf-700" },
              { icon: Sun, label: "UV index", value: `${current.uvIndex} (moderate)`, tone: "bg-sun-100 text-sun-600" },
            ].map((m) => (
              <div key={m.label} className="rounded-2xl border border-charcoal-100 p-3.5">
                <span className={cn("flex h-8 w-8 items-center justify-center rounded-lg", m.tone)}>
                  <m.icon className="h-4 w-4" aria-hidden />
                </span>
                <p className="mt-2 text-[11px] font-bold uppercase tracking-wide text-charcoal-400">{m.label}</p>
                <p className="text-sm font-extrabold text-charcoal-900">{m.value}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Farm location + map placeholder */}
        <Card>
          <CardHeader title="Farm location" subtitle={farm ? `${farm.village}, ${farm.district}` : data.location} icon={<MapPin className="h-5 w-5" aria-hidden />} />
          <div className="px-5 pb-5">
            <div className="map-grid relative flex h-44 items-center justify-center overflow-hidden rounded-2xl border border-forest-100 bg-forest-50/60">
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
                <span className="relative mx-auto flex h-10 w-10 items-center justify-center">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-forest-400 opacity-40" />
                  <MapPin className="relative h-7 w-7 text-forest-700" aria-hidden />
                </span>
                <p className="mt-1 rounded-lg bg-white/90 px-2 py-0.5 text-[10px] font-extrabold text-charcoal-700 shadow-sm">
                  15.57° N, 77.58° E
                </p>
              </div>
              <span className="absolute bottom-2 right-2 rounded-lg bg-white/90 px-2 py-1 text-[10px] font-bold text-charcoal-500 shadow-sm">
                Map preview — API integration ready
              </span>
            </div>
            <Link
              href="/profile"
              className="focus-ring mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-charcoal-200 bg-white px-4 py-2.5 text-sm font-semibold text-charcoal-700 hover:border-forest-400 hover:text-forest-700"
            >
              <Navigation className="h-4 w-4" aria-hidden />
              Update farm location
            </Link>
          </div>
        </Card>
      </div>

      {/* 7-day forecast */}
      <Card className="mt-4">
        <CardHeader
          title="7-day forecast"
          subtitle="Plan spraying, irrigation and harvest around the rain"
          action={<DemoBadge />}
        />
        <ul className="grid grid-cols-2 gap-3 px-5 pb-5 sm:grid-cols-4 lg:grid-cols-7">
          {daily.map((d) => {
            const { Icon, class: cls } = CONDITION_ICONS[d.condition];
            return (
              <li
                key={d.day}
                className={cn(
                  "rounded-2xl border p-3 text-center",
                  d.rain >= 65 ? "border-indigo-200 bg-indigo-50/60" : "border-charcoal-100 bg-white"
                )}
              >
                <p className="text-xs font-extrabold text-charcoal-900">{d.day}</p>
                <p className="text-[10px] font-semibold text-charcoal-400">{d.date}</p>
                <Icon className={cn("mx-auto mt-2 h-8 w-8", cls)} aria-hidden />
                <p className="mt-2 text-sm font-extrabold text-charcoal-900">
                  {d.hi}° <span className="font-semibold text-charcoal-400">{d.lo}°</span>
                </p>
                <p className="mt-1 flex items-center justify-center gap-1 text-[11px] font-bold text-sky-600">
                  <Droplets className="h-3 w-3" aria-hidden />
                  {d.rain}%
                </p>
              </li>
            );
          })}
        </ul>
      </Card>

      {/* Farming recommendations */}
      <Card className="mt-4">
        <CardHeader
          title="Farming recommendations"
          subtitle="Generated for your crops and soil this week (demo logic)"
          icon={<Sprout className="h-5 w-5" aria-hidden />}
        />
        <ul className="grid gap-3 px-5 pb-5 md:grid-cols-2">
          {recommendations.map((r) => {
            const Icon = RECO_ICONS[r.icon] ?? Sprout;
            return (
              <li key={r.title} className="flex items-start gap-3 rounded-2xl border border-charcoal-100 bg-beige-50 p-4">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-forest-600 text-white">
                  <Icon className="h-[18px] w-[18px]" aria-hidden />
                </span>
                <div>
                  <p className="text-sm font-bold text-charcoal-900">{r.title}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-charcoal-600">{r.body}</p>
                </div>
              </li>
            );
          })}
        </ul>
        <div className="mx-5 mb-5 flex items-center justify-between rounded-2xl bg-forest-50 px-4 py-3">
          <p className="text-xs font-semibold text-forest-800">
            Irrigation advice: skip watering today — Wednesday&apos;s rain will recharge your black soil.
          </p>
          <Badge variant="success">Auto</Badge>
        </div>
      </Card>
    </div>
  );
}
