"use client";

import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import {
  BadgeCheck,
  CalendarDays,
  Clock,
  GraduationCap,
  ImagePlus,
  Languages,
  MessageCircle,
  Phone,
  Star,
  Video,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import Modal from "@/components/ui/Modal";
import Avatar from "@/components/ui/Avatar";
import { Field, Input, Select, Textarea } from "@/components/ui/Form";
import EmptyState from "@/components/ui/Feedback";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { experts } from "@/lib/data/experts";
import type { Consultation, Expert } from "@/lib/types";
import { cn, formatDate, formatINR } from "@/lib/utils";

const MODES: Consultation["mode"][] = ["Video call", "Phone call", "Farm visit"];
const TIME_SLOTS = ["8:00 AM", "10:30 AM", "12:00 PM", "3:00 PM", "5:00 PM", "7:00 PM"];

export default function ExpertsPage() {
  usePageTitle("Experts");
  const { consultations, addConsultation, crops, toast } = useApp();

  const [booking, setBooking] = useState<Expert | null>(null);
  const [form, setForm] = useState({
    crop: "",
    topic: "",
    date: "",
    time: TIME_SLOTS[0],
    mode: "Video call" as Consultation["mode"],
    photo: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState<"all" | "available">("all");

  useEffect(() => {
    if (booking) {
      setForm((f) => ({ ...f, crop: f.crop || crops[0]?.name || "", date: "" }));
      setErrors({});
    }
  }, [booking, crops]);

  const list = filter === "available" ? experts.filter((e) => e.available) : experts;

  const set = (key: keyof typeof form) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    setErrors((er) => ({ ...er, [key]: "" }));
  };

  const onPhoto = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setForm((f) => ({ ...f, photo: URL.createObjectURL(file) }));
  };

  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    const e: Record<string, string> = {};
    if (!form.crop) e.crop = "Select the crop you need help with";
    if (form.topic.trim().length < 12) e.topic = "Describe the problem in at least 12 characters";
    if (!form.date) e.date = "Pick a preferred date";
    setErrors(e);
    if (Object.keys(e).length > 0 || !booking) return;
    setSaving(true);
    await new Promise((r) => setTimeout(r, 700));
    addConsultation({
      expertId: booking.id,
      expertName: booking.name,
      crop: form.crop,
      topic: form.topic.trim(),
      date: form.date,
      time: form.time,
      mode: form.mode,
      fee: booking.fee,
    });
    setSaving(false);
    setBooking(null);
    toast(`Consultation booked with ${booking.name}!`, "success");
  };

  const upcoming = consultations.filter((c) => c.status === "Upcoming");
  const past = consultations.filter((c) => c.status !== "Upcoming");

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Expert Consultation"
        subtitle="Talk to verified agronomists, pathologists and market advisors — in your language."
        demoNote="Demo expert panel with sample fees and slots."
      />

      <div className="mb-5 flex gap-2" role="group" aria-label="Expert availability filter">
        {(["all", "available"] as const).map((f) => (
          <button
            key={f}
            type="button"
            onClick={() => setFilter(f)}
            aria-pressed={filter === f}
            className={cn(
              "focus-ring rounded-full border px-4 py-2 text-sm font-bold transition-colors",
              filter === f
                ? "border-forest-600 bg-forest-600 text-white"
                : "border-charcoal-200 bg-white text-charcoal-600 hover:border-forest-400"
            )}
          >
            {f === "all" ? "All experts" : "Available today"}
          </button>
        ))}
      </div>

      <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {list.map((ex) => (
          <Card key={ex.id} className="p-5 transition-shadow hover:shadow-lift">
            <div className="flex items-start gap-3.5">
              <Avatar name={ex.name} size="lg" className={cn("!rounded-2xl", ex.color)} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="truncate text-sm font-extrabold text-charcoal-900">{ex.name}</h3>
                  {ex.available ? (
                    <Badge variant="success">● Available</Badge>
                  ) : (
                    <Badge variant="neutral">Busy</Badge>
                  )}
                </div>
                <p className="truncate text-xs font-semibold text-forest-700">{ex.specialization}</p>
                <p className="truncate text-[11px] text-charcoal-400">{ex.qualification}</p>
              </div>
            </div>

            <dl className="mt-3.5 space-y-1.5 text-xs font-semibold text-charcoal-600">
              <div className="flex items-center justify-between">
                <dt className="flex items-center gap-1.5 text-charcoal-400">
                  <GraduationCap className="h-3.5 w-3.5" aria-hidden /> Experience
                </dt>
                <dd>{ex.experience} years</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="flex items-center gap-1.5 text-charcoal-400">
                  <Languages className="h-3.5 w-3.5" aria-hidden /> Languages
                </dt>
                <dd className="truncate">{ex.languages.join(", ")}</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="flex items-center gap-1.5 text-charcoal-400">
                  <Clock className="h-3.5 w-3.5" aria-hidden /> Next slot
                </dt>
                <dd>{ex.nextSlot}</dd>
              </div>
            </dl>

            <div className="mt-3.5 flex items-center justify-between border-t border-charcoal-100 pt-3.5">
              <div>
                <span className="flex items-center gap-1 text-sm font-extrabold text-charcoal-900">
                  <Star className="h-4 w-4 fill-sun-400 text-sun-400" aria-hidden />
                  {ex.rating}
                  <span className="text-[11px] font-semibold text-charcoal-400">({ex.reviews})</span>
                </span>
                <p className="text-[11px] font-bold text-charcoal-500">{formatINR(ex.fee)} / consultation</p>
              </div>
              <Button size="sm" onClick={() => setBooking(ex)} disabled={!ex.available}>
                Book
              </Button>
            </div>
          </Card>
        ))}
      </ul>

      {/* Consultation history */}
      <section className="mt-8">
        <Card>
          <CardHeader
            title="My consultations"
            subtitle={`${upcoming.length} upcoming · ${past.length} completed`}
            icon={<MessageCircle className="h-5 w-5" aria-hidden />}
          />
          {consultations.length === 0 ? (
            <div className="px-5 pb-6">
              <EmptyState
                icon={<GraduationCap className="h-7 w-7" aria-hidden />}
                title="No consultations yet"
                body="Book your first expert call — get answers within hours, not field trips."
                className="border-0 bg-beige-50"
              />
            </div>
          ) : (
            <ul className="divide-y divide-charcoal-50 px-5 pb-4">
              {consultations.map((c) => (
                <li key={c.id} className="flex flex-wrap items-center justify-between gap-3 py-3.5">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-extrabold text-charcoal-900">{c.expertName}</p>
                      <Badge variant={c.status === "Upcoming" ? "success" : c.status === "Completed" ? "neutral" : "danger"}>
                        {c.status}
                      </Badge>
                      <Badge variant="info">{c.mode}</Badge>
                    </div>
                    <p className="mt-0.5 line-clamp-1 text-xs text-charcoal-500">{c.topic}</p>
                    <p className="mt-0.5 flex items-center gap-1 text-[11px] font-semibold text-charcoal-400">
                      <CalendarDays className="h-3 w-3" aria-hidden />
                      {c.crop} · {formatDate(c.date)}, {c.time} · {formatINR(c.fee)}
                    </p>
                  </div>
                  {c.status === "Upcoming" ? (
                    <Button
                      size="sm"
                      variant="outline"
                      leftIcon={<Video className="h-4 w-4" aria-hidden />}
                      onClick={() => toast("The join link arrives 15 min before (demo).", "info")}
                    >
                      Join
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="ghost"
                      leftIcon={<Phone className="h-4 w-4" aria-hidden />}
                      onClick={() => toast("Consultation summary opened (demo).", "info")}
                    >
                      Summary
                    </Button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Card>
      </section>

      {/* Booking modal */}
      <Modal
        open={!!booking}
        onClose={() => setBooking(null)}
        title={booking ? `Book ${booking.name}` : ""}
        subtitle={booking ? `${booking.specialization} · ${formatINR(booking.fee)} per consultation` : ""}
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setBooking(null)}>
              Cancel
            </Button>
            <Button type="submit" form="consult-form" loading={saving}>
              Confirm booking
            </Button>
          </div>
        }
      >
        <form id="consult-form" onSubmit={submit} noValidate className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Crop" htmlFor="cn-crop" required error={errors.crop}>
              <Select id="cn-crop" value={form.crop} onChange={set("crop")} error={errors.crop}>
                <option value="">Select crop…</option>
                {Array.from(new Set([...crops.map((c) => c.name), "Cotton", "Chilli", "Other"])).map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </Select>
            </Field>
            <Field label="Consultation type" htmlFor="cn-mode">
              <Select id="cn-mode" value={form.mode} onChange={set("mode")}>
                {MODES.map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </Select>
            </Field>
          </div>
          <Field label="Describe the problem" htmlFor="cn-topic" required error={errors.topic}>
            <Textarea
              id="cn-topic"
              value={form.topic}
              onChange={set("topic")}
              error={errors.topic}
              placeholder="e.g. Yellowing starts from leaf tips on 20-day paddy, spreading fast in one corner"
            />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Preferred date" htmlFor="cn-date" required error={errors.date}>
              <Input id="cn-date" type="date" value={form.date} onChange={set("date")} error={errors.date} />
            </Field>
            <Field label="Preferred time" htmlFor="cn-time">
              <Select id="cn-time" value={form.time} onChange={set("time")}>
                {TIME_SLOTS.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </Select>
            </Field>
          </div>
          <Field label="Attach a photo of the affected plant" htmlFor="cn-photo">
            <div className="flex items-center gap-3">
              {form.photo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={form.photo} alt="Problem preview" className="h-16 w-24 rounded-xl border border-charcoal-100 object-cover" />
              ) : (
                <span className="flex h-16 w-24 items-center justify-center rounded-xl border-2 border-dashed border-charcoal-200 bg-beige-100 text-charcoal-400">
                  <BadgeCheck className="h-5 w-5" aria-hidden />
                </span>
              )}
              <label className="focus-ring inline-flex cursor-pointer items-center gap-2 rounded-xl border border-charcoal-200 bg-white px-3.5 py-2 text-sm font-semibold text-charcoal-700 hover:border-forest-400">
                <ImagePlus className="h-4 w-4" aria-hidden />
                Upload
                <input id="cn-photo" type="file" accept="image/*" className="sr-only" onChange={onPhoto} />
              </label>
            </div>
          </Field>
        </form>
      </Modal>
    </div>
  );
}
