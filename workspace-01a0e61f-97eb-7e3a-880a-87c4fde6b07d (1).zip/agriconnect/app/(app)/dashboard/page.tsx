"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  CalendarCheck,
  CheckCircle2,
  ChevronRight,
  Circle,
  CloudSun,
  IndianRupee,
  Landmark,
  ListPlus,
  Microscope,
  Sprout,
  Store,
  Tractor,
  TrendingDown,
  TrendingUp,
  Wheat,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card, CardHeader } from "@/components/ui/Card";
import StatCard from "@/components/ui/StatCard";
import Badge, { DemoBadge } from "@/components/ui/Badge";
import Avatar from "@/components/ui/Avatar";
import { ProgressBar } from "@/components/ui/Feedback";
import { RevenueAreaChart, DonutChart, MiniSparkline, SimpleBarChart } from "@/components/charts/Charts";
import ChartFrame from "@/components/charts/ChartFrame";
import DemoBanner from "@/components/dashboard/DemoBanner";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle, todayLabel, greeting } from "@/lib/hooks";
import { weatherData } from "@/lib/data/weather";
import { marketPrices } from "@/lib/data/market";
import { dashboardRevenue, expenseBreakdown } from "@/lib/data/analytics";
import { seedTasks, seedActivity } from "@/lib/data/notifications";
import type { FarmTask } from "@/lib/types";
import {
  cn,
  cropEmoji,
  daysUntil,
  estimateCropRevenue,
  formatDateShort,
  STAGE_BAR_CLASS,
  STAGE_BADGE_CLASS,
  stageIndex,
  toLakh,
  tonnesToQuintals,
} from "@/lib/utils";

const QUICK_ACTIONS = [
  { href: "/crops?add=1", labelKey: "dashboard.addCrop", fallback: "Add crop", icon: ListPlus, tone: "bg-forest-600" },
  { href: "/marketplace?add=1", labelKey: "dashboard.sellProduce", fallback: "Sell produce", icon: Store, tone: "bg-earth-600" },
  { href: "/disease", labelKey: "dashboard.detectDisease", fallback: "Detect disease", icon: Microscope, tone: "bg-red-500" },
  { href: "/experts", labelKey: "dashboard.bookExpert", fallback: "Book expert", icon: CalendarCheck, tone: "bg-sky-600" },
  { href: "/equipment", labelKey: "dashboard.rentEquipment", fallback: "Rent equipment", icon: Tractor, tone: "bg-sun-500" },
] as const;

const ACTIVITY_ICONS = {
  order: Store,
  price: TrendingUp,
  expert: CalendarCheck,
  scheme: Landmark,
  equipment: Tractor,
} as const;

const STAGE_DONUT_COLORS: Record<string, string> = {
  Planned: "#a4aca6",
  Seedling: "#4ade80",
  Vegetative: "#64a97c",
  Flowering: "#d99e1b",
  Fruiting: "#ea580c",
  "Ready for Harvest": "#16a34a",
  Harvested: "#b0825c",
};

export default function DashboardPage() {
  usePageTitle("Dashboard");
  const { user, crops, t, toast } = useApp();
  const [tasks, setTasks] = useState<FarmTask[]>(seedTasks);

  const activeCrops = useMemo(() => crops.filter((c) => c.stage !== "Harvested"), [crops]);

  const expectedHarvest = useMemo(
    () => activeCrops.reduce((sum, c) => sum + c.estimatedYield, 0),
    [activeCrops]
  );

  const estimatedRevenue = useMemo(
    () => activeCrops.reduce((sum, c) => sum + estimateCropRevenue(c), 0),
    [activeCrops]
  );

  const stageData = useMemo(() => {
    const counts = new Map<string, number>();
    crops.forEach((c) => counts.set(c.stage, (counts.get(c.stage) ?? 0) + 1));
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([name, value]) => ({ name, value, color: STAGE_DONUT_COLORS[name] ?? "#a4aca6" }));
  }, [crops]);

  const topPrices = marketPrices.slice(0, 4);
  const farm = user?.farm;

  // Hydration-safe: render a stable string on the server, real local values after mount.
  const [todayStr, setTodayStr] = useState("");
  const [welcomeWord, setWelcomeWord] = useState("Welcome");
  useEffect(() => {
    setTodayStr(todayLabel());
    setWelcomeWord(greeting());
  }, []);

  const toggleTask = (id: string) => {
    setTasks((prev) => prev.map((task) => (task.id === id ? { ...task, done: !task.done } : task)));
    const task = tasks.find((task) => task.id === id);
    if (task && !task.done) toast(`Task completed: ${task.title}`, "success");
  };

  return (
    <div className="animate-fade-in">
      {/* Demo-data separation banner */}
      <DemoBanner />

      {/* Welcome / profile summary */}
      <PageHeader
        title={`${welcomeWord}, ${(user?.name ?? "Farmer").split(" ")[0]} 👋`}
        subtitle={`${todayStr ? todayStr + (farm ? ` · ${farm.village}, ${farm.district}` : "") : farm ? `${farm.village}, ${farm.district}` : ""}`}
        actions={
          <Link
            href="/analytics"
            className="focus-ring inline-flex items-center gap-1.5 rounded-xl border border-charcoal-200 bg-white px-3.5 py-2 text-sm font-semibold text-charcoal-700 hover:border-forest-400 hover:text-forest-700"
          >
            View analytics
            <ArrowRight className="h-4 w-4" aria-hidden />
          </Link>
        }
      />

      <Card className="mb-6 flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:p-5">
        <Avatar name={user?.name ?? "Farmer"} size="xl" />
        <div className="min-w-0 flex-1">
          <p className="text-base font-extrabold text-charcoal-900">{user?.name}</p>
          <p className="mt-0.5 text-sm text-charcoal-500">
            {farm ? `${farm.area} ${farm.areaUnit} · ${farm.soilType} soil · ${farm.irrigationType}` : "Complete onboarding to add farm details"}
          </p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            <Badge variant="forest">Farmer</Badge>
            {farm?.cropsGrown?.slice(0, 4).map((c) => (
              <Badge key={c} variant="neutral">{c}</Badge>
            ))}
            {(farm?.cropsGrown?.length ?? 0) > 4 && (
              <Badge variant="neutral">+{(farm?.cropsGrown?.length ?? 0) - 4} more</Badge>
            )}
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-3 rounded-2xl bg-sky-50 px-4 py-3">
          <CloudSun className="h-8 w-8 text-sky-600" aria-hidden />
          <div>
            <p className="text-xl font-extrabold leading-none text-charcoal-900">{weatherData.current.tempC}°C</p>
            <p className="mt-0.5 text-[11px] font-semibold capitalize text-sky-700">{weatherData.current.condition} · rain {weatherData.current.rainChance}%</p>
          </div>
        </div>
      </Card>

      {/* Quick actions */}
      <section aria-label={t("dashboard.quickActions")} className="mb-6">
        <h2 className="mb-3 text-sm font-bold text-charcoal-700">{t("dashboard.quickActions")}</h2>
        <div className="flex gap-3 overflow-x-auto pb-1 scrollbar-thin sm:grid sm:grid-cols-3 sm:overflow-visible lg:grid-cols-5">
          {QUICK_ACTIONS.map((a) => {
            const Icon = a.icon;
            return (
              <Link
                key={a.href}
                href={a.href}
                className="focus-ring group flex min-w-[128px] flex-1 flex-col items-center gap-2 rounded-2xl border border-charcoal-100 bg-white px-3 py-4 text-center shadow-panel transition-all hover:-translate-y-0.5 hover:shadow-card"
              >
                <span className={cn("flex h-11 w-11 items-center justify-center rounded-2xl text-white transition-transform group-hover:scale-105", a.tone)}>
                  <Icon className="h-5 w-5" aria-hidden />
                </span>
                <span className="text-xs font-bold text-charcoal-700">{t(a.labelKey) !== a.labelKey ? t(a.labelKey) : a.fallback}</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* KPI cards */}
      <section aria-label="Key metrics" className="mb-6 grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <StatCard
          label={t("dashboard.activeCrops")}
          value={activeCrops.length}
          sub={`${crops.length} total this season`}
          icon={<Sprout className="h-5 w-5" aria-hidden />}
          tone="forest"
          trend={{ dir: "up", value: "+2" }}
        />
        <StatCard
          label={t("dashboard.expectedHarvest")}
          value={`${expectedHarvest.toFixed(1)} t`}
          sub="next 120 days · demo estimate"
          icon={<Wheat className="h-5 w-5" aria-hidden />}
          tone="leaf"
          demo
        />
        <StatCard
          label={t("dashboard.estimatedRevenue")}
          value={toLakh(estimatedRevenue)}
          sub={`≈ ${Math.round(tonnesToQuintals(expectedHarvest))} quintals total`}
          icon={<IndianRupee className="h-5 w-5" aria-hidden />}
          tone="earth"
          demo
        />
        <StatCard
          label={t("dashboard.farmHealth")}
          value="92%"
          sub="Good — 1 crop needs monitoring"
          icon={<CloudSun className="h-5 w-5" aria-hidden />}
          tone="sun"
          trend={{ dir: "up", value: "94 wk" }}
        />
      </section>

      {/* Revenue chart + weather */}
      <section className="mb-6 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title={t("dashboard.monthlyRevenue")}
            subtitle="Apr – Sep 2026 · sample data"
            action={<DemoBadge />}
          />
          <div className="px-3 pb-4">
            <ChartFrame minWidth={520} label="Monthly revenue chart">
              <RevenueAreaChart data={dashboardRevenue as unknown as Array<Record<string, string | number>>} />
            </ChartFrame>
          </div>
        </Card>

        <Card>
          <CardHeader
            title="Today's weather"
            subtitle={weatherData.location}
            icon={<CloudSun className="h-5 w-5" aria-hidden />}
            action={<Link href="/weather" aria-label="Open weather page" className="focus-ring rounded-lg p-1 text-charcoal-400 hover:text-forest-700"><ChevronRight className="h-5 w-5" aria-hidden /></Link>}
          />
          <div className="px-5 pb-5">
            <div className="flex items-center justify-between rounded-2xl bg-gradient-to-br from-sky-50 to-forest-50 p-4">
              <div>
                <p className="text-3xl font-extrabold text-charcoal-900">{weatherData.current.tempC}°</p>
                <p className="text-xs font-semibold capitalize text-charcoal-500">{weatherData.current.condition}</p>
              </div>
              <ul className="space-y-1 text-right text-xs font-semibold text-charcoal-600">
                <li>💧 {weatherData.current.humidity}% humidity</li>
                <li>🌧️ {weatherData.current.rainChance}% rain</li>
                <li>💨 {weatherData.current.windKmph} km/h</li>
              </ul>
            </div>
            <ul className="mt-3 space-y-1.5">
              {weatherData.recommendations.slice(0, 2).map((r) => (
                <li key={r.title} className="rounded-xl bg-beige-100 px-3 py-2 text-xs font-medium leading-snug text-charcoal-700">
                  <span className="font-bold text-forest-700">Advisory: </span>
                  {r.title}
                </li>
              ))}
            </ul>
          </div>
        </Card>
      </section>

      {/* Market prices + crop health + tasks */}
      <section className="mb-6 grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader
            title={t("dashboard.marketPrices")}
            subtitle="Your key crops · demo feed"
            icon={<IndianRupee className="h-5 w-5" aria-hidden />}
            action={<Link href="/market" className="focus-ring rounded-lg px-2 py-1 text-xs font-bold text-forest-700 hover:bg-forest-50">{t("common.viewAll")}</Link>}
          />
          <ul className="space-y-1 px-3 pb-4">
            {topPrices.map((p) => {
              const positive = p.changePct >= 0;
              return (
                <li key={p.id} className="flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-beige-100">
                  <span aria-hidden className="text-xl">{p.emoji}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-charcoal-900">{p.crop}</p>
                    <p className="text-[11px] text-charcoal-400">{p.market}</p>
                  </div>
                  <MiniSparkline data={p.history.slice(-14)} positive={positive} width={56} height={22} />
                  <div className="text-right">
                    <p className="text-sm font-extrabold text-charcoal-900">₹{p.modal.toLocaleString("en-IN")}</p>
                    <p className={cn("text-[11px] font-bold", positive ? "text-leaf-600" : "text-red-600")}>
                      {positive ? "▲" : "▼"} {Math.abs(p.changePct)}%
                    </p>
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>

        <Card>
          <CardHeader title={t("dashboard.cropHealth")} subtitle="Crops by growth stage" icon={<Sprout className="h-5 w-5" aria-hidden />} />
          <div className="px-5 pb-2">
            {stageData.length > 0 ? (
              <DonutChart data={stageData} />
            ) : (
              <p className="py-8 text-center text-sm text-charcoal-400">Add crops to see health overview</p>
            )}
            <ul className="mt-1 flex flex-wrap justify-center gap-x-3 gap-y-1 pb-3">
              {stageData.map((d) => (
                <li key={d.name} className="flex items-center gap-1.5 text-[11px] font-semibold text-charcoal-600">
                  <span className="h-2 w-2 rounded-full" style={{ backgroundColor: d.color }} aria-hidden />
                  {d.name} ({d.value})
                </li>
              ))}
            </ul>
          </div>
        </Card>

        <Card>
          <CardHeader
            title={t("dashboard.upcomingTasks")}
            subtitle={`${tasks.filter((task) => !task.done).length} pending`}
            icon={<CalendarCheck className="h-5 w-5" aria-hidden />}
          />
          <ul className="space-y-1 px-3 pb-4">
            {tasks.map((task) => (
              <li key={task.id}>
                <button
                  type="button"
                  onClick={() => toggleTask(task.id)}
                  className="focus-ring flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left hover:bg-beige-100"
                  aria-pressed={task.done}
                >
                  {task.done ? (
                    <CheckCircle2 className="h-5 w-5 shrink-0 text-leaf-600" aria-hidden />
                  ) : (
                    <Circle className="h-5 w-5 shrink-0 text-charcoal-300" aria-hidden />
                  )}
                  <span className="min-w-0 flex-1">
                    <span className={cn("block truncate text-sm font-semibold", task.done ? "text-charcoal-400 line-through" : "text-charcoal-800")}>
                      {task.title}
                    </span>
                    <span className="text-[11px] text-charcoal-400">
                      {task.crop} · {task.due}
                    </span>
                  </span>
                  <Badge variant={task.priority === "High" ? "danger" : task.priority === "Medium" ? "warning" : "neutral"}>
                    {task.priority}
                  </Badge>
                </button>
              </li>
            ))}
          </ul>
        </Card>
      </section>

      {/* Activity + harvest timeline */}
      <section className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader
            title={t("dashboard.recentActivity")}
            subtitle="Demo events"
            icon={<Store className="h-5 w-5" aria-hidden />}
            action={<Link href="/marketplace" className="focus-ring rounded-lg px-2 py-1 text-xs font-bold text-forest-700 hover:bg-forest-50">{t("common.viewAll")}</Link>}
          />
          <ul className="space-y-1 px-3 pb-4">
            {seedActivity.map((a) => {
              const Icon = ACTIVITY_ICONS[a.icon];
              return (
                <li key={a.id} className="flex items-start gap-3 rounded-xl px-2 py-2.5 hover:bg-beige-100">
                  <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-forest-50 text-forest-700">
                    <Icon className="h-4 w-4" aria-hidden />
                  </span>
                  <p className="flex-1 text-sm font-medium leading-snug text-charcoal-700">{a.text}</p>
                  <span className="shrink-0 text-[11px] font-semibold text-charcoal-400">{a.time}</span>
                </li>
              );
            })}
          </ul>
        </Card>

        <Card>
          <CardHeader
            title="Harvest timeline"
            subtitle="Nearest harvests first · from your crop log"
            icon={<Wheat className="h-5 w-5" aria-hidden />}
            action={<Link href="/crops" className="focus-ring rounded-lg px-2 py-1 text-xs font-bold text-forest-700 hover:bg-forest-50">{t("common.viewAll")}</Link>}
          />
          <ul className="space-y-3 px-5 pb-5">
            {[...activeCrops]
              .sort((a, b) => a.harvestDate.localeCompare(b.harvestDate))
              .slice(0, 4)
              .map((crop) => {
                const days = daysUntil(crop.harvestDate);
                return (
                  <li key={crop.id}>
                    <div className="mb-1.5 flex items-center justify-between gap-2 text-xs">
                      <span className="font-bold text-charcoal-800">
                        {cropEmoji(crop.name)} {crop.name}{" "}
                        <span className="font-medium text-charcoal-400">· {formatDateShort(crop.harvestDate)}</span>
                      </span>
                      <Badge variant={days < 0 ? "danger" : days <= 30 ? "success" : "neutral"}>
                        {days < 0 ? `${Math.abs(days)}d overdue` : days === 0 ? "Today" : `in ${days}d`}
                      </Badge>
                    </div>
                    <ProgressBar
                      percent={stageIndex(crop.stage) * (100 / 6)}
                      colorClass={STAGE_BAR_CLASS[crop.stage]}
                      label={`${crop.name} growth progress`}
                    />
                  </li>
                );
              })}
          </ul>
        </Card>
      </section>
    </div>
  );
}
