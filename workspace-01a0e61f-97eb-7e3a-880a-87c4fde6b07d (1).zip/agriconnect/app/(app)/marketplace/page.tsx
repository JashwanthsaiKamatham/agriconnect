"use client";

import { useEffect, useMemo, useState } from "react";
import {
  BadgeCheck,
  CalendarDays,
  Heart,
  Leaf,
  MapPin,
  MessageCircle,
  Phone,
  Plus,
  Search,
  Store,
  Weight,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import Modal from "@/components/ui/Modal";
import EmptyState from "@/components/ui/Feedback";
import { Input, Select } from "@/components/ui/Form";
import ListingFormModal from "@/components/forms/ListingFormModal";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import type { Listing } from "@/lib/types";
import { cn, cropEmoji, daysUntil, formatDate, formatINR } from "@/lib/utils";

const GRADE_STYLE: Record<Listing["grade"], string> = {
  A: "bg-leaf-600 text-white",
  B: "bg-charcoal-600 text-white",
};

export default function MarketplacePage() {
  usePageTitle("Marketplace");
  const { listings, savedListingIds, toggleSaveListing, toast, user, t } = useApp();

  const [query, setQuery] = useState("");
  const [cropFilter, setCropFilter] = useState("all");
  const [locationFilter, setLocationFilter] = useState("all");
  const [priceFilter, setPriceFilter] = useState("all");
  const [qtyFilter, setQtyFilter] = useState("all");
  const [formOpen, setFormOpen] = useState(false);
  const [contactFor, setContactFor] = useState<Listing | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [savedOnly, setSavedOnly] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined" && window.location.search.includes("add=1")) {
      setFormOpen(true);
      window.history.replaceState({}, "", "/marketplace");
    }
  }, []);

  const cropOptions = useMemo(
    () => Array.from(new Set(listings.map((l) => l.crop))).sort(),
    [listings]
  );
  const locationOptions = useMemo(
    () => Array.from(new Set(listings.map((l) => l.district))).sort(),
    [listings]
  );

  const filtered = useMemo(() => {
    let list = [...listings];
    const q = query.trim().toLowerCase();
    if (q)
      list = list.filter(
        (l) =>
          l.crop.toLowerCase().includes(q) ||
          (l.variety ?? "").toLowerCase().includes(q) ||
          l.farmer.toLowerCase().includes(q) ||
          l.location.toLowerCase().includes(q)
      );
    if (cropFilter !== "all") list = list.filter((l) => l.crop === cropFilter);
    if (locationFilter !== "all") list = list.filter((l) => l.district === locationFilter);
    if (priceFilter !== "all") {
      list = list.filter((l) =>
        priceFilter === "low" ? l.price < 2000 : priceFilter === "mid" ? l.price >= 2000 && l.price <= 7000 : l.price > 7000
      );
    }
    if (qtyFilter !== "all") {
      const toQuintals = (l: Listing) =>
        l.unit === "tonnes" ? l.quantity * 10 : l.unit === "kg" ? l.quantity / 100 : l.quantity;
      list = list.filter((l) =>
        qtyFilter === "small" ? toQuintals(l) < 10 : qtyFilter === "mid" ? toQuintals(l) >= 10 && toQuintals(l) <= 40 : toQuintals(l) > 40
      );
    }
    if (savedOnly) list = list.filter((l) => savedListingIds.includes(l.id));
    return list;
  }, [listings, query, cropFilter, locationFilter, priceFilter, qtyFilter, savedOnly, savedListingIds]);

  const clearFilters = () => {
    setQuery("");
    setCropFilter("all");
    setLocationFilter("all");
    setPriceFilter("all");
    setQtyFilter("all");
    setSavedOnly(false);
  };

  return (
    <div className="animate-fade-in">
      <PageHeader
        title={t("nav.marketplace")}
        subtitle="Sell your produce directly to verified buyers — zero commission, full transparency."
        demoNote="Demo listings. In production, buyers see this board the moment you publish."
        actions={
          <>
            <button
              type="button"
              onClick={() => setSavedOnly((s) => !s)}
              aria-pressed={savedOnly}
              className={cn(
                "focus-ring inline-flex items-center gap-2 rounded-xl border px-3.5 py-2 text-sm font-semibold transition-colors",
                savedOnly
                  ? "border-red-200 bg-red-50 text-red-600"
                  : "border-charcoal-200 bg-white text-charcoal-700 hover:border-forest-400"
              )}
            >
              <Heart className={cn("h-4 w-4", savedOnly && "fill-red-500 text-red-500")} aria-hidden />
              Saved ({savedListingIds.length})
            </button>
            <Button onClick={() => setFormOpen(true)} leftIcon={<Plus className="h-4 w-4" aria-hidden />}>
              Add produce listing
            </Button>
          </>
        }
      />

      {/* Filters */}
      <div className="mb-5 grid gap-3 rounded-2xl border border-charcoal-100 bg-white p-3 shadow-panel sm:grid-cols-2 lg:grid-cols-5">
        <div className="relative lg:col-span-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal-400" aria-hidden />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search produce, farmer, village…" aria-label="Search listings" className="pl-9" />
        </div>
        <Select value={cropFilter} onChange={(e) => setCropFilter(e.target.value)} aria-label="Filter by crop">
          <option value="all">All crops</option>
          {cropOptions.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </Select>
        <Select value={locationFilter} onChange={(e) => setLocationFilter(e.target.value)} aria-label="Filter by district">
          <option value="all">All districts</option>
          {locationOptions.map((d) => (
            <option key={d}>{d}</option>
          ))}
        </Select>
        <Select value={priceFilter} onChange={(e) => setPriceFilter(e.target.value)} aria-label="Filter by price">
          <option value="all">Any price</option>
          <option value="low">Under ₹2,000/q</option>
          <option value="mid">₹2,000 – ₹7,000/q</option>
          <option value="high">Above ₹7,000/q</option>
        </Select>
        <Select value={qtyFilter} onChange={(e) => setQtyFilter(e.target.value)} aria-label="Filter by quantity">
          <option value="all">Any quantity</option>
          <option value="small">Small (under 10 q)</option>
          <option value="mid">Medium (10–40 q)</option>
          <option value="large">Bulk (40 q +)</option>
        </Select>
      </div>

      <p className="mb-4 text-xs font-semibold text-charcoal-500">
        {filtered.length} listing{filtered.length === 1 ? "" : "s"}
        {savedOnly && " · saved only"}
      </p>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<Store className="h-7 w-7" aria-hidden />}
          title={listings.length === 0 ? "No listings yet" : "Nothing matches these filters"}
          body={
            listings.length === 0
              ? "Publish your first produce listing and let verified buyers come to you."
              : "Try widening the price range or clearing the location filter."
          }
          action={
            listings.length === 0 ? (
              <Button onClick={() => setFormOpen(true)} leftIcon={<Plus className="h-4 w-4" aria-hidden />}>
                Add produce listing
              </Button>
            ) : (
              <Button variant="outline" onClick={clearFilters}>
                Clear filters
              </Button>
            )
          }
        />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((l) => {
            const saved = savedListingIds.includes(l.id);
            const days = daysUntil(l.harvestDate);
            return (
              <Card key={l.id} className="overflow-hidden transition-shadow hover:shadow-lift">
                <div className="relative h-40 bg-beige-100">
                  {l.image ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={l.image} alt={`${l.crop} — ${l.quantity} ${l.unit}`} className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-forest-100 via-beige-200 to-earth-100 text-6xl">
                      {cropEmoji(l.crop)}
                    </div>
                  )}
                  <span className={cn("absolute left-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-extrabold shadow-sm", GRADE_STYLE[l.grade])}>
                    Grade {l.grade}
                  </span>
                  {l.organic && (
                    <span className="absolute left-3 top-10 rounded-full bg-leaf-100 px-2.5 py-1 text-[11px] font-extrabold text-leaf-800 shadow-sm">
                      🌿 Organic
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      toggleSaveListing(l.id);
                      toast(saved ? "Removed from saved listings." : "Listing saved for later.", saved ? "info" : "success");
                    }}
                    aria-label={saved ? `Remove ${l.crop} listing from saved` : `Save ${l.crop} listing`}
                    aria-pressed={saved}
                    className="focus-ring absolute right-3 top-3 rounded-full bg-white/95 p-2 shadow-sm hover:scale-105"
                  >
                    <Heart className={cn("h-4 w-4", saved ? "fill-red-500 text-red-500" : "text-charcoal-500")} aria-hidden />
                  </button>
                  <span className="absolute bottom-3 right-3 rounded-full bg-charcoal-900/80 px-2.5 py-1 text-[10px] font-bold text-white">
                    Listed {formatDate(l.createdAt)}
                  </span>
                </div>

                <div className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="truncate text-base font-extrabold text-charcoal-900">
                        {l.crop} {l.variety && <span className="text-xs font-semibold text-charcoal-400">· {l.variety}</span>}
                      </h3>
                      <p className="mt-0.5 flex items-center gap-1.5 text-xs font-semibold text-charcoal-500">
                        <BadgeCheck className={cn("h-3.5 w-3.5", l.verified ? "text-sky-600" : "text-charcoal-300")} aria-hidden />
                        {l.farmer}
                      </p>
                    </div>
                  </div>

                  <div className="mt-3 flex items-end justify-between gap-2">
                    <div>
                      <p className="text-xl font-extrabold tracking-tight text-forest-700">
                        {formatINR(l.price)}
                        <span className="text-xs font-bold text-charcoal-400">/q</span>
                      </p>
                      <p className="text-[11px] font-semibold text-charcoal-400">
                        ≈ {formatINR(l.unit === "tonnes" ? l.quantity * 10 * l.price : l.unit === "kg" ? (l.quantity / 100) * l.price : l.quantity * l.price)} total
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="flex items-center justify-end gap-1 text-sm font-bold text-charcoal-800">
                        <Weight className="h-3.5 w-3.5 text-earth-500" aria-hidden />
                        {l.quantity} {l.unit}
                      </p>
                    </div>
                  </div>

                  <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[11px] font-semibold text-charcoal-500">
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5" aria-hidden />
                      {l.location}, {l.district}
                    </span>
                    <span className="flex items-center gap-1">
                      <CalendarDays className="h-3.5 w-3.5" aria-hidden />
                      Ready {formatDate(l.harvestDate)}
                      {days >= 0 && days <= 7 && <Badge variant="success" className="ml-1">now</Badge>}
                    </span>
                  </div>

                  {l.description && (
                    <p className="mt-2.5 line-clamp-2 text-xs leading-relaxed text-charcoal-500">{l.description}</p>
                  )}

                  <div className="mt-4 flex gap-2">
                    <Button
                      size="sm"
                      fullWidth
                      leftIcon={<MessageCircle className="h-4 w-4" aria-hidden />}
                      onClick={() => {
                        setContactFor(l);
                        setRevealed(false);
                      }}
                    >
                      Contact seller
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })}
        </ul>
      )}

      {/* Add listing */}
      <ListingFormModal open={formOpen} onClose={() => setFormOpen(false)} />

      {/* Contact seller */}
      <Modal
        open={!!contactFor}
        onClose={() => setContactFor(null)}
        title={contactFor ? `${contactFor.crop} — ${contactFor.farmer}` : ""}
        subtitle="Direct contact · no commission, no middleman"
      >
        {contactFor && (
          <div className="space-y-4">
            <div className="rounded-2xl bg-beige-100 p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-extrabold text-charcoal-900">
                    {contactFor.quantity} {contactFor.unit} · Grade {contactFor.grade}
                  </p>
                  <p className="text-xs text-charcoal-500">
                    {formatINR(contactFor.price)}/quintal · {contactFor.location}, {contactFor.district}
                  </p>
                </div>
                <span aria-hidden className="text-3xl">{cropEmoji(contactFor.crop)}</span>
              </div>
              {contactFor.description && (
                <p className="mt-2 text-xs leading-relaxed text-charcoal-600">{contactFor.description}</p>
              )}
            </div>

            <div className="rounded-2xl border border-charcoal-100 p-4">
              <p className="text-xs font-bold uppercase tracking-wide text-charcoal-400">Seller number</p>
              {revealed ? (
                <p className="mt-1 text-lg font-extrabold tracking-wide text-forest-700" aria-live="polite">
                  +91 98480 {Math.abs(contactFor.id.length * 111) % 90000 + 10000}
                </p>
              ) : (
                <p className="mt-1 text-lg font-extrabold tracking-wide text-charcoal-300" aria-hidden>
                  +91 98480 •••••
                </p>
              )}
              <Button
                variant="outline"
                size="sm"
                className="mt-2"
                onClick={() => {
                  setRevealed(true);
                  toast("Number revealed — mention AgriConnect when you call!", "info");
                }}
                disabled={revealed}
              >
                {revealed ? "Revealed" : "Reveal number"}
              </Button>
            </div>

            <div className="flex flex-col gap-2 sm:flex-row">
              <Button href="#" fullWidth leftIcon={<Phone className="h-4 w-4" aria-hidden />} onClick={() => toast("Calling is disabled in the demo.", "info")}>
                Call now
              </Button>
              <Button
                variant="outline"
                fullWidth
                leftIcon={<Leaf className="h-4 w-4" aria-hidden />}
                onClick={() => toast("Sample message sent to the seller (demo).", "success")}
              >
                Send enquiry
              </Button>
            </div>
            <p className="text-center text-[11px] font-medium text-charcoal-400">
              You are viewing as {user?.name ?? "guest"} · demo contact flow
            </p>
          </div>
        )}
      </Modal>
    </div>
  );
}
