"use client";

import { useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  Droplets,
  Layers,
  Pencil,
  Plus,
  Search,
  Sprout,
  Trash2,
  TriangleAlert,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import Modal from "@/components/ui/Modal";
import EmptyState, { ProgressBar } from "@/components/ui/Feedback";
import { Input, Select } from "@/components/ui/Form";
import CropFormModal from "@/components/forms/CropFormModal";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { GROWTH_STAGES, type Crop } from "@/lib/types";
import {
  cn,
  cropEmoji,
  daysUntil,
  formatDate,
  formatINR,
  STAGE_BADGE_CLASS,
  STAGE_BAR_CLASS,
  stageIndex,
  STAGE_ORDER,
  stagePercent,
  estimateCropRevenue,
} from "@/lib/utils";

type SortKey = "harvest-asc" | "harvest-desc" | "name" | "recent";

export default function CropsPage() {
  usePageTitle("My Crops");
  const { crops, deleteCrop, toast, t } = useApp();

  const [query, setQuery] = useState("");
  const [stageFilter, setStageFilter] = useState<string>("all");
  const [sort, setSort] = useState<SortKey>("harvest-asc");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Crop | null>(null);
  const [deleting, setDeleting] = useState<Crop | null>(null);

  // Support "Add crop" quick action from the dashboard (?add=1)
  useEffect(() => {
    if (typeof window !== "undefined" && window.location.search.includes("add=1")) {
      setFormOpen(true);
      window.history.replaceState({}, "", "/crops");
    }
  }, []);

  const filtered = useMemo(() => {
    let list = [...crops];
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((c) => c.name.toLowerCase().includes(q) || c.variety.toLowerCase().includes(q));
    if (stageFilter !== "all") list = list.filter((c) => c.stage === stageFilter);
    switch (sort) {
      case "harvest-asc":
        list.sort((a, b) => a.harvestDate.localeCompare(b.harvestDate));
        break;
      case "harvest-desc":
        list.sort((a, b) => b.harvestDate.localeCompare(a.harvestDate));
        break;
      case "name":
        list.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case "recent":
        list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
        break;
    }
    return list;
  }, [crops, query, stageFilter, sort]);

  const openAdd = () => {
    setEditing(null);
    setFormOpen(true);
  };

  const openEdit = (crop: Crop) => {
    setEditing(crop);
    setFormOpen(true);
  };

  const confirmDelete = () => {
    if (!deleting) return;
    deleteCrop(deleting.id);
    toast(`"${deleting.name}" removed from your crops.`, "info");
    setDeleting(null);
  };

  return (
    <div className="animate-fade-in">
      <PageHeader
        title={t("nav.crops")}
        subtitle="Track every crop from planning to harvest. Demo data — your changes are saved on this device."
        actions={
          <Button onClick={openAdd} leftIcon={<Plus className="h-4 w-4" aria-hidden />}>
            {t("dashboard.addCrop")}
          </Button>
        }
      />

      {/* Toolbar */}
      <div className="mb-5 flex flex-col gap-3 rounded-2xl border border-charcoal-100 bg-white p-3 shadow-panel sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal-400" aria-hidden />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by crop or variety…"
            aria-label="Search crops"
            className="pl-9"
          />
        </div>
        <Select
          value={stageFilter}
          onChange={(e) => setStageFilter(e.target.value)}
          aria-label="Filter by growth stage"
          className="sm:w-48"
        >
          <option value="all">All growth stages</option>
          {GROWTH_STAGES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </Select>
        <Select
          value={sort}
          onChange={(e) => setSort(e.target.value as SortKey)}
          aria-label="Sort crops"
          className="sm:w-52"
        >
          <option value="harvest-asc">Harvest: soonest first</option>
          <option value="harvest-desc">Harvest: latest first</option>
          <option value="name">Name (A–Z)</option>
          <option value="recent">Recently added</option>
        </Select>
      </div>

      <p className="mb-4 text-xs font-semibold text-charcoal-500">
        {filtered.length} of {crops.length} crops
        {stageFilter !== "all" && ` · filtered by “${stageFilter}”`}
      </p>

      {/* States */}
      {crops.length === 0 ? (
        <EmptyState
          icon={<Sprout className="h-7 w-7" aria-hidden />}
          title="No crops yet"
          body="Add your first crop to unlock stage-wise advisories, harvest estimates and market insights."
          action={
            <Button onClick={openAdd} leftIcon={<Plus className="h-4 w-4" aria-hidden />}>
              {t("dashboard.addCrop")}
            </Button>
          }
        />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No crops match your filters"
          body="Try a different search term or clear the growth-stage filter."
          action={
            <Button
              variant="outline"
              onClick={() => {
                setQuery("");
                setStageFilter("all");
              }}
            >
              Clear filters
            </Button>
          }
        />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((crop) => {
            const days = daysUntil(crop.harvestDate);
            return (
              <li key={crop.id}>
                <Card className="overflow-hidden transition-shadow hover:shadow-lift">
                <div className="relative h-36 bg-beige-100">
                  {crop.image ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={crop.image} alt={`${crop.name} crop`} className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-forest-100 to-beige-200 text-5xl">
                      {cropEmoji(crop.name)}
                    </div>
                  )}
                  <span className="absolute left-3 top-3">
                    <Badge className={cn("!shadow-sm", STAGE_BADGE_CLASS[crop.stage])}>{crop.stage}</Badge>
                  </span>
                  <span className="absolute right-3 top-3">
                    <Badge
                      variant={days < 0 ? "danger" : days <= 30 ? "success" : "neutral"}
                      className="!bg-white/90 !text-charcoal-700"
                    >
                      {days < 0 ? `${Math.abs(days)}d overdue` : days === 0 ? "Harvest today" : `Harvest in ${days}d`}
                    </Badge>
                  </span>
                </div>

                <div className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="truncate text-base font-extrabold text-charcoal-900">{crop.name}</h3>
                      <p className="truncate text-xs font-medium text-charcoal-500">{crop.variety || "Local variety"}</p>
                    </div>
                    <div className="flex shrink-0 gap-1">
                      <button
                        type="button"
                        onClick={() => openEdit(crop)}
                        aria-label={`Edit ${crop.name}`}
                        className="focus-ring rounded-lg p-2 text-charcoal-400 hover:bg-forest-50 hover:text-forest-700"
                      >
                        <Pencil className="h-4 w-4" aria-hidden />
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeleting(crop)}
                        aria-label={`Delete ${crop.name}`}
                        className="focus-ring rounded-lg p-2 text-charcoal-400 hover:bg-red-50 hover:text-red-600"
                      >
                        <Trash2 className="h-4 w-4" aria-hidden />
                      </button>
                    </div>
                  </div>

                  <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 text-xs">
                    <div className="flex items-center gap-1.5 text-charcoal-600">
                      <Layers className="h-3.5 w-3.5 text-earth-500" aria-hidden />
                      <span className="font-semibold">{crop.area} {crop.areaUnit}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-charcoal-600">
                      <Droplets className="h-3.5 w-3.5 text-sky-600" aria-hidden />
                      <span className="font-semibold">{crop.irrigation}</span>
                    </div>
                    <div className="col-span-2 flex items-center gap-1.5 text-charcoal-600">
                      <CalendarDays className="h-3.5 w-3.5 text-forest-600" aria-hidden />
                      <span className="font-semibold">
                        {formatDate(crop.plantingDate)} → {formatDate(crop.harvestDate)}
                      </span>
                    </div>
                  </dl>

                  <div className="mt-3">
                    <div className="mb-1 flex items-center justify-between text-[11px] font-bold text-charcoal-500">
                      <span>{stagePercent(crop.stage)}% of lifecycle</span>
                      <span>Est. {crop.estimatedYield} t · {formatINR(estimateCropRevenue(crop))}</span>
                    </div>
                    <ProgressBar
                      percent={stagePercent(crop.stage)}
                      colorClass={STAGE_BAR_CLASS[crop.stage]}
                      label={`${crop.name} growth progress`}
                    />
                    <div className="mt-1.5 flex gap-0.5" aria-hidden>
                      {STAGE_ORDER.map((s, i) => (
                        <span
                          key={s}
                          className={cn("h-1 flex-1 rounded-full", i <= stageIndex(crop.stage) ? "bg-forest-500/70" : "bg-charcoal-100")}
                        />
                      ))}
                    </div>
                  </div>

                  {crop.notes && (
                    <p className="mt-3 line-clamp-2 rounded-xl bg-beige-100 px-3 py-2 text-[11px] font-medium leading-relaxed text-charcoal-600">
                      📝 {crop.notes}
                    </p>
                  )}
                </div>
                </Card>
              </li>
            );
          })}
        </ul>
      )}

      {/* Form modal (add / edit) */}
      <CropFormModal open={formOpen} onClose={() => setFormOpen(false)} editing={editing} />

      {/* Delete confirmation */}
      <Modal
        open={!!deleting}
        onClose={() => setDeleting(null)}
        title="Delete this crop?"
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setDeleting(null)}>
              {t("common.cancel")}
            </Button>
            <Button variant="danger" onClick={confirmDelete} leftIcon={<Trash2 className="h-4 w-4" aria-hidden />}>
              Delete crop
            </Button>
          </div>
        }
      >
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-100 text-red-600">
            <TriangleAlert className="h-5 w-5" aria-hidden />
          </span>
          <p className="text-sm leading-relaxed text-charcoal-600">
            <strong className="text-charcoal-900">{deleting?.name}</strong> ({deleting?.variety}) will be
            removed from your crop log, including its harvest estimates. This cannot be undone in the
            demo.
          </p>
        </div>
      </Modal>
    </div>
  );
}
