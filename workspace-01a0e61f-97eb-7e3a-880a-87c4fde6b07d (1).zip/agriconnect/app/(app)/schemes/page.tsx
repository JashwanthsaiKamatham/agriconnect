"use client";

import { useMemo, useState } from "react";
import {
  Bookmark,
  BookmarkCheck,
  CalendarClock,
  CheckCircle2,
  ExternalLink,
  FileText,
  Landmark,
  Search,
  ShieldCheck,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import EmptyState from "@/components/ui/Feedback";
import { Input, Select } from "@/components/ui/Form";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { schemes } from "@/lib/data/schemes";
import { cn } from "@/lib/utils";

const CROPS = ["All crops", "Paddy", "Cotton", "Maize", "Tomato", "Onion", "Groundnut", "Sugarcane", "Chilli"];
const CATEGORIES = ["All farmers", "Small farmers", "Marginal farmers", "SC/ST farmers", "Women farmers", "Tenant farmers", "FPOs"];
const BENEFITS = ["All benefits", "Income support", "Insurance", "Credit", "Subsidy", "Market access", "Training"];

export default function SchemesPage() {
  usePageTitle("Government Schemes");
  const { toast } = useApp();

  const [query, setQuery] = useState("");
  const [state, setState] = useState("all");
  const [crop, setCrop] = useState("all");
  const [category, setCategory] = useState("all");
  const [benefit, setBenefit] = useState("all");
  const [bookmarks, setBookmarks] = useState<string[]>([]);

  const stateOptions = useMemo(() => Array.from(new Set(schemes.map((s) => s.state))), []);

  const filtered = useMemo(() => {
    let list = [...schemes];
    const q = query.trim().toLowerCase();
    if (q)
      list = list.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.description.toLowerCase().includes(q) ||
          s.department.toLowerCase().includes(q)
      );
    if (state !== "all") list = list.filter((s) => s.state === state || s.state === "All India");
    if (crop !== "all") list = list.filter((s) => s.crops.includes(crop) || s.crops.includes("All crops"));
    if (category !== "all") list = list.filter((s) => s.category.includes(category));
    if (benefit !== "all") list = list.filter((s) => s.benefitType === benefit);
    return list;
  }, [query, state, crop, category, benefit]);

  const toggleBookmark = (id: string, name: string) => {
    const has = bookmarks.includes(id);
    setBookmarks((b) => (has ? b.filter((x) => x !== id) : [...b, id]));
    toast(has ? "Removed from bookmarks." : `${name} bookmarked.`, has ? "info" : "success");
  };

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Government Schemes"
        subtitle="Central and southern-state schemes matched to your farmer profile."
        demoNote="Always verify details and apply through the official government portal only."
      />

      {/* Disclaimer */}
      <div role="note" className="mb-5 flex items-start gap-3 rounded-2xl border border-earth-200 bg-earth-50 px-4 py-3.5">
        <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-earth-600" aria-hidden />
        <p className="text-xs font-semibold leading-relaxed text-earth-800">
          These summaries are sample data for demonstration. Scheme rules, deadlines and subsidies
          change — <strong>always check the official portal before applying</strong>. AgriConnect never
          charges for scheme applications.
        </p>
      </div>

      {/* Filters */}
      <div className="mb-5 grid gap-3 rounded-2xl border border-charcoal-100 bg-white p-3 shadow-panel sm:grid-cols-2 lg:grid-cols-5">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal-400" aria-hidden />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search schemes…" aria-label="Search schemes" className="pl-9" />
        </div>
        <Select value={state} onChange={(e) => setState(e.target.value)} aria-label="Filter by state">
          <option value="all">All states</option>
          {stateOptions.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </Select>
        <Select value={crop} onChange={(e) => setCrop(e.target.value)} aria-label="Filter by crop">
          {CROPS.map((c) => (
            <option key={c} value={c === "All crops" ? "all" : c}>
              {c}
            </option>
          ))}
        </Select>
        <Select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Filter by farmer category">
          {CATEGORIES.map((c) => (
            <option key={c} value={c === "All farmers" ? "all" : c}>
              {c}
            </option>
          ))}
        </Select>
        <Select value={benefit} onChange={(e) => setBenefit(e.target.value)} aria-label="Filter by benefit type">
          {BENEFITS.map((b) => (
            <option key={b} value={b === "All benefits" ? "all" : b}>
              {b}
            </option>
          ))}
        </Select>
      </div>

      <p className="mb-4 text-xs font-semibold text-charcoal-500">
        {filtered.length} scheme{filtered.length === 1 ? "" : "s"} found
        {bookmarks.length > 0 && ` · ${bookmarks.length} bookmarked`}
      </p>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<Landmark className="h-7 w-7" aria-hidden />}
          title="No schemes match"
          body="Try a different combination of filters — many schemes apply to all farmers."
          action={
            <Button variant="outline" onClick={() => { setQuery(""); setState("all"); setCrop("all"); setCategory("all"); setBenefit("all"); }}>
              Clear filters
            </Button>
          }
        />
      ) : (
        <ul className="grid gap-4 lg:grid-cols-2">
          {filtered.map((s) => {
            const marked = bookmarks.includes(s.id);
            return (
              <Card key={s.id} className="flex flex-col p-5 transition-shadow hover:shadow-lift">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge variant="forest">{s.benefitType}</Badge>
                      <Badge variant="earth">{s.state}</Badge>
                      {s.deadline.toLowerCase() !== "ongoing" && (
                        <Badge variant="warning">
                          <CalendarClock className="h-3 w-3" aria-hidden />
                          {s.deadline}
                        </Badge>
                      )}
                      {s.deadline.toLowerCase() === "ongoing" && <Badge variant="success">Ongoing</Badge>}
                    </div>
                    <h3 className="mt-2 text-base font-extrabold leading-snug text-charcoal-900">{s.name}</h3>
                    <p className="text-[11px] font-semibold text-charcoal-400">{s.department}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => toggleBookmark(s.id, s.name)}
                    aria-label={marked ? `Remove ${s.name} bookmark` : `Bookmark ${s.name}`}
                    aria-pressed={marked}
                    className="focus-ring rounded-xl p-2 text-charcoal-400 hover:bg-sun-100 hover:text-sun-600"
                  >
                    {marked ? (
                      <BookmarkCheck className="h-5 w-5 text-sun-600" aria-hidden />
                    ) : (
                      <Bookmark className="h-5 w-5" aria-hidden />
                    )}
                  </button>
                </div>

                <p className="mt-2.5 text-sm leading-relaxed text-charcoal-600">{s.description}</p>

                <div className="mt-3 rounded-xl bg-leaf-50 px-3.5 py-2.5">
                  <p className="text-[11px] font-extrabold uppercase tracking-wide text-leaf-800">Key benefits</p>
                  <ul className="mt-1 space-y-1">
                    {s.benefits.map((b) => (
                      <li key={b} className="flex items-start gap-1.5 text-xs font-medium leading-snug text-charcoal-700">
                        <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-leaf-600" aria-hidden />
                        {b}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-3">
                  <p className="text-[11px] font-extrabold uppercase tracking-wide text-charcoal-400">Eligibility</p>
                  <p className="mt-1 text-xs font-semibold leading-relaxed text-charcoal-700">{s.eligibility}</p>
                </div>

                <div className="mt-3">
                  <p className="text-[11px] font-extrabold uppercase tracking-wide text-charcoal-400">
                    Required documents
                  </p>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {s.documents.map((d) => (
                      <span key={d} className="inline-flex items-center gap-1 rounded-full bg-beige-100 px-2.5 py-1 text-[11px] font-semibold text-charcoal-600">
                        <FileText className="h-3 w-3 text-earth-500" aria-hidden />
                        {d}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-auto flex items-center justify-between gap-3 border-t border-charcoal-100 pt-4">
                  <p className={cn("text-xs font-bold", s.deadline.toLowerCase() === "ongoing" ? "text-leaf-700" : "text-red-600")}>
                    {s.deadline.toLowerCase() === "ongoing" ? "Applications open" : `Apply before ${s.deadline}`}
                  </p>
                  <Button
                    size="sm"
                    rightIcon={<ExternalLink className="h-3.5 w-3.5" aria-hidden />}
                    onClick={() =>
                      toast("Demo: in production this opens the official government portal.", "info")
                    }
                  >
                    Apply
                  </Button>
                </div>
              </Card>
            );
          })}
        </ul>
      )}
    </div>
  );
}
