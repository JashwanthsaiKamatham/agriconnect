"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  BadgeCheck,
  CalendarDays,
  MapPin,
  Search,
  Star,
  Truck,
  Wrench,
} from "lucide-react";
import PageHeader from "@/components/ui/PageHeader";
import { Card } from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import Modal from "@/components/ui/Modal";
import EmptyState from "@/components/ui/Feedback";
import { Field, Input, Select, Textarea } from "@/components/ui/Form";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { equipmentItems } from "@/lib/data/logistics";
import type { EquipmentItem } from "@/lib/types";
import { cn, daysUntil, formatDate, formatINR } from "@/lib/utils";

const CATEGORIES = ["All", "Tractor", "Rotavator", "Seed Drill", "Sprayer", "Harvester"] as const;

export default function EquipmentPage() {
  usePageTitle("Equipment");
  const { addRental, rentals, user, toast } = useApp();

  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("All");
  const [district, setDistrict] = useState("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [booking, setBooking] = useState<EquipmentItem | null>(null);
  const [form, setForm] = useState({ start: "", end: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const today = new Date();
    const iso = (d: Date) => d.toISOString().slice(0, 10);
    const start = new Date(today);
    start.setDate(start.getDate() + 1);
    const end = new Date(today);
    end.setDate(end.getDate() + 3);
    setFromDate(iso(start));
    setToDate(iso(end));
  }, []);

  useEffect(() => {
    if (booking) setForm({ start: fromDate, end: toDate, message: "" });
  }, [booking, fromDate, toDate]);

  const districts = useMemo(
    () => Array.from(new Set(equipmentItems.map((e) => e.district))),
    []
  );

  const filtered = useMemo(() => {
    let list = [...equipmentItems];
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((e) => e.name.toLowerCase().includes(q) || e.owner.toLowerCase().includes(q));
    if (category !== "All") list = list.filter((e) => e.category === category);
    if (district !== "all") list = list.filter((e) => e.district === district);
    return list;
  }, [query, category, district]);

  const days =
    form.start && form.end && form.end >= form.start
      ? Math.round((Date.parse(form.end) - Date.parse(form.start)) / 86400000) + 1
      : 0;

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.start) e.start = "Start date is required";
    if (!form.end) e.end = "End date is required";
    if (form.start && form.end && form.end < form.start) e.end = "End date must be after the start date";
    return e;
  };

  const submitBooking = async (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length > 0 || !booking) return;
    setSaving(true);
    await new Promise((r) => setTimeout(r, 700));
    addRental({
      equipmentId: booking.id,
      equipmentName: booking.name,
      owner: booking.owner,
      startDate: form.start,
      endDate: form.end,
      totalEstimate: days * booking.pricePerDay,
    });
    setSaving(false);
    setBooking(null);
    toast(`Booking request sent to ${booking.owner}!`, "success");
  };

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Equipment Rental"
        subtitle="Rent tractors, tillers and harvesters from owners near you — at fair, transparent day rates."
        demoNote="Demo catalogue with sample owners and rates."
      />

      {/* My bookings */}
      {rentals.length > 0 && (
        <Card className="mb-5">
          <div className="flex items-center justify-between px-5 pt-4 pb-1">
            <h2 className="text-sm font-bold text-charcoal-900">My rental requests ({rentals.length})</h2>
            <Badge variant="warning">{rentals[0].status}</Badge>
          </div>
          <ul className="divide-y divide-charcoal-50 px-5 pb-3">
            {rentals.map((r) => (
              <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <div>
                  <p className="text-sm font-bold text-charcoal-900">{r.equipmentName}</p>
                  <p className="text-[11px] text-charcoal-500">
                    {formatDate(r.startDate)} → {formatDate(r.endDate)} · {r.owner}
                  </p>
                </div>
                <p className="text-sm font-extrabold text-forest-700">{formatINR(r.totalEstimate)}</p>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {/* Filters */}
      <div className="mb-5 grid gap-3 rounded-2xl border border-charcoal-100 bg-white p-3 shadow-panel sm:grid-cols-2 lg:grid-cols-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-charcoal-400" aria-hidden />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search machine or owner…" aria-label="Search equipment" className="pl-9" />
        </div>
        <Select value={district} onChange={(e) => setDistrict(e.target.value)} aria-label="Filter by district">
          <option value="all">All districts</option>
          {districts.map((d) => (
            <option key={d}>{d}</option>
          ))}
        </Select>
        <Input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} aria-label="Rental from date" />
        <Input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} aria-label="Rental to date" />
      </div>

      {/* Category chips */}
      <div className="mb-5 flex gap-2 overflow-x-auto pb-1 scrollbar-thin" role="group" aria-label="Equipment category">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setCategory(c)}
            aria-pressed={category === c}
            className={cn(
              "focus-ring shrink-0 rounded-full border px-4 py-2 text-sm font-bold transition-colors",
              category === c
                ? "border-forest-600 bg-forest-600 text-white"
                : "border-charcoal-200 bg-white text-charcoal-600 hover:border-forest-400"
            )}
          >
            {c}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon={<Wrench className="h-7 w-7" aria-hidden />}
          title="No equipment matches"
          body="Try another category or clear the district filter."
          action={
            <Button variant="outline" onClick={() => { setQuery(""); setCategory("All"); setDistrict("all"); }}>
              Clear filters
            </Button>
          }
        />
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((eq) => (
            <Card key={eq.id} className="overflow-hidden transition-shadow hover:shadow-lift">
              <div className="relative h-40">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={eq.image} alt={eq.name} className="h-full w-full object-cover" />
                <span className="absolute left-3 top-3">
                  <Badge variant={eq.available ? "success" : "neutral"} className="!bg-white/95 !text-charcoal-800">
                    {eq.available ? "● Available" : "○ Booked"}
                  </Badge>
                </span>
                <span className="absolute right-3 top-3 rounded-full bg-charcoal-900/80 px-2.5 py-1 text-[11px] font-extrabold text-white">
                  {formatINR(eq.pricePerDay)}/day
                </span>
              </div>
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <h3 className="truncate text-sm font-extrabold text-charcoal-900">{eq.name}</h3>
                    <p className="mt-0.5 truncate text-xs font-semibold text-charcoal-500">
                      <BadgeCheck className="mr-1 inline h-3.5 w-3.5 text-sky-600" aria-hidden />
                      {eq.owner}
                    </p>
                  </div>
                  <span className="flex shrink-0 items-center gap-1 rounded-lg bg-sun-100 px-2 py-1 text-xs font-extrabold text-sun-600">
                    <Star className="h-3.5 w-3.5 fill-current" aria-hidden />
                    {eq.rating}
                  </span>
                </div>
                <p className="mt-2 text-[11px] font-medium text-charcoal-500">{eq.specs}</p>
                <div className="mt-2.5 flex flex-wrap gap-x-3 gap-y-1 text-[11px] font-semibold text-charcoal-500">
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3.5 w-3.5" aria-hidden />
                    {eq.location}, {eq.district}
                  </span>
                  {eq.delivery && (
                    <span className="flex items-center gap-1 text-forest-700">
                      <Truck className="h-3.5 w-3.5" aria-hidden />
                      Delivery available
                    </span>
                  )}
                  <span>{eq.trips} rentals</span>
                </div>
                <Button
                  className="mt-3.5"
                  fullWidth
                  disabled={!eq.available}
                  onClick={() => setBooking(eq)}
                >
                  {eq.available ? "Book equipment" : "Currently booked"}
                </Button>
              </div>
            </Card>
          ))}
        </ul>
      )}

      {/* Booking modal */}
      <Modal
        open={!!booking}
        onClose={() => setBooking(null)}
        title={booking ? `Book ${booking.name}` : ""}
        subtitle={booking ? `Owner: ${booking.owner} · ${booking.location}` : ""}
        footer={
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            {days > 0 && booking && (
              <p className="text-sm font-bold text-charcoal-700">
                {days} day{days > 1 ? "s" : ""} × {formatINR(booking.pricePerDay)} ={" "}
                <span className="text-forest-700">{formatINR(days * booking.pricePerDay)}</span>
              </p>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setBooking(null)}>
                Cancel
              </Button>
              <Button type="submit" form="rental-form" loading={saving}>
                Confirm request
              </Button>
            </div>
          </div>
        }
      >
        <form id="rental-form" onSubmit={submitBooking} noValidate className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="From date" htmlFor="rent-from" required error={errors.start}>
              <Input
                id="rent-from"
                type="date"
                value={form.start}
                onChange={(e) => {
                  setForm((f) => ({ ...f, start: e.target.value }));
                  setErrors((er) => ({ ...er, start: "" }));
                }}
                error={errors.start}
              />
            </Field>
            <Field label="To date" htmlFor="rent-to" required error={errors.end}>
              <Input
                id="rent-to"
                type="date"
                value={form.end}
                onChange={(e) => {
                  setForm((f) => ({ ...f, end: e.target.value }));
                  setErrors((er) => ({ ...er, end: "" }));
                }}
                error={errors.end}
              />
            </Field>
          </div>
          <Field label="Message to owner" htmlFor="rent-msg" hint="Your crop, land size and task — owners reply faster">
            <Textarea
              id="rent-msg"
              value={form.message}
              onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
              placeholder="e.g. Need rotavator for 3 acres seedbed prep before paddy transplanting"
            />
          </Field>
          <div className="rounded-xl bg-leaf-50 px-4 py-3 text-xs font-semibold text-leaf-800">
            <CalendarDays className="mr-1.5 inline h-4 w-4" aria-hidden />
            Free cancellation until 12 hours before {user?.farm?.village ? "delivery" : "pickup"} · payment on
            completion (demo).
          </div>
        </form>
      </Modal>
    </div>
  );
}
