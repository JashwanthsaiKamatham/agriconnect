import { NextResponse } from "next/server";
import { seedCrops } from "@/lib/data/crops";

/**
 * GET /api/crops — returns the demo farmer's crops.
 *
 * Production version: read from the `crops` table filtered by the authenticated
 * user's farm (see database/schema.sql). The shape matches `lib/types.ts` → Crop.
 */
export async function GET() {
  return NextResponse.json({
    ok: true,
    demo: true,
    count: seedCrops.length,
    crops: seedCrops,
  });
}
