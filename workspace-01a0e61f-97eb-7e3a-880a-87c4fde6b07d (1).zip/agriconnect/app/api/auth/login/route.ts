import { NextResponse } from "next/server";
import { DEMO_USER } from "@/lib/context/AppContext";

/**
 * POST /api/auth/login — demo authentication endpoint.
 *
 * In production, replace the body with a real credential check:
 *   1. look up the user by email/phone (Prisma/Drizzle query)
 *   2. verify the password hash (bcrypt/argon2)
 *   3. issue a signed session JWT (NextAuth / custom)
 * The client contract (JSON below) stays the same.
 */
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { demo?: boolean; identifier?: string };

    // Simulated latency for a realistic loading state.
    await new Promise((r) => setTimeout(r, 600));

    if (!body.demo && !body.identifier) {
      return NextResponse.json(
        { ok: false, error: "Email or mobile number is required" },
        { status: 400 }
      );
    }

    return NextResponse.json({
      ok: true,
      user: {
        id: DEMO_USER.id,
        name: DEMO_USER.name,
        role: DEMO_USER.role,
        onboarded: DEMO_USER.onboarded,
      },
      // token: "<JWT in production>"
    });
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }
}
