import { NextResponse } from "next/server";

/**
 * POST /api/auth/signup — demo registration endpoint.
 *
 * Production version would:
 *   1. validate the payload with zod
 *   2. hash the password (never store plain text)
 *   3. insert into the `users` table (see database/schema.sql)
 *   4. send an OTP to the mobile number via the SMS provider
 */
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      name?: string;
      phone?: string;
      email?: string;
      role?: string;
    };

    await new Promise((r) => setTimeout(r, 700));

    if (!body.name || (!body.phone && !body.email)) {
      return NextResponse.json(
        { ok: false, error: "Name and (mobile or email) are required" },
        { status: 400 }
      );
    }

    return NextResponse.json({
      ok: true,
      user: {
        id: `u-${Date.now()}`,
        name: body.name,
        role: body.role ?? "farmer",
        onboarded: false,
      },
    });
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body" }, { status: 400 });
  }
}
