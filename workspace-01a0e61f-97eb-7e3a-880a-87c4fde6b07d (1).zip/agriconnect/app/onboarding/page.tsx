"use client";

import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import {
  UserRound,
  MapPin,
  Mountain,
  Sprout,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  ImagePlus,
  MapPinned,
  PartyPopper,
} from "lucide-react";
import Button from "@/components/ui/Button";
import { Field, Input, Select } from "@/components/ui/Form";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { LANGUAGES } from "@/lib/i18n/translations";
import type { Farm, IrrigationType, Lang, SoilType } from "@/lib/types";
import { cn } from "@/lib/utils";

const SOILS: SoilType[] = ["Black", "Red", "Alluvial", "Sandy loam", "Loamy", "Laterite"];
const IRRIGATIONS: IrrigationType[] = ["Rain-fed", "Canal", "Borewell", "Drip", "Sprinkler", "Flood"];
const CROP_OPTIONS = ["Paddy", "Cotton", "Tomato", "Maize", "Onion", "Groundnut", "Chilli", "Sugarcane", "Millet", "Banana", "Mango", "Wheat"];

const STEPS = [
  { title: "Your profile", icon: UserRound },
  { title: "Farm location", icon: MapPin },
  { title: "Land & soil", icon: Mountain },
  { title: "Crops & experience", icon: Sprout },
];

export default function OnboardingPage() {
  const router = useRouter();
  usePageTitle("Set up your farm");
  const { user, hydrated, completeOnboarding, updateUser, setLang, toast } = useApp();

  const [step, setStep] = useState(0);
  const [photo, setPhoto] = useState<string | undefined>();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const [values, setValues] = useState({
    name: "",
    phone: "",
    language: "en" as Lang,
    village: "",
    district: "",
    state: "Andhra Pradesh",
    pincode: "",
    locationCoords: "",
    area: "",
    areaUnit: "acres" as "acres" | "hectares",
    soilType: "Black" as SoilType,
    irrigationType: "Borewell" as IrrigationType,
    cropsGrown: [] as string[],
    experienceYears: "",
    preferredMarket: "",
  });

  useEffect(() => {
    if (!hydrated) return;
    if (!user) {
      router.replace("/login");
      return;
    }
    setValues((v) => ({
      ...v,
      name: v.name || user.name,
      phone: v.phone || user.phone || "",
      language: user.language,
    }));
  }, [hydrated, user, router]);

  const set = (key: keyof typeof values) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setValues((v) => ({ ...v, [key]: e.target.value }));
    setErrors((er) => ({ ...er, [key]: "" }));
  };

  const toggleCrop = (crop: string) =>
    setValues((v) => ({
      ...v,
      cropsGrown: v.cropsGrown.includes(crop) ? v.cropsGrown.filter((c) => c !== crop) : [...v.cropsGrown, crop],
    }));

  const validateStep = (s: number): boolean => {
    const e: Record<string, string> = {};
    if (s === 0) {
      if (!values.name.trim()) e.name = "Your name is required";
      if (!values.phone.trim()) e.phone = "Mobile number is required";
      else if (!/^(\+91[\s-]?)?[6-9]\d{9}$/.test(values.phone.replace(/[\s-]/g, "")))
        e.phone = "Enter a valid 10-digit mobile number";
    }
    if (s === 1) {
      if (!values.village.trim()) e.village = "Village is required";
      if (!values.district.trim()) e.district = "District is required";
      if (!values.state.trim()) e.state = "State is required";
      if (!/^\d{6}$/.test(values.pincode)) e.pincode = "Enter a valid 6-digit PIN code";
    }
    if (s === 2) {
      const a = Number(values.area);
      if (!values.area || Number.isNaN(a) || a <= 0) e.area = "Enter your total land area";
    }
    if (s === 3) {
      if (values.cropsGrown.length === 0) e.cropsGrown = "Select at least one crop";
      if (values.experienceYears && (Number(values.experienceYears) < 0 || Number(values.experienceYears) > 80))
        e.experienceYears = "Enter a valid number of years";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (validateStep(step)) setStep((s) => Math.min(s + 1, STEPS.length - 1));
  };
  const back = () => setStep((s) => Math.max(s - 1, 0));

  const finish = async () => {
    if (!validateStep(3)) return;
    setSaving(true);
    await new Promise((r) => setTimeout(r, 800));
    const farm: Farm = {
      village: values.village.trim(),
      district: values.district.trim(),
      state: values.state,
      pincode: values.pincode,
      area: Number(values.area),
      areaUnit: values.areaUnit,
      soilType: values.soilType,
      irrigationType: values.irrigationType,
      experienceYears: values.experienceYears ? Number(values.experienceYears) : undefined,
      preferredMarket: values.preferredMarket || undefined,
      cropsGrown: values.cropsGrown,
    };
    setLang(values.language);
    updateUser({
      name: values.name.trim() || user?.name,
      phone: values.phone.trim() || user?.phone,
      language: values.language,
      photoDataUrl: photo,
    });
    completeOnboarding(farm);
    setSaving(false);
    setDone(true);
  };

  const progress = useMemo(() => ((step + (done ? 1 : 0)) / STEPS.length) * 100, [step, done]);

  if (done) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-forest-50 to-beige-50 px-4">
        <div className="w-full max-w-md rounded-3xl border border-charcoal-100 bg-white p-8 text-center shadow-card animate-fade-in-up">
          <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-leaf-100 text-leaf-700">
            <PartyPopper className="h-8 w-8" aria-hidden />
          </span>
          <h1 className="mt-5 text-2xl font-extrabold text-charcoal-900">Your farm is ready! 🌾</h1>
          <p className="mt-2 text-sm leading-relaxed text-charcoal-600">
            Welcome to AgriConnect, {values.name.split(" ")[0]}. Your dashboard is preloaded with
            sample crops so you can explore everything right away.
          </p>
                  <Button href="/dashboard" size="lg" fullWidth className="mt-6" onClick={() => toast("Welcome to AgriConnect!", "success")}>
            Go to my dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-forest-50/60 to-beige-50 px-4 py-8 sm:py-12">
      <div className="mx-auto max-w-xl">
        {/* Progress header */}
        <div className="mb-6">
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-forest-700">Farm setup</p>
          <h1 className="mt-1 text-2xl font-extrabold tracking-tight text-charcoal-900">
            Tell us about your farm
          </h1>
          <div className="mt-4 flex items-center gap-2" role="group" aria-label={`Step ${step + 1} of ${STEPS.length}`}>
            {STEPS.map((s, i) => {
              const Icon = s.icon;
              const active = i === step;
              const complete = i < step;
              return (
                <div key={s.title} className="flex flex-1 flex-col items-center gap-1.5">
                  <span
                    className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-2xl border-2 transition-colors",
                      complete
                        ? "border-leaf-500 bg-leaf-500 text-white"
                        : active
                          ? "border-forest-600 bg-forest-600 text-white"
                          : "border-charcoal-200 bg-white text-charcoal-400"
                    )}
                  >
                    {complete ? <CheckCircle2 className="h-5 w-5" aria-hidden /> : <Icon className="h-5 w-5" aria-hidden />}
                  </span>
                  <span className={cn("hidden text-[10px] font-bold sm:block", active ? "text-forest-700" : "text-charcoal-400")}>
                    {s.title}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-charcoal-100" role="progressbar" aria-valuenow={Math.round(progress)} aria-valuemin={0} aria-valuemax={100}>
            <div className="h-full rounded-full bg-forest-600 transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>
          <p className="mt-1.5 text-xs font-semibold text-charcoal-400">
            Step {step + 1} of {STEPS.length} — {STEPS[step].title}
          </p>
        </div>

        <div className="rounded-3xl border border-charcoal-100 bg-white p-6 shadow-card sm:p-8">
          {step === 0 && (
            <div className="space-y-4 animate-fade-in">
              <Field label="Farmer name" htmlFor="ob-name" required error={errors.name}>
                <Input id="ob-name" value={values.name} onChange={set("name")} error={errors.name} placeholder="e.g. Ravi Kumar" />
              </Field>
              <Field label="Profile photo" htmlFor="ob-photo">
                <div className="flex items-center gap-4">
                  {photo ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={photo} alt="Profile preview" className="h-16 w-16 rounded-full border border-charcoal-100 object-cover" />
                  ) : (
                    <span className="flex h-16 w-16 items-center justify-center rounded-full bg-forest-100 text-forest-700">
                      <UserRound className="h-7 w-7" aria-hidden />
                    </span>
                  )}
                  <label className="focus-ring inline-flex cursor-pointer items-center gap-2 rounded-xl border border-charcoal-200 bg-white px-4 py-2.5 text-sm font-semibold text-charcoal-700 hover:border-forest-400">
                    <ImagePlus className="h-4 w-4" aria-hidden />
                    Upload photo
                    <input
                      id="ob-photo"
                      type="file"
                      accept="image/*"
                      className="sr-only"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (!f) return;
                        const reader = new FileReader();
                        reader.onload = () => setPhoto(String(reader.result));
                        reader.readAsDataURL(f);
                      }}
                    />
                  </label>
                </div>
              </Field>
              <Field label="Mobile number" htmlFor="ob-phone" required error={errors.phone}>
                <Input id="ob-phone" type="tel" value={values.phone} onChange={set("phone")} error={errors.phone} placeholder="98480 11223" />
              </Field>
              <Field label="Preferred language" htmlFor="ob-lang">
                <Select id="ob-lang" value={values.language} onChange={set("language")}>
                  {LANGUAGES.map((l) => (
                    <option key={l.code} value={l.code}>
                      {l.native} ({l.label})
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4 animate-fade-in">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Village" htmlFor="ob-village" required error={errors.village}>
                  <Input id="ob-village" value={values.village} onChange={set("village")} error={errors.village} placeholder="e.g. Veldurthi" />
                </Field>
                <Field label="District" htmlFor="ob-district" required error={errors.district}>
                  <Input id="ob-district" value={values.district} onChange={set("district")} error={errors.district} placeholder="e.g. Kurnool" />
                </Field>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="State" htmlFor="ob-state" required error={errors.state}>
                  <Select id="ob-state" value={values.state} onChange={set("state")} error={errors.state}>
                    <option>Andhra Pradesh</option>
                    <option>Telangana</option>
                    <option>Karnataka</option>
                    <option>Tamil Nadu</option>
                    <option>Maharashtra</option>
                    <option>Other</option>
                  </Select>
                </Field>
                <Field label="PIN code" htmlFor="ob-pin" required error={errors.pincode}>
                  <Input id="ob-pin" inputMode="numeric" maxLength={6} value={values.pincode} onChange={set("pincode")} error={errors.pincode} placeholder="518218" />
                </Field>
              </div>
              <Field label="Farm location (GPS)" htmlFor="ob-coords" hint="Optional — used for precise weather and maps">
                <div className="flex gap-2">
                  <Input id="ob-coords" value={values.locationCoords} onChange={set("locationCoords")} placeholder="15.57° N, 77.58° E" className="flex-1" />
                  <Button
                    variant="outline"
                    leftIcon={<MapPinned className="h-4 w-4" aria-hidden />}
                    onClick={() => {
                      if (typeof navigator !== "undefined" && navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(
                          (pos) => {
                            setValues((v) => ({
                              ...v,
                              locationCoords: `${pos.coords.latitude.toFixed(2)}° N, ${pos.coords.longitude.toFixed(2)}° E`,
                            }));
                            toast("Farm location captured.", "success");
                          },
                          () => toast("Location permission denied — you can type it instead.", "warning")
                        );
                      } else {
                        toast("GPS not available on this device.", "warning");
                      }
                    }}
                  >
                    Use GPS
                  </Button>
                </div>
              </Field>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4 animate-fade-in">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Total land area" htmlFor="ob-area" required error={errors.area}>
                  <Input id="ob-area" type="number" min="0" step="0.1" value={values.area} onChange={set("area")} error={errors.area} placeholder="e.g. 14.5" />
                </Field>
                <Field label="Land unit" htmlFor="ob-unit">
                  <Select id="ob-unit" value={values.areaUnit} onChange={set("areaUnit")}>
                    <option value="acres">Acres</option>
                    <option value="hectares">Hectares</option>
                  </Select>
                </Field>
              </div>
              <Field label="Soil type" htmlFor="ob-soil" hint="Not sure? A free Soil Health Card test can tell you.">
                <Select id="ob-soil" value={values.soilType} onChange={set("soilType")}>
                  {SOILS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Irrigation type" htmlFor="ob-irrigation">
                <Select id="ob-irrigation" value={values.irrigationType} onChange={set("irrigationType")}>
                  {IRRIGATIONS.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4 animate-fade-in">
              <fieldset>
                <legend className="mb-1.5 text-xs font-semibold text-charcoal-700">
                  Crops you grow <span className="ml-0.5 text-red-500" aria-hidden>*</span>
                </legend>
                <div className="flex flex-wrap gap-2">
                  {CROP_OPTIONS.map((crop) => {
                    const active = values.cropsGrown.includes(crop);
                    return (
                      <button
                        key={crop}
                        type="button"
                        onClick={() => {
                          toggleCrop(crop);
                          setErrors((er) => ({ ...er, cropsGrown: "" }));
                        }}
                        aria-pressed={active}
                        className={cn(
                          "focus-ring rounded-full border px-3.5 py-1.5 text-sm font-semibold transition-colors",
                          active
                            ? "border-forest-600 bg-forest-600 text-white"
                            : "border-charcoal-200 bg-white text-charcoal-600 hover:border-forest-400"
                        )}
                      >
                        {crop}
                      </button>
                    );
                  })}
                </div>
                {errors.cropsGrown && <p className="mt-1.5 text-xs font-medium text-red-600" role="alert">{errors.cropsGrown}</p>}
              </fieldset>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Farming experience (years)" htmlFor="ob-exp" error={errors.experienceYears}>
                  <Input id="ob-exp" type="number" min="0" max="80" value={values.experienceYears} onChange={set("experienceYears")} error={errors.experienceYears} placeholder="e.g. 12" />
                </Field>
                <Field label="Preferred market" htmlFor="ob-market">
                  <Select id="ob-market" value={values.preferredMarket} onChange={set("preferredMarket")}>
                    <option value="">Select…</option>
                    <option>Kurnool APMC</option>
                    <option>Guntur APMC</option>
                    <option>Raichur APMC</option>
                    <option>Warangal APMC</option>
                    <option>Direct buyers (marketplace)</option>
                  </Select>
                </Field>
              </div>
            </div>
          )}

          {/* Controls */}
          <div className="mt-8 flex items-center justify-between border-t border-charcoal-100 pt-5">
            <Button variant="ghost" onClick={back} disabled={step === 0} leftIcon={<ArrowLeft className="h-4 w-4" aria-hidden />}>
              Back
            </Button>
            {step < STEPS.length - 1 ? (
              <Button onClick={next} rightIcon={<ArrowRight className="h-4 w-4" aria-hidden />}>
                Continue
              </Button>
            ) : (
              <Button onClick={finish} loading={saving}>
                Complete setup
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
