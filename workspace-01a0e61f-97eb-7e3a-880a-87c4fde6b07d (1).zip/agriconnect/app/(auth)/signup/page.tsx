"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  UserRound,
  Briefcase,
  GraduationCap,
  Tractor,
  Truck,
  ShieldCheck,
  CheckCircle2,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import Button from "@/components/ui/Button";
import { Field, Input, Select } from "@/components/ui/Form";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { LANGUAGES, translate } from "@/lib/i18n/translations";
import type { Lang, Role } from "@/lib/types";
import { cn } from "@/lib/utils";

const ROLE_OPTIONS: Array<{ role: Role; label: string; icon: LucideIcon; preview?: boolean }> = [
  { role: "farmer", label: "Farmer", icon: UserRound },
  { role: "buyer", label: "Buyer / Trader", icon: Briefcase, preview: true },
  { role: "expert", label: "Agri Expert", icon: GraduationCap, preview: true },
  { role: "supplier", label: "Equipment Supplier", icon: Tractor, preview: true },
  { role: "logistics", label: "Logistics Provider", icon: Truck, preview: true },
  { role: "admin", label: "Administrator", icon: ShieldCheck, preview: true },
];

export default function SignupPage() {
  const router = useRouter();
  const { user, hydrated, signup, toast, t } = useApp();
  usePageTitle("Sign up");

  const [values, setValues] = useState({
    name: "",
    role: "farmer" as Role,
    phone: "",
    email: "",
    language: "en" as Lang,
    password: "",
    confirm: "",
    terms: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (hydrated && user) router.replace(user.onboarded ? "/dashboard" : "/onboarding");
  }, [hydrated, user, router]);

  const set = (key: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const target = e.target;
    const val = target instanceof HTMLInputElement && target.type === "checkbox" ? target.checked : target.value;
    setValues((v) => ({ ...v, [key]: val }));
    setErrors((er) => ({ ...er, [key]: "" }));
  };

  const strength = (() => {
    const p = values.password;
    let s = 0;
    if (p.length >= 8) s++;
    if (/[0-9]/.test(p)) s++;
    if (/[a-zA-Z]/.test(p)) s++;
    if (/[^0-9a-zA-Z]/.test(p)) s++;
    return s;
  })();

  const validate = () => {
    const e: Record<string, string> = {};
    if (!values.name.trim()) e.name = "Full name is required";
    if (!values.phone.trim()) e.phone = "Mobile number is required";
    else if (!/^(\+91[\s-]?)?[6-9]\d{9}$/.test(values.phone.replace(/[\s-]/g, "")))
      e.phone = "Enter a valid 10-digit Indian mobile number";
    if (values.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email))
      e.email = "Enter a valid email address";
    if (!values.password) e.password = "Password is required";
    else if (values.password.length < 8) e.password = "Use at least 8 characters";
    if (values.confirm !== values.password) e.confirm = "Passwords do not match";
    if (!values.terms) e.terms = "Please accept the terms to continue";
    return e;
  };

  const onSubmit = async (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length > 0) return;
    setLoading(true);
    await signup({
      name: values.name.trim(),
      role: values.role,
      phone: values.phone.trim(),
      email: values.email.trim() || undefined,
      language: values.language,
    });
    setLoading(false);
    toast("Account created! Let's set up your farm profile.", "success");
    router.push("/onboarding");
  };

  return (
    <div className="w-full max-w-lg">
      <div className="rounded-3xl border border-charcoal-100 bg-white p-6 shadow-card sm:p-8">
        <h1 className="text-2xl font-extrabold tracking-tight text-charcoal-900">
          {t("auth.createAccount")}
        </h1>
        <p className="mt-1.5 text-sm text-charcoal-500">
          Free forever for farmers. Takes less than 2 minutes.
        </p>

        <form onSubmit={onSubmit} noValidate className="mt-6 space-y-4">
          <fieldset>
            <legend className="mb-2 text-xs font-semibold text-charcoal-700">
              {t("auth.selectRole")}
            </legend>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {ROLE_OPTIONS.map((r) => {
                const Icon = r.icon;
                const active = values.role === r.role;
                return (
                  <label
                    key={r.role}
                    className={cn(
                      "focus-within:ring-2 focus-within:ring-forest-500 relative flex cursor-pointer flex-col items-center gap-1.5 rounded-xl border p-3 text-center text-[11px] font-bold transition-colors",
                      active
                        ? "border-forest-600 bg-forest-50 text-forest-800"
                        : "border-charcoal-200 bg-white text-charcoal-600 hover:border-forest-300"
                    )}
                  >
                    <input
                      type="radio"
                      name="role"
                      value={r.role}
                      checked={active}
                      onChange={set("role")}
                      className="sr-only"
                    />
                    <Icon className={cn("h-5 w-5", active ? "text-forest-600" : "text-charcoal-400")} aria-hidden />
                    {r.label}
                    {r.preview && (
                      <span className="absolute right-1.5 top-1.5 rounded-full bg-sun-100 px-1.5 py-0.5 text-[8px] font-extrabold uppercase text-sun-600">
                        V2
                      </span>
                    )}
                    {active && <CheckCircle2 className="absolute right-1.5 bottom-1.5 h-3.5 w-3.5 text-forest-600" aria-hidden />}
                  </label>
                );
              })}
            </div>
            {values.role !== "farmer" && (
              <p className="mt-2 rounded-xl bg-sun-100 px-3 py-2 text-xs font-medium text-sun-600">
                {ROLE_OPTIONS.find((r) => r.role === values.role)?.label} dashboards arrive in v2 —
                you can still explore the full farmer experience today.
              </p>
            )}
          </fieldset>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t("auth.fullName")} htmlFor="su-name" required error={errors.name}>
              <Input id="su-name" value={values.name} onChange={set("name")} placeholder="e.g. Ravi Kumar" error={errors.name} autoComplete="name" />
            </Field>
            <Field label={t("auth.mobile")} htmlFor="su-phone" required error={errors.phone}>
              <Input id="su-phone" type="tel" value={values.phone} onChange={set("phone")} placeholder="98480 11223" error={errors.phone} autoComplete="tel" />
            </Field>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t("auth.email")} htmlFor="su-email" error={errors.email}>
              <Input id="su-email" type="email" value={values.email} onChange={set("email")} placeholder="optional" error={errors.email} autoComplete="email" />
            </Field>
            <Field label={t("auth.language")} htmlFor="su-lang">
              <Select id="su-lang" value={values.language} onChange={set("language")}>
                {LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.native} ({l.label})
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label={t("auth.password")} htmlFor="su-password" required error={errors.password} hint="8+ characters with a number">
              <Input id="su-password" type="password" value={values.password} onChange={set("password")} error={errors.password} autoComplete="new-password" />
              {values.password && (
                <div className="mt-2 flex gap-1" aria-hidden>
                  {[1, 2, 3, 4].map((i) => (
                    <span
                      key={i}
                      className={cn(
                        "h-1 flex-1 rounded-full",
                        i <= strength ? (strength <= 2 ? "bg-red-400" : strength === 3 ? "bg-sun-400" : "bg-leaf-500") : "bg-charcoal-100"
                      )}
                    />
                  ))}
                </div>
              )}
            </Field>
            <Field label={t("auth.confirmPassword")} htmlFor="su-confirm" required error={errors.confirm}>
              <Input id="su-confirm" type="password" value={values.confirm} onChange={set("confirm")} error={errors.confirm} autoComplete="new-password" />
            </Field>
          </div>

          <div>
            <label className="flex cursor-pointer items-start gap-2.5 text-sm text-charcoal-700">
              <input
                type="checkbox"
                checked={values.terms}
                onChange={set("terms")}
                aria-invalid={errors.terms ? true : undefined}
                className="mt-0.5 h-4 w-4 rounded border-charcoal-300 text-forest-600 focus:ring-forest-500"
              />
              <span>
                I agree to the <span className="font-semibold text-forest-700 underline">Terms of Service</span> and{" "}
                <span className="font-semibold text-forest-700 underline">Privacy Policy</span>.
              </span>
            </label>
            {errors.terms && <p className="mt-1 text-xs font-medium text-red-600" role="alert">{errors.terms}</p>}
          </div>

          <Button type="submit" fullWidth size="lg" loading={loading}>
            Create account
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-charcoal-600">
          Already have an account?{" "}
          <Link href="/login" className="focus-ring rounded font-bold text-forest-700 hover:underline">
            {t("common.login")}
          </Link>
        </p>
      </div>
    </div>
  );
}
