"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Sparkles } from "lucide-react";
import Button from "@/components/ui/Button";
import { Field, Input } from "@/components/ui/Form";
import { useApp } from "@/lib/context/AppContext";
import { usePageTitle } from "@/lib/hooks";
import { translate } from "@/lib/i18n/translations";

export default function LoginPage() {
  const router = useRouter();
  const { lang, user, hydrated, login, demoLogin, toast } = useApp();
  const t = (k: string) => translate(lang, k);
  usePageTitle("Log in");

  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState<{ identifier?: string; password?: string }>({});
  const [loading, setLoading] = useState(false);
  const [demoLoading, setDemoLoading] = useState(false);

  useEffect(() => {
    if (hydrated && user) router.replace("/dashboard");
  }, [hydrated, user, router]);

  const validate = () => {
    const e: typeof errors = {};
    const v = identifier.trim();
    if (!v) e.identifier = t("auth.emailOrPhone") + " is required";
    else {
      const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
      const isPhone = /^(\+91[\s-]?)?[6-9]\d{9}$/.test(v.replace(/[\s-]/g, ""));
      if (!isEmail && !isPhone) e.identifier = "Enter a valid email or 10-digit mobile number";
    }
    if (!password) e.password = "Password is required";
    else if (password.length < 6) e.password = "Password must be at least 6 characters";
    return e;
  };

  const onSubmit = async (ev: FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length > 0) return;
    setLoading(true);
    await login(identifier);
    setLoading(false);
    toast("Welcome back! Redirecting to your dashboard…", "success");
    router.push("/dashboard");
  };

  const onDemo = async () => {
    setDemoLoading(true);
    await demoLogin();
    setDemoLoading(false);
    toast("Demo farmer account loaded. Explore freely!", "info");
    router.push("/dashboard");
  };

  return (
    <div className="w-full max-w-md">
      <div className="rounded-3xl border border-charcoal-100 bg-white p-6 shadow-card sm:p-8">
        <h1 className="text-2xl font-extrabold tracking-tight text-charcoal-900">
          {t("auth.welcomeBack")}
        </h1>
        <p className="mt-1.5 text-sm text-charcoal-500">{t("auth.signInSubtitle")}</p>

        <form onSubmit={onSubmit} noValidate className="mt-6 space-y-4">
          <Field label={t("auth.emailOrPhone")} htmlFor="login-id" required error={errors.identifier}>
            <Input
              id="login-id"
              type="text"
              autoComplete="username"
              value={identifier}
              onChange={(e) => {
                setIdentifier(e.target.value);
                setErrors((er) => ({ ...er, identifier: undefined }));
              }}
              placeholder="ravi@example.com or 9848011223"
              error={errors.identifier}
            />
          </Field>

          <Field label={t("auth.password")} htmlFor="login-password" required error={errors.password}>
            <div className="relative">
              <Input
                id="login-password"
                type={showPassword ? "text" : "password"}
                autoComplete="current-password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setErrors((er) => ({ ...er, password: undefined }));
                }}
                placeholder="••••••••"
                error={errors.password}
                className="pr-11"
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                className="focus-ring absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-charcoal-400 hover:text-charcoal-700"
              >
                {showPassword ? <EyeOff className="h-[18px] w-[18px]" aria-hidden /> : <Eye className="h-[18px] w-[18px]" aria-hidden />}
              </button>
            </div>
          </Field>

          <div className="flex justify-end">
            <Link
              href="/forgot-password"
              className="focus-ring rounded text-xs font-bold text-forest-700 hover:underline"
            >
              {t("auth.forgotPassword")}
            </Link>
          </div>

          <Button type="submit" fullWidth size="lg" loading={loading}>
            {t("common.login")}
          </Button>
        </form>

        <div className="my-5 flex items-center gap-3">
          <span className="h-px flex-1 bg-charcoal-100" aria-hidden />
          <span className="text-[11px] font-bold uppercase tracking-wide text-charcoal-400">or</span>
          <span className="h-px flex-1 bg-charcoal-100" aria-hidden />
        </div>

        <Button variant="sun" fullWidth size="lg" onClick={onDemo} loading={demoLoading} leftIcon={<Sparkles className="h-4 w-4" aria-hidden />}>
          {t("auth.demoLogin")}
        </Button>

        <p className="mt-6 text-center text-sm text-charcoal-600">
          New to AgriConnect?{" "}
          <Link href="/signup" className="focus-ring rounded font-bold text-forest-700 hover:underline">
            {t("common.signup")}
          </Link>
        </p>
      </div>
    </div>
  );
}
