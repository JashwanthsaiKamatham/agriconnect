"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { MailCheck } from "lucide-react";
import Button from "@/components/ui/Button";
import { Field, Input } from "@/components/ui/Form";
import { usePageTitle } from "@/lib/hooks";
import { useApp } from "@/lib/context/AppContext";

export default function ForgotPasswordPage() {
  usePageTitle("Reset password");
  const { toast } = useApp();
  const [identifier, setIdentifier] = useState("");
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const v = identifier.trim();
    const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
    const isPhone = /^(\+91[\s-]?)?[6-9]\d{9}$/.test(v.replace(/[\s-]/g, ""));
    if (!v) setError("Enter your email or mobile number");
    else if (!isEmail && !isPhone) setError("Enter a valid email or 10-digit mobile number");
    else {
      setError("");
      setLoading(true);
      await new Promise((r) => setTimeout(r, 900));
      setLoading(false);
      setSent(true);
      toast("Reset instructions sent (demo).", "info");
    }
  };

  return (
    <div className="w-full max-w-md">
      <div className="rounded-3xl border border-charcoal-100 bg-white p-6 shadow-card sm:p-8">
        {sent ? (
          <div className="text-center">
            <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-leaf-100 text-leaf-700">
              <MailCheck className="h-7 w-7" aria-hidden />
            </span>
            <h1 className="mt-4 text-xl font-extrabold text-charcoal-900">Check your messages</h1>
            <p className="mt-2 text-sm leading-relaxed text-charcoal-500">
              We&apos;ve sent a password reset link to <span className="font-semibold text-charcoal-800">{identifier}</span>.
              In this demo no real message is sent — use the demo login on the next screen.
            </p>
            <Button href="/login" fullWidth size="lg" className="mt-6">
              Back to login
            </Button>
          </div>
        ) : (
          <>
            <h1 className="text-2xl font-extrabold tracking-tight text-charcoal-900">Forgot password?</h1>
            <p className="mt-1.5 text-sm text-charcoal-500">
              Enter your registered email or mobile number and we&apos;ll send you a reset link.
            </p>
            <form onSubmit={onSubmit} noValidate className="mt-6 space-y-4">
              <Field label="Email or mobile number" htmlFor="fp-id" required error={error}>
                <Input
                  id="fp-id"
                  value={identifier}
                  onChange={(e) => {
                    setIdentifier(e.target.value);
                    setError("");
                  }}
                  placeholder="ravi@example.com or 9848011223"
                  error={error}
                />
              </Field>
              <Button type="submit" fullWidth size="lg" loading={loading}>
                Send reset link
              </Button>
            </form>
            <p className="mt-6 text-center text-sm text-charcoal-600">
              Remembered it?{" "}
              <Link href="/login" className="focus-ring rounded font-bold text-forest-700 hover:underline">
                Back to login
              </Link>
            </p>
          </>
        )}
      </div>
    </div>
  );
}
