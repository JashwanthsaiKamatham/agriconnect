import Link from "next/link";
import { ShieldCheck, IndianRupee, CloudSun } from "lucide-react";
import Logo from "@/components/layout/Logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-beige-50">
      {/* Brand panel */}
      <aside className="relative hidden w-[46%] overflow-hidden lg:block">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/hero.jpg"
          alt=""
          aria-hidden
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-forest-950/95 via-forest-950/60 to-forest-900/30" aria-hidden />
        <div className="relative flex h-full flex-col justify-between p-10">
          <Logo dark />
          <div>
            <h2 className="max-w-md text-3xl font-extrabold leading-tight text-white">
              Grow Smarter. Sell Better. Connect Directly.
            </h2>
            <ul className="mt-8 space-y-4">
              {[
                { icon: IndianRupee, text: "Sell directly to verified buyers at better prices" },
                { icon: CloudSun, text: "Village weather alerts and live mandi prices" },
                { icon: ShieldCheck, text: "Your data stays yours — always" },
              ].map((i) => (
                <li key={i.text} className="flex items-center gap-3 text-sm font-medium text-charcoal-100">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 backdrop-blur">
                    <i.icon className="h-[18px] w-[18px] text-leaf-300" aria-hidden />
                  </span>
                  {i.text}
                </li>
              ))}
            </ul>
          </div>
          <p className="text-xs text-charcoal-300">
            Demo application · Sample data only
          </p>
        </div>
      </aside>

      {/* Form panel */}
      <main className="flex flex-1 flex-col items-center justify-center px-4 py-10 sm:px-8">
        <div className="mb-8 lg:hidden">
          <Logo />
        </div>
        {children}
        <p className="mt-8 max-w-sm text-center text-xs text-charcoal-400">
          <Link href="/" className="focus-ring rounded font-semibold text-forest-700 hover:underline">
            ← Back to home
          </Link>
        </p>
      </main>
    </div>
  );
}
