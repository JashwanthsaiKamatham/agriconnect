import type { ActivityItem } from "@/lib/types";

/** 12-month analytics series (Apr 2025 → Sep 2026) — sample data, ₹ thousands. */
export const monthlyRevenue = [
  { month: "Oct", revenue: 42 },
  { month: "Nov", revenue: 88 },
  { month: "Dec", revenue: 74 },
  { month: "Jan", revenue: 56 },
  { month: "Feb", revenue: 39 },
  { month: "Mar", revenue: 27 },
  { month: "Apr", revenue: 18 },
  { month: "May", revenue: 26 },
  { month: "Jun", revenue: 31 },
  { month: "Jul", revenue: 22 },
  { month: "Aug", revenue: 34 },
  { month: "Sep", revenue: 46 },
];

export const monthlyExpenses = [
  { month: "Oct", expenses: 18 },
  { month: "Nov", expenses: 32 },
  { month: "Dec", expenses: 24 },
  { month: "Jan", expenses: 20 },
  { month: "Feb", expenses: 16 },
  { month: "Mar", expenses: 12 },
  { month: "Apr", expenses: 9 },
  { month: "May", expenses: 14 },
  { month: "Jun", expenses: 18 },
  { month: "Jul", expenses: 21 },
  { month: "Aug", expenses: 19 },
  { month: "Sep", expenses: 22 },
];

export const waterUsage = [
  { label: "Apr", usage: 420 },
  { label: "May", usage: 610 },
  { label: "Jun", usage: 780 },
  { label: "Jul", usage: 640 },
  { label: "Aug", usage: 520 },
  { label: "Sep", usage: 460 },
];

export const fertilizerUsage = [
  { label: "Apr", usage: 45 },
  { label: "May", usage: 60 },
  { label: "Jun", usage: 110 },
  { label: "Jul", usage: 135 },
  { label: "Aug", usage: 95 },
  { label: "Sep", usage: 70 },
];

export const healthTrend = [
  { week: "W1", health: 88 },
  { week: "W2", health: 90 },
  { week: "W3", health: 89 },
  { week: "W4", health: 92 },
  { week: "W5", health: 94 },
  { week: "W6", health: 92 },
];

export const expenseBreakdown = [
  { name: "Fertilizer", value: 32 },
  { name: "Labour", value: 26 },
  { name: "Seeds", value: 18 },
  { name: "Fuel", value: 12 },
  { name: "Irrigation", value: 7 },
  { name: "Other", value: 5 },
];

/** 6-month revenue for the dashboard card (Apr → Sep 2026). */
export const dashboardRevenue = monthlyRevenue.slice(6).map((r) => ({
  month: r.month,
  revenue: r.revenue,
}));

export const analyticsActivity: ActivityItem[] = [];
