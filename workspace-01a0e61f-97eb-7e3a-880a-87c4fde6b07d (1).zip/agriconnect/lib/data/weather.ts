import type { WeatherData } from "../types";

/**
 * Sample weather for the demo farm (Kurnool, Andhra Pradesh).
 * The `weatherService` in `lib/services` is the single swap point for a live
 * weather API (IMD / OpenWeatherMap) later — the UI contract stays the same.
 */
export const weatherData: WeatherData = {
  location: "Kurnool, Andhra Pradesh",
  farm: "Ravi's Farm — Veldurthi Road",
  updatedAtLabel: "Updated 20 minutes ago",
  current: {
    tempC: 29,
    feelsLikeC: 31,
    condition: "partly cloudy",
    humidity: 72,
    rainChance: 40,
    windKmph: 12,
    uvIndex: 6,
    sunrise: "6:04 AM",
    sunset: "6:16 PM",
  },
  daily: [
    { day: "Today", date: "Sep 28", hi: 31, lo: 23, rain: 40, condition: "partly cloudy" },
    { day: "Tue", date: "Sep 29", hi: 30, lo: 23, rain: 65, condition: "light rain" },
    { day: "Wed", date: "Sep 30", hi: 28, lo: 22, rain: 80, condition: "heavy rain" },
    { day: "Thu", date: "Oct 1", hi: 32, lo: 24, rain: 20, condition: "partly cloudy" },
    { day: "Fri", date: "Oct 2", hi: 33, lo: 24, rain: 10, condition: "sunny" },
    { day: "Sat", date: "Oct 3", hi: 34, lo: 25, rain: 15, condition: "sunny" },
    { day: "Sun", date: "Oct 4", hi: 32, lo: 24, rain: 30, condition: "thunderstorm" },
  ],
  alerts: [
    {
      type: "rain",
      title: "Heavy rain alert — Wednesday (Sep 30)",
      body: "40–60 mm rainfall expected in Kurnool district. Postpone harvesting and spraying; secure harvested produce and equipment under cover.",
    },
    {
      type: "wind",
      title: "Windy evening today",
      body: "Gusts up to 28 km/h expected after 4 PM. Avoid pesticide or fertilizer spraying this evening.",
    },
  ],
  recommendations: [
    {
      icon: "droplets",
      title: "Irrigate cotton before Wednesday",
      body: "No effective rain expected today–Tuesday. Give cotton one light irrigation tomorrow morning; Wednesday's rain will then recharge the soil.",
    },
    {
      icon: "harvest",
      title: "Harvest tomato before the rain",
      body: "Your tomato is ready for picking. Harvest by Tuesday evening to avoid splitting and fungal rot during Wednesday's heavy rain.",
    },
    {
      icon: "spray",
      title: "Avoid spraying today evening",
      body: "Wind speeds above 15 km/h reduce spray efficiency and cause drift. Spray Thursday morning between 6–9 AM instead.",
    },
    {
      icon: "bug",
      title: "Watch paddy for blight after rain",
      body: "High humidity (>70%) for 3+ days raises bacterial leaf blight risk. Inspect paddy fields Friday and scout for wilting edges.",
    },
  ],
};
