export const platformStats = [
  { value: "52,000+", label: "Farmers onboard" },
  { value: "12,400+", label: "Verified buyers" },
  { value: "₹180 Cr+", label: "Produce traded" },
  { value: "1,400+", label: "Mandis connected" },
];

export const features = [
  {
    icon: "market",
    title: "Live Market Prices",
    body: "Daily modal, minimum and maximum prices from 1,400+ mandis with 30-day trends, so you never sell below the right price.",
  },
  {
    icon: "weather",
    title: "Weather Intelligence",
    body: "Village-level 7-day forecasts, rain alerts and farming advisories for irrigation, spraying and harvesting windows.",
  },
  {
    icon: "disease",
    title: "Crop Disease Detection",
    body: "Upload a leaf photo and get an instant AI-assisted diagnosis with severity, treatment steps and expert review.",
  },
  {
    icon: "marketplace",
    title: "Direct Marketplace",
    body: "List your produce with grades and expected price. Buyers contact you directly — no middlemen commissions.",
  },
  {
    icon: "equipment",
    title: "Equipment Rental",
    body: "Rent tractors, rotavators, harvesters and sprayers nearby with delivery options and transparent daily rates.",
  },
  {
    icon: "expert",
    title: "Expert Consultation",
    body: "Talk or video-call verified agronomists and pathologists in your language at farmer-friendly fees.",
  },
];

export const roles = [
  {
    icon: "farmer",
    title: "Farmer",
    body: "Track crops, sell direct, get advisories and rent equipment.",
    active: true,
  },
  {
    icon: "buyer",
    title: "Buyer / Trader",
    body: "Discover graded produce with transparent pricing and farm-gate pickup.",
    active: false,
  },
  {
    icon: "expert",
    title: "Agri Expert",
    body: "Advise farmers via video/phone and grow your consultation practice.",
    active: false,
  },
  {
    icon: "supplier",
    title: "Equipment Supplier",
    body: "List machinery, manage bookings and reach farmers nearby.",
    active: false,
  },
  {
    icon: "logistics",
    title: "Logistics Provider",
    body: "Receive trip requests and move produce from farm to market.",
    active: false,
  },
  {
    icon: "admin",
    title: "Administrator",
    body: "Monitor platform activity, users and listings from one console.",
    active: false,
  },
];

export const howItWorks = [
  {
    step: 1,
    title: "Create your free profile",
    body: "Sign up with your mobile number and add your village, land and language in under 3 minutes.",
  },
  {
    step: 2,
    title: "Add your crops",
    body: "Log every crop with variety, area and planting date to get stage-wise reminders and alerts.",
  },
  {
    step: 3,
    title: "Act on smart insights",
    body: "Use weather advisories, live mandi prices and disease scans to protect yield and cut cost.",
  },
  {
    step: 4,
    title: "Sell directly & track",
    body: "Publish a produce listing, negotiate with verified buyers and book logistics to deliver.",
  },
];

export const farmerBenefits = [
  "15–20% better prices by selling directly to verified buyers",
  "Free weather, pest and scheme alerts in your language",
  "Instant AI disease scans with expert second opinion",
  "Equipment rental at fair rates — no ownership cost",
  "Doorstep logistics booking from farm to mandi",
  "One profile for all government scheme updates",
];

export const buyerBenefits = [
  "Quality-graded produce with photos before pickup",
  "Farm-gate pricing without layered commissions",
  "Talk directly to the farmer — full transparency",
  "Forward-book harvests with fixed quantity and date",
  "Integrated logistics with live shipment tracking",
  "Verified farmer profiles reduce counterparty risk",
];

export const testimonials = [
  {
    name: "Lakshmamma G.",
    detail: "Cotton farmer · Kallur, Kurnool (AP)",
    quote:
      "Earlier I sold kapas to a middleman at ₹6,100 a quintal. On AgriConnect a ginning mill contacted me directly and I got ₹7,050 — ₹45,000 more on my five acres.",
    rating: 5,
  },
  {
    name: "Manjunath S.",
    detail: "Paddy farmer · Davanagere (KA)",
    quote:
      "The disease scanner caught bacterial blight on my paddy in two minutes and the expert confirmed it the same evening. Early spraying saved my entire crop.",
    rating: 5,
  },
  {
    name: "Anil Traders Pvt. Ltd.",
    detail: "Vegetable buyer · Hyderabad (TS)",
    quote:
      "We now book tomatoes from three villages with quality grades and pickup dates fixed a week in advance. Rejections have dropped by half.",
    rating: 4,
  },
];

export const contactInfo = {
  email: "hello@agriconnect.in",
  phone: "+91 80080 12345",
  address: "HSR Layout, Bengaluru, Karnataka 560102",
};
