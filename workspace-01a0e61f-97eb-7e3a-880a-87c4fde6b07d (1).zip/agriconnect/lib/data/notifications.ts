import type { AppNotification, ActivityItem, FarmTask } from "../types";

export const seedNotifications: AppNotification[] = [
  {
    id: "n-1",
    type: "weather",
    title: "Heavy rain expected Wednesday",
    body: "40–60 mm rain in Kurnool. Plan harvesting and spraying around it.",
    time: "25 min ago",
    read: false,
  },
  {
    id: "n-2",
    type: "price",
    title: "Onion price up 12.5%",
    body: "Kurnool APMC modal price now ₹1,850/quintal. Good time to list stored onion.",
    time: "1 hour ago",
    read: false,
  },
  {
    id: "n-3",
    type: "market",
    title: "3 new buyer inquiries on your tomato listing",
    body: "Sri Anil Traders, FreshMart Retail and 1 more asked about 25 q tomato.",
    time: "3 hours ago",
    read: false,
  },
  {
    id: "n-4",
    type: "scheme",
    title: "PM-KISAN 18th installment released",
    body: "₹2,000 will be credited to your registered bank account within 5 days.",
    time: "Yesterday",
    read: true,
  },
  {
    id: "n-5",
    type: "expert",
    title: "Dr. Prasad Rao replied to your query",
    body: "\"Increase the second nitrogen split for your paddy after Wednesday's rain.\"",
    time: "Yesterday",
    read: true,
  },
];

export const seedTasks: FarmTask[] = [
  {
    id: "t-1",
    title: "First tomato picking & packing",
    crop: "Tomato",
    due: "Today",
    priority: "High",
    done: false,
  },
  {
    id: "t-2",
    title: "Top dress nitrogen on maize",
    crop: "Maize",
    due: "Tomorrow",
    priority: "Medium",
    done: false,
  },
  {
    id: "t-3",
    title: "Check pink bollworm traps",
    crop: "Cotton",
    due: "Sep 30",
    priority: "High",
    done: false,
  },
  {
    id: "t-4",
    title: "Desilt the farm pond",
    crop: "All",
    due: "Oct 5",
    priority: "Low",
    done: true,
  },
];

export const seedActivity: ActivityItem[] = [
  {
    id: "a-1",
    icon: "order",
    text: "Your tomato listing got 3 new buyer inquiries",
    time: "3 h ago",
  },
  {
    id: "a-2",
    icon: "price",
    text: "Price alert: Onion +12.5% in Kurnool APMC",
    time: "5 h ago",
  },
  {
    id: "a-3",
    icon: "expert",
    text: "Dr. Prasad Rao answered your paddy nutrition query",
    time: "Yesterday",
  },
  {
    id: "a-4",
    icon: "equipment",
    text: "Combine harvester confirmed near you for Nov 2–4",
    time: "2 days ago",
  },
  {
    id: "a-5",
    icon: "order",
    text: "Paddy shipment SHP-1024 reached Hyderabad hub",
    time: "2 days ago",
  },
];
