import type { MarketPrice } from "../types";

/**
 * Demo mandi prices (₹ per quintal).
 * Currently SAMPLE DATA — the service layer in `lib/services` is the single
 * integration point for a live Agmarknet / eNAM price API later.
 *
 * `history` uses a deterministic pseudo-random walk (no Math.random) so the
 * server-rendered and client-rendered markup always match.
 */

/** Deterministic series generator — same output on server and client. */
function series(seed: number, current: number, volatility: number, points = 30): number[] {
  const out: number[] = [];
  let v = current;
  for (let i = 0; i < points; i++) {
    const x = Math.sin(seed * 99.7 + (points - i) * 12.9898) * 43758.5453;
    const r = x - Math.floor(x);
    v = v - (r - 0.47) * volatility;
    if (v < current * 0.72) v = current * 0.72;
    out.unshift(Math.round(v));
  }
  out[points - 1] = current;
  return out;
}

export const marketPrices: MarketPrice[] = [
  {
    id: "mp-rice",
    crop: "Rice",
    variety: "Sona Masoori",
    emoji: "🌾",
    image: "/images/crops/rice.jpg",
    unit: "quintal",
    modal: 2180,
    min: 1950,
    max: 2400,
    avg: 2178,
    changePct: 2.4,
    market: "Raichur APMC",
    district: "Raichur",
    state: "Karnataka",
    updatedLabel: "Today, 9:15 AM",
    history: series(1, 2180, 55),
    nearby: [
      { market: "Raichur APMC", district: "Raichur", distanceKm: 0, modal: 2180, changePct: 2.4 },
      { market: "Kurnool APMC", district: "Kurnool", distanceKm: 42, modal: 2150, changePct: 1.8 },
      { market: "Gadwal Market", district: "Jogulamba Gadwal", distanceKm: 68, modal: 2120, changePct: 1.1 },
      { market: "Devanakonda Market", district: "Kurnool", distanceKm: 75, modal: 2090, changePct: 0.6 },
    ],
  },
  {
    id: "mp-maize",
    crop: "Maize",
    emoji: "🌽",
    image: "/images/crops/maize.jpg",
    unit: "quintal",
    modal: 2090,
    min: 1980,
    max: 2210,
    avg: 2088,
    changePct: 1.1,
    market: "Davanagere APMC",
    district: "Davanagere",
    state: "Karnataka",
    updatedLabel: "Today, 8:40 AM",
    history: series(2, 2090, 42),
    nearby: [
      { market: "Davanagere APMC", district: "Davanagere", distanceKm: 0, modal: 2090, changePct: 1.1 },
      { market: "Bellary Market", district: "Ballari", distanceKm: 96, modal: 2065, changePct: 0.9 },
      { market: "Kurnool APMC", district: "Kurnool", distanceKm: 118, modal: 2040, changePct: 0.4 },
      { market: "Haveri Market", district: "Haveri", distanceKm: 132, modal: 2030, changePct: -0.2 },
    ],
  },
  {
    id: "mp-cotton",
    crop: "Cotton",
    variety: "Kapas",
    emoji: "☁️",
    image: "/images/crops/cotton.jpg",
    unit: "quintal",
    modal: 7020,
    min: 6750,
    max: 7310,
    avg: 7010,
    changePct: 3.8,
    market: "Guntur APMC",
    district: "Guntur",
    state: "Andhra Pradesh",
    updatedLabel: "Today, 10:05 AM",
    history: series(3, 7020, 160),
    nearby: [
      { market: "Guntur APMC", district: "Guntur", distanceKm: 0, modal: 7020, changePct: 3.8 },
      { market: "Adoni Market", district: "Kurnool", distanceKm: 55, modal: 6950, changePct: 3.2 },
      { market: "Warangal APMC", district: "Warangal", distanceKm: 165, modal: 6880, changePct: 2.6 },
      { market: "Bellary Cotton Yard", district: "Ballari", distanceKm: 190, modal: 6840, changePct: 2.1 },
    ],
  },
  {
    id: "mp-tomato",
    crop: "Tomato",
    emoji: "🍅",
    image: "/images/crops/tomato.jpg",
    unit: "quintal",
    modal: 1450,
    min: 850,
    max: 1900,
    avg: 1380,
    changePct: -6.2,
    market: "Kurnool APMC",
    district: "Kurnool",
    state: "Andhra Pradesh",
    updatedLabel: "Today, 7:30 AM",
    history: series(4, 1450, 190),
    nearby: [
      { market: "Kurnool APMC", district: "Kurnool", distanceKm: 0, modal: 1450, changePct: -6.2 },
      { market: "Madanapalle Market", district: "Annamayya", distanceKm: 210, modal: 1520, changePct: -4.8 },
      { market: "Bengaluru Binny Mills", district: "Bengaluru Urban", distanceKm: 245, modal: 1610, changePct: -3.1 },
      { market: "Hyderabad Bowenpally", district: "Hyderabad", distanceKm: 198, modal: 1580, changePct: -3.9 },
    ],
  },
  {
    id: "mp-onion",
    crop: "Onion",
    emoji: "🧅",
    image: "/images/crops/onion.jpg",
    unit: "quintal",
    modal: 1850,
    min: 1400,
    max: 2100,
    avg: 1790,
    changePct: 12.5,
    market: "Kurnool APMC",
    district: "Kurnool",
    state: "Andhra Pradesh",
    updatedLabel: "Today, 7:30 AM",
    history: series(5, 1850, 120),
    nearby: [
      { market: "Kurnool APMC", district: "Kurnool", distanceKm: 0, modal: 1850, changePct: 12.5 },
      { market: "Hyderabad Bowenpally", district: "Hyderabad", distanceKm: 198, modal: 1920, changePct: 14.1 },
      { market: "Bengaluru Yeshwanthpur", district: "Bengaluru Urban", distanceKm: 245, modal: 1965, changePct: 15.3 },
      { market: "Dharwad APMC", district: "Dharwad", distanceKm: 240, modal: 1810, changePct: 10.8 },
    ],
  },
  {
    id: "mp-millet",
    crop: "Bajra (Millet)",
    emoji: "🌾",
    unit: "quintal",
    modal: 2350,
    min: 2200,
    max: 2500,
    avg: 2340,
    changePct: 0.8,
    market: "Warangal APMC",
    district: "Warangal",
    state: "Telangana",
    updatedLabel: "Yesterday, 6:20 PM",
    history: series(6, 2350, 38),
    nearby: [
      { market: "Warangal APMC", district: "Warangal", distanceKm: 0, modal: 2350, changePct: 0.8 },
      { market: "Kurnool APMC", district: "Kurnool", distanceKm: 175, modal: 2320, changePct: 0.5 },
      { market: "Anantapur Market", district: "Anantapur", distanceKm: 220, modal: 2300, changePct: 0.2 },
      { market: "Mahbubnagar Market", district: "Mahbubnagar", distanceKm: 140, modal: 2280, changePct: -0.1 },
    ],
  },
  {
    id: "mp-sugarcane",
    crop: "Sugarcane",
    emoji: "🎍",
    image: "/images/crops/sugarcane.jpg",
    unit: "quintal",
    modal: 3100,
    min: 2900,
    max: 3250,
    avg: 3095,
    changePct: 0.4,
    market: "Bijapur APMC",
    district: "Vijayapura",
    state: "Karnataka",
    updatedLabel: "Yesterday, 5:45 PM",
    history: series(7, 3100, 30),
    nearby: [
      { market: "Bijapur APMC", district: "Vijayapura", distanceKm: 0, modal: 3100, changePct: 0.4 },
      { market: "Belagavi Market", district: "Belagavi", distanceKm: 185, modal: 3080, changePct: 0.3 },
      { market: "Kurnool APMC", district: "Kurnool", distanceKm: 260, modal: 3050, changePct: 0.1 },
      { market: "Solapur Market", district: "Solapur", distanceKm: 240, modal: 3020, changePct: 0 },
    ],
  },
  {
    id: "mp-groundnut",
    crop: "Groundnut",
    emoji: "🥜",
    image: "/images/crops/groundnut.jpg",
    unit: "quintal",
    modal: 6250,
    min: 5900,
    max: 6600,
    avg: 6225,
    changePct: 2.2,
    market: "Anantapur APMC",
    district: "Anantapur",
    state: "Andhra Pradesh",
    updatedLabel: "Today, 9:50 AM",
    history: series(8, 6250, 110),
    nearby: [
      { market: "Anantapur APMC", district: "Anantapur", distanceKm: 0, modal: 6250, changePct: 2.2 },
      { market: "Kurnool APMC", district: "Kurnool", distanceKm: 130, modal: 6180, changePct: 1.9 },
      { market: "Tandur Market", district: "Vikarabad", distanceKm: 175, modal: 6120, changePct: 1.4 },
      { market: "Bellary Market", district: "Ballari", distanceKm: 150, modal: 6090, changePct: 1.2 },
    ],
  },
];

/** States/districts available in the demo dataset. */
export const marketStates = Array.from(new Set(marketPrices.map((p) => p.state)));
export const marketDistricts = Array.from(new Set(marketPrices.map((p) => p.district)));
