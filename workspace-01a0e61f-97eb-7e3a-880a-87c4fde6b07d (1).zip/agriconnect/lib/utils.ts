import type { Crop, GrowthStage } from "./types";

/** Join conditional class names. */
export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(" ");
}

/* ------------------------------- Formatting ------------------------------ */

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
];

export function formatINR(n: number): string {
  return "₹" + Math.round(n).toLocaleString("en-IN");
}

/** Compact Indian notation: ₹1.2 L / ₹2.4 Cr */
export function toLakh(n: number): string {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)} Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(1)} L`;
  if (n >= 1000) return `₹${Math.round(n / 1000)}K`;
  return formatINR(n);
}

/** Format an ISO date (yyyy-mm-dd) without timezone surprises. */
export function formatDate(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  if (!y || !m || !d) return iso;
  return `${d} ${MONTHS[m - 1]} ${y}`;
}

export function formatDateShort(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  if (!y || !m || !d) return iso;
  return `${d} ${MONTHS[m - 1]}`;
}

/** Whole days from *today* (UTC-safe, no hydration drift within a day). */
export function daysUntil(iso: string): number {
  const [y, m, d] = iso.split("-").map(Number);
  const now = new Date();
  const target = Date.UTC(y, (m || 1) - 1, d || 1);
  const today = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  return Math.round((target - today) / 86400000);
}

export function initials(name: string): string {
  return name
    .replace(/(Dr\.?|Mr\.?|Mrs\.?|Ms\.?|Sri\.?)\s+/gi, "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");
}

/* ------------------------------ Crop helpers ----------------------------- */

export const STAGE_ORDER: GrowthStage[] = [
  "Planned",
  "Seedling",
  "Vegetative",
  "Flowering",
  "Fruiting",
  "Ready for Harvest",
  "Harvested",
];

export function stageIndex(stage: GrowthStage): number {
  return STAGE_ORDER.indexOf(stage);
}

/** 0–100 progress of a crop through its lifecycle. */
export function stagePercent(stage: GrowthStage): number {
  return Math.round((stageIndex(stage) / (STAGE_ORDER.length - 1)) * 100);
}

export const STAGE_BADGE_CLASS: Record<GrowthStage, string> = {
  Planned: "bg-charcoal-100 text-charcoal-700",
  Seedling: "bg-leaf-100 text-leaf-800",
  Vegetative: "bg-forest-100 text-forest-800",
  Flowering: "bg-sun-100 text-sun-600",
  Fruiting: "bg-orange-100 text-orange-800",
  "Ready for Harvest": "bg-leaf-600 text-white",
  Harvested: "bg-earth-100 text-earth-800",
};

export const STAGE_BAR_CLASS: Record<GrowthStage, string> = {
  Planned: "bg-charcoal-300",
  Seedling: "bg-leaf-400",
  Vegetative: "bg-forest-400",
  Flowering: "bg-sun-400",
  Fruiting: "bg-orange-400",
  "Ready for Harvest": "bg-leaf-600",
  Harvested: "bg-earth-400",
};

const EMOJI_RULES: Array<[RegExp, string]> = [
  [/rice|paddy|dhan/, "🌾"],
  [/maize|corn|makka/, "🌽"],
  [/tomato|tamatar/, "🍅"],
  [/onion|pya[az]/, "🧅"],
  [/cotton|kapas/, "☁️"],
  [/ground ?nut|peanut|moong ?phali/, "🥜"],
  [/sugar ?cane|ganna/, "🎍"],
  [/millet|bajra|ragi|jowar/, "🌾"],
  [/chill[iy]|mirch/, "🌶️"],
  [/banana|kela|arati/, "🍌"],
  [/mango|aam|mamidi/, "🥭"],
  [/wheat|gehu|godhuma/, "🌾"],
  [/potato|aloo/, "🥔"],
  [/turmeric|pasupu/, "🟡"],
  [/vegetable|mixed/, "🥬"],
];

export function cropEmoji(name: string): string {
  const n = name.toLowerCase();
  for (const [re, emoji] of EMOJI_RULES) if (re.test(n)) return emoji;
  return "🌱";
}

/** Warm avatar / tile gradients used across the app. */
export const AVATAR_COLORS = [
  "bg-forest-600",
  "bg-earth-600",
  "bg-sun-500",
  "bg-leaf-600",
  "bg-earth-500",
  "bg-forest-500",
];

export function avatarColor(name: string): string {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}

/* --------------------------- Dashboard analytics -------------------------- */

const CROP_PRICE: Record<string, number> = {
  rice: 2180, paddy: 2180, maize: 2090, cotton: 7020, tomato: 1450,
  onion: 1850, bajra: 2350, millet: 2350, sugarcane: 3100, groundnut: 6250,
};

/** Demo modal price used to estimate a crop's revenue (₹/quintal). */
export function demoPriceFor(cropName: string): number {
  const n = cropName.toLowerCase();
  for (const [key, price] of Object.entries(CROP_PRICE)) {
    if (n.includes(key)) return price;
  }
  return 2200;
}

/** tonnes → quintals (1 t = 10 q). */
export function tonnesToQuintals(t: number): number {
  return t * 10;
}

/** Estimated revenue for one crop in ₹. */
export function estimateCropRevenue(crop: Crop): number {
  return demoPriceFor(crop.name) * tonnesToQuintals(crop.estimatedYield);
}
