/**
 * AgriConnect — shared domain models.
 *
 * These TypeScript interfaces mirror the database schema in `database/schema.sql`
 * and are designed to be handed directly to a real backend (Prisma, Drizzle,
 * Postgres, Firebase, …) without breaking component contracts.
 */

/* --------------------------------- Shared -------------------------------- */

export type Lang = "en" | "te" | "kn" | "hi";

export type Role =
  | "farmer"
  | "buyer"
  | "expert"
  | "supplier"
  | "logistics"
  | "admin";

export type SoilType =
  | "Black"
  | "Red"
  | "Alluvial"
  | "Sandy loam"
  | "Loamy"
  | "Laterite";

export type IrrigationType =
  | "Rain-fed"
  | "Canal"
  | "Borewell"
  | "Drip"
  | "Sprinkler"
  | "Flood";

export type AreaUnit = "acres" | "hectares";

export const GROWTH_STAGES = [
  "Planned",
  "Seedling",
  "Vegetative",
  "Flowering",
  "Fruiting",
  "Ready for Harvest",
  "Harvested",
] as const;

export type GrowthStage = (typeof GROWTH_STAGES)[number];

/* ---------------------------------- Users -------------------------------- */

export interface Farm {
  name?: string;
  village: string;
  district: string;
  state: string;
  pincode: string;
  area: number;
  areaUnit: AreaUnit;
  soilType: SoilType;
  irrigationType: IrrigationType;
  experienceYears?: number;
  preferredMarket?: string;
  cropsGrown?: string[];
}

export interface User {
  id: string;
  name: string;
  role: Role;
  email?: string;
  phone?: string;
  language: Lang;
  onboarded: boolean;
  photoDataUrl?: string;
  farm?: Farm;
  createdAt: string;
}

/* ---------------------------------- Crops -------------------------------- */

export interface Crop {
  id: string;
  name: string;
  variety: string;
  image?: string; // path under /public/images — optional; falls back to emoji tile
  area: number;
  areaUnit: AreaUnit;
  plantingDate: string; // ISO yyyy-mm-dd
  harvestDate: string; // ISO yyyy-mm-dd
  stage: GrowthStage;
  irrigation: IrrigationType;
  soil: SoilType;
  estimatedYield: number; // in tonnes
  notes?: string;
  createdAt: string;
}

/* ------------------------------ Market prices ---------------------------- */

export interface NearbyMarket {
  market: string;
  district: string;
  distanceKm: number;
  modal: number;
  changePct: number;
}

export interface MarketPrice {
  id: string;
  crop: string; // display name
  variety?: string;
  emoji: string;
  image?: string;
  unit: string; // per quintal
  modal: number;
  min: number;
  max: number;
  avg: number;
  changePct: number;
  market: string;
  district: string;
  state: string;
  updatedLabel: string;
  history: number[]; // last 30 days, oldest → newest
  nearby: NearbyMarket[];
}

/* --------------------------------- Weather ------------------------------- */

export type WeatherCondition =
  | "sunny"
  | "partly cloudy"
  | "cloudy"
  | "light rain"
  | "heavy rain"
  | "thunderstorm";

export interface DailyForecast {
  day: string;
  date: string;
  hi: number;
  lo: number;
  rain: number; // probability %
  condition: WeatherCondition;
}

export interface WeatherAlert {
  type: "rain" | "heat" | "wind";
  title: string;
  body: string;
}

export interface FarmingRecommendation {
  icon: "droplets" | "spray" | "harvest" | "bug" | "sun";
  title: string;
  body: string;
}

export interface WeatherData {
  location: string;
  farm: string;
  updatedAtLabel: string;
  current: {
    tempC: number;
    feelsLikeC: number;
    condition: WeatherCondition;
    humidity: number;
    rainChance: number;
    windKmph: number;
    uvIndex: number;
    sunrise: string;
    sunset: string;
  };
  daily: DailyForecast[];
  alerts: WeatherAlert[];
  recommendations: FarmingRecommendation[];
}

/* ------------------------------- Marketplace ----------------------------- */

export interface Listing {
  id: string;
  crop: string;
  variety?: string;
  emoji: string;
  image?: string;
  quantity: number;
  unit: string; // quintals, kg, tonnes
  price: number; // ₹ per quintal
  grade: "A" | "B";
  organic?: boolean;
  harvestDate: string;
  location: string;
  district: string;
  state: string;
  farmer: string;
  verified?: boolean;
  description?: string;
  createdAt: string;
}

/* -------------------------------- Equipment ------------------------------ */

export interface EquipmentItem {
  id: string;
  name: string;
  category: "Tractor" | "Rotavator" | "Seed Drill" | "Sprayer" | "Harvester";
  image: string;
  owner: string;
  pricePerDay: number;
  location: string;
  district: string;
  state: string;
  available: boolean;
  delivery: boolean;
  rating: number;
  trips: number;
  specs: string;
}

export interface EquipmentRental {
  id: string;
  equipmentId: string;
  equipmentName: string;
  owner: string;
  startDate: string;
  endDate: string;
  totalEstimate: number;
  status: "Requested" | "Confirmed" | "Completed";
}

/* --------------------------------- Experts ------------------------------- */

export interface Expert {
  id: string;
  name: string;
  specialization: string;
  qualification: string;
  experience: number;
  languages: string[];
  rating: number;
  reviews: number;
  fee: number;
  available: boolean;
  nextSlot: string;
  color: string; // avatar background class
}

export interface Consultation {
  id: string;
  expertId: string;
  expertName: string;
  crop: string;
  topic: string;
  date: string; // ISO
  time: string;
  mode: "Video call" | "Phone call" | "Farm visit";
  status: "Upcoming" | "Completed" | "Cancelled";
  fee: number;
}

/* ---------------------------- Government schemes ------------------------- */

export type BenefitType =
  | "Income support"
  | "Insurance"
  | "Credit"
  | "Subsidy"
  | "Market access"
  | "Training";

export interface Scheme {
  id: string;
  name: string;
  description: string;
  department: string;
  state: string; // "All India" or a state name
  eligibility: string;
  benefits: string[];
  documents: string[];
  deadline: string;
  crops: string[];
  category: string[]; // farmer categories
  benefitType: BenefitType;
}

/* -------------------------------- Logistics ------------------------------ */

export type ShipmentStatus =
  | "Request created"
  | "Provider assigned"
  | "Pickup scheduled"
  | "In transit"
  | "Delivered";

export const SHIPMENT_STATUSES: ShipmentStatus[] = [
  "Request created",
  "Provider assigned",
  "Pickup scheduled",
  "In transit",
  "Delivered",
];

export interface ShipmentUpdate {
  label: ShipmentStatus;
  done: boolean;
  time?: string;
}

export interface Shipment {
  id: string;
  goods: string;
  quantity: string;
  pickup: string;
  drop: string;
  provider?: string;
  vehicle?: string;
  date: string;
  eta?: string;
  status: ShipmentStatus;
  updates: ShipmentUpdate[];
}

export interface LogisticsProvider {
  id: string;
  name: string;
  vehicle: string;
  capacity: string;
  serviceArea: string[];
  priceEstimate: string;
  available: boolean;
  rating: number;
  trips: number;
}

/* ------------------------------ Notifications ---------------------------- */

export type NotificationType =
  | "weather"
  | "price"
  | "market"
  | "scheme"
  | "expert";

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  time: string;
  read: boolean;
}

/* ------------------------------ Farm activity ---------------------------- */

export interface FarmTask {
  id: string;
  title: string;
  crop: string;
  due: string;
  priority: "High" | "Medium" | "Low";
  done: boolean;
}

export interface ActivityItem {
  id: string;
  icon: "order" | "price" | "expert" | "scheme" | "equipment";
  text: string;
  time: string;
}

/* --------------------------------- Disease ------------------------------- */

export interface Diagnosis {
  disease: string;
  scientificName?: string;
  confidence: number; // %
  severity: "Low" | "Medium" | "High";
  symptoms: string[];
  actions: string[];
  prevention: string[];
}
