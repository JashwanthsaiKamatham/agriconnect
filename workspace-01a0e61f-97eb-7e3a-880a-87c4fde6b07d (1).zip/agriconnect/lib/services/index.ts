import type {
  Crop,
  Diagnosis,
  MarketPrice,
  WeatherData,
} from "../types";
import { seedCrops } from "../data/crops";
import { marketPrices } from "../data/market";
import { weatherData } from "../data/weather";

/**
 * AgriConnect service layer
 * -------------------------
 * Every screen talks to the app through these services. Today they resolve
 * realistic sample data with simulated latency; when the real backend is
 * ready, only these function bodies change (e.g. `return fetch('/api/crops')`).
 * UI contracts stay untouched.
 */

const delay = (ms = 500) => new Promise((r) => setTimeout(r, ms));

/* --------------------------------- Crops --------------------------------- */

export const cropService = {
  async list(): Promise<Crop[]> {
    await delay();
    return seedCrops;
    // Future: return (await fetch("/api/crops")).json();
  },
  async create(crop: Crop): Promise<Crop> {
    await delay(700);
    return crop;
  },
  async update(crop: Crop): Promise<Crop> {
    await delay(700);
    return crop;
  },
  async remove(id: string): Promise<{ id: string }> {
    await delay(500);
    return { id };
  },
};

/* ------------------------------ Market prices ----------------------------- */

export const marketService = {
  async prices(): Promise<MarketPrice[]> {
    await delay(650);
    return marketPrices;
    // Future: live Agmarknet / eNAM feed keyed by WEATHER/Market API keys.
  },
};

/* --------------------------------- Weather -------------------------------- */

export const weatherService = {
  async current(): Promise<WeatherData> {
    await delay(600);
    return weatherData;
    // Future: village-level forecast via WEATHER_API_KEY provider.
  },
};

/* ---------------------------- Disease detection --------------------------- */

/**
 * Demo diagnoses. NOT a medical/agricultural diagnosis — the UI must always
 * show the expert-consultation disclaimer alongside this result.
 */
const DEMO_DIAGNOSES: Record<string, Diagnosis> = {
  Tomato: {
    disease: "Late Blight",
    scientificName: "Phytophthora infestans",
    confidence: 87.4,
    severity: "High",
    symptoms: [
      "Dark, water-soaked lesions on leaves with pale yellow border",
      "White fuzzy growth on leaf undersides in humid weather",
      "Brown streaks on stems; fruit develops greasy brown patches",
    ],
    actions: [
      "Remove and destroy (do not compost) affected leaves and fruit immediately",
      "Spray a recommended fungicide such as cymoxanil + mancozeb; repeat after 7–10 days",
      "Improve airflow — widen spacing and stake plants; avoid overhead watering",
    ],
    prevention: [
      "Use certified disease-free seed and resistant varieties (e.g. Arka Rakshak)",
      "Rotate with non-solanaceous crops for 2–3 seasons",
      "Water at the base in the morning; keep foliage dry",
    ],
  },
  Paddy: {
    disease: "Bacterial Leaf Blight",
    scientificName: "Xanthomonas oryzae pv. oryzae",
    confidence: 82.1,
    severity: "Medium",
    symptoms: [
      "Yellowish lesions starting from leaf tips and moving downward",
      "Wavy yellow-to-brown leaf edges; leaves dry out greyish",
      "Milky droplets that dry into small amber beads on lesions",
    ],
    actions: [
      "Drain the field and let it dry briefly; avoid excess nitrogen now",
      "Spray copper-based bactericide or validamycin as per label dose",
      "Remove and burn severely infected plants",
    ],
    prevention: [
      "Use balanced fertilizer; split nitrogen applications",
      "Keep 2–3 cm standing water; avoid wound injury during weeding",
      "Grow resistant varieties (e.g. BPT 5204 with seed treatment)",
    ],
  },
  Cotton: {
    disease: "Cotton Leaf Curl Disease",
    scientificName: "CLCuV (whitefly-transmitted virus)",
    confidence: 78.6,
    severity: "High",
    symptoms: [
      "Upward/downward curling of leaves with thickened veins",
      "Leaf enations (small leaf-like outgrowths) on the underside",
      "Stunted plant growth and reduced boll formation",
    ],
    actions: [
      "Uproot and destroy severely infected plants to reduce virus spread",
      "Control the whitefly vector — yellow sticky traps + recommended insecticide rotation",
      "Do not top-dress heavy nitrogen on infected plants",
    ],
    prevention: [
      "Clean field borders of alternate host weeds",
      "Use tolerant hybrids and treat seed before sowing",
      "Install sticky traps at 10/acre from early vegetative stage",
    ],
  },
  Maize: {
    disease: "Fall Armyworm Damage",
    scientificName: "Spodoptera frugiperda",
    confidence: 91.2,
    severity: "Medium",
    symptoms: [
      "Irregular 'window pane' feeding holes on whorl leaves",
      "Moist sawdust-like frass (excreta) in the leaf whorl",
      "Ragged whorl; growing point damaged in heavy infestation",
    ],
    actions: [
      "Hand-pick and crush egg masses and larvae found in whorls",
      "Apply recommended insecticide or Emamectin benzoate into the whorl; evening application works best",
      "Set up pheromone traps at 5/ha to monitor moth pressure",
    ],
    prevention: [
      "Early sowing escapes the peak moth flight period",
      "Intercrop with legumes (cowpea/lablab) to encourage natural enemies",
      "Keep fields weed-free to remove alternate hosts",
    ],
  },
};

export const diseaseService = {
  supportedCrops: ["Tomato", "Paddy", "Cotton", "Maize", "Other"],
  async analyze(cropType: string): Promise<Diagnosis> {
    // Simulate AI inference latency. Future: POST image to AI_DISEASE_API.
    await delay(2200);
    return DEMO_DIAGNOSES[cropType] ?? {
      disease: "Common Leaf Spot",
      scientificName: "Fungal complex",
      confidence: 74.3,
      severity: "Low",
      symptoms: [
        "Small brown spots with yellow halos scattered on older leaves",
        "Spots may merge in wet weather forming irregular patches",
      ],
      actions: [
        "Prune heavily affected leaves and improve airflow",
        "Apply a broad-spectrum fungicide if spots spread quickly",
      ],
      prevention: [
        "Avoid overhead irrigation and water stress",
        "Practice crop rotation and remove crop debris after harvest",
      ],
    };
  },
};

export const DISEASE_DISCLAIMER =
  "This is a demonstration result. Consult a qualified agricultural expert before taking action.";
