"use client";

/**
 * AgriConnect application context.
 *
 * Holds language, mock authentication, and all interactive collections
 * (crops, listings, bookings, notifications…). Everything persists to
 * localStorage so the demo feels like a real logged-in experience and can be
 * swapped for server state (React Query + API routes) without touching pages.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type {
  AppNotification,
  Consultation,
  Crop,
  EquipmentRental,
  Farm,
  Lang,
  Listing,
  Role,
  Shipment,
  User,
} from "../types";
import { translations } from "../i18n/translations";
import { seedCrops } from "../data/crops";
import { seedListings } from "../data/marketplace";
import { seedNotifications } from "../data/notifications";
import { seedConsultations } from "../data/experts";
import { seedShipments } from "../data/logistics";

/* ---------------------------------- User ---------------------------------- */

export const DEMO_USER: User = {
  id: "u-demo-ravi",
  name: "Ravi Kumar",
  role: "farmer",
  email: "ravi.kumar@demo.agriconnect.in",
  phone: "+91 98480 11223",
  language: "en",
  onboarded: true,
  createdAt: "2025-11-02",
  farm: {
    name: "Ravi's Farm",
    village: "Veldurthi",
    district: "Kurnool",
    state: "Andhra Pradesh",
    pincode: "518218",
    area: 14.5,
    areaUnit: "acres",
    soilType: "Black",
    irrigationType: "Borewell",
    experienceYears: 12,
    preferredMarket: "Kurnool APMC",
    cropsGrown: ["Paddy", "Cotton", "Tomato", "Maize", "Onion", "Groundnut"],
  },
};

/* --------------------------------- Toasts --------------------------------- */

export interface Toast {
  id: number;
  message: string;
  type: "success" | "error" | "info" | "warning";
}

/* --------------------------------- Context -------------------------------- */

interface AppContextValue {
  hydrated: boolean;
  /* i18n */
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string) => string;
  /* auth */
  user: User | null;
  login: (identifier: string) => Promise<void>;
  demoLogin: () => Promise<void>;
  signup: (data: {
    name: string;
    role: Role;
    email?: string;
    phone?: string;
    language: Lang;
  }) => Promise<void>;
  completeOnboarding: (farm: Farm) => void;
  updateUser: (patch: Partial<User>) => void;
  logout: () => void;
  /* crops */
  crops: Crop[];
  addCrop: (crop: Omit<Crop, "id" | "createdAt">) => void;
  updateCrop: (id: string, patch: Partial<Crop>) => void;
  deleteCrop: (id: string) => void;
  /* marketplace */
  listings: Listing[];
  addListing: (listing: Omit<Listing, "id" | "createdAt" | "farmer" | "verified">) => void;
  savedListingIds: string[];
  toggleSaveListing: (id: string) => void;
  /* notifications */
  notifications: AppNotification[];
  markAllNotificationsRead: () => void;
  markNotificationRead: (id: string) => void;
  /* bookings & shipments */
  consultations: Consultation[];
  addConsultation: (c: Omit<Consultation, "id" | "status" | "expertName"> & { expertName: string }) => void;
  rentals: EquipmentRental[];
  addRental: (r: Omit<EquipmentRental, "id" | "status">) => void;
  shipments: Shipment[];
  addShipment: (s: Omit<Shipment, "id" | "status" | "updates">) => void;
  /* toasts */
  toasts: Toast[];
  toast: (message: string, type?: Toast["type"]) => void;
  dismissToast: (id: number) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const LS = {
  user: "agriconnect.user",
  lang: "agriconnect.lang",
  crops: "agriconnect.crops",
  listings: "agriconnect.listings",
  saved: "agriconnect.savedListings",
  notifications: "agriconnect.notifications",
  consultations: "agriconnect.consultations",
  rentals: "agriconnect.rentals",
  shipments: "agriconnect.shipments",
};

function readLS<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeLS(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full / private mode — ignore in demo */
  }
}

let toastSeq = 1;

export function AppProvider({ children }: { children: ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [lang, setLangState] = useState<Lang>("en");
  const [user, setUser] = useState<User | null>(null);
  const [crops, setCrops] = useState<Crop[]>(seedCrops);
  const [listings, setListings] = useState<Listing[]>(seedListings);
  const [savedListingIds, setSavedListingIds] = useState<string[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>(seedNotifications);
  const [consultations, setConsultations] = useState<Consultation[]>(seedConsultations);
  const [rentals, setRentals] = useState<EquipmentRental[]>([]);
  const [shipments, setShipments] = useState<Shipment[]>(seedShipments);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const firstRun = useRef(true);

  /* ------------------------------ hydration ------------------------------ */
  useEffect(() => {
    const storedLang = readLS<Lang | null>(LS.lang, null);
    if (storedLang) setLangState(storedLang);
    setUser(readLS<User | null>(LS.user, null));
    setCrops(readLS<Crop[] | null>(LS.crops, null) ?? seedCrops);
    setListings(readLS<Listing[] | null>(LS.listings, null) ?? seedListings);
    setSavedListingIds(readLS<string[]>(LS.saved, []));
    setNotifications(readLS<AppNotification[] | null>(LS.notifications, null) ?? seedNotifications);
    setConsultations(readLS<Consultation[] | null>(LS.consultations, null) ?? seedConsultations);
    setRentals(readLS<EquipmentRental[]>(LS.rentals, []));
    setShipments(readLS<Shipment[] | null>(LS.shipments, null) ?? seedShipments);
    setHydrated(true);
  }, []);

  /* ------------------------------ persistence ---------------------------- */
  useEffect(() => {
    if (firstRun.current) {
      firstRun.current = false;
      return;
    }
    if (!hydrated) return;
    writeLS(LS.lang, lang);
    writeLS(LS.user, user);
    writeLS(LS.crops, crops);
    writeLS(LS.listings, listings);
    writeLS(LS.saved, savedListingIds);
    writeLS(LS.notifications, notifications);
    writeLS(LS.consultations, consultations);
    writeLS(LS.rentals, rentals);
    writeLS(LS.shipments, shipments);
  }, [hydrated, lang, user, crops, listings, savedListingIds, notifications, consultations, rentals, shipments]);

  /* -------------------------------- toasts ------------------------------- */
  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toast = useCallback(
    (message: string, type: Toast["type"] = "success") => {
      const id = toastSeq++;
      setToasts((prev) => [...prev.slice(-3), { id, message, type }]);
      window.setTimeout(() => dismissToast(id), 4500);
    },
    [dismissToast]
  );

  /* --------------------------------- i18n -------------------------------- */
  const setLang = useCallback((l: Lang) => setLangState(l), []);
  const t = useCallback(
    (key: string) => translations[lang]?.[key] ?? translations.en[key] ?? key,
    [lang]
  );

  /* --------------------------------- auth -------------------------------- */
  const login = useCallback(
    async (identifier: string) => {
      // Demo auth — replace with POST /api/auth/login when backend is live.
      await new Promise((r) => setTimeout(r, 900));
      const base = DEMO_USER;
      const isPhone = /^[0-9+\-\s]{8,16}$/.test(identifier.trim());
      setUser({
        ...base,
        email: isPhone ? base.email : identifier.trim(),
        phone: isPhone ? identifier.trim() : base.phone,
      });
    },
    []
  );

  const demoLogin = useCallback(async () => {
    try {
      await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ demo: true }),
      });
    } catch {
      /* offline-safe: demo login still succeeds locally */
    }
    setUser(DEMO_USER);
  }, []);

  const signup = useCallback(
    async (data: { name: string; role: Role; email?: string; phone?: string; language: Lang }) => {
      await new Promise((r) => setTimeout(r, 900));
      setUser({
        id: `u-${Date.now()}`,
        onboarded: false,
        createdAt: new Date().toISOString().slice(0, 10),
        ...data,
      });
      setLangState(data.language);
    },
    []
  );

  const completeOnboarding = useCallback((farm: Farm) => {
    setUser((u) => (u ? { ...u, farm, onboarded: true } : u));
  }, []);

  const updateUser = useCallback((patch: Partial<User>) => {
    setUser((u) => (u ? { ...u, ...patch } : u));
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    writeLS(LS.user, null);
  }, []);

  /* --------------------------------- crops ------------------------------- */
  const addCrop = useCallback(
    (crop: Omit<Crop, "id" | "createdAt">) => {
      const full: Crop = {
        ...crop,
        id: `c-${Date.now()}`,
        createdAt: new Date().toISOString().slice(0, 10),
      };
      setCrops((prev) => [...prev, full]);
    },
    []
  );

  const updateCrop = useCallback((id: string, patch: Partial<Crop>) => {
    setCrops((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)));
  }, []);

  const deleteCrop = useCallback((id: string) => {
    setCrops((prev) => prev.filter((c) => c.id !== id));
  }, []);

  /* ------------------------------ marketplace ---------------------------- */
  const addListing = useCallback(
    (listing: Omit<Listing, "id" | "createdAt" | "farmer" | "verified">) => {
      const full: Listing = {
        ...listing,
        id: `l-${Date.now()}`,
        farmer: user?.name ?? "You",
        verified: true,
        createdAt: new Date().toISOString().slice(0, 10),
      };
      setListings((prev) => [full, ...prev]);
    },
    [user]
  );

  const toggleSaveListing = useCallback((id: string) => {
    setSavedListingIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }, []);

  /* ----------------------------- notifications --------------------------- */
  const markAllNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const markNotificationRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  }, []);

  /* --------------------------- bookings/shipments ------------------------ */
  const addConsultation = useCallback(
    (c: Omit<Consultation, "id" | "status" | "expertName"> & { expertName: string }) => {
      setConsultations((prev) => [
        { ...c, id: `cn-${Date.now()}`, status: "Upcoming" as const },
        ...prev,
      ]);
    },
    []
  );

  const addRental = useCallback((r: Omit<EquipmentRental, "id" | "status">) => {
    setRentals((prev) => [{ ...r, id: `r-${Date.now()}`, status: "Requested" as const }, ...prev]);
  }, []);

  const addShipment = useCallback((s: Omit<Shipment, "id" | "status" | "updates">) => {
    setShipments((prev) => [
      {
        ...s,
        id: `SHP-${1032 + prev.length}`,
        status: "Request created" as const,
        updates: [{ label: "Request created" as const, done: true, time: "Just now" }],
      },
      ...prev,
    ]);
  }, []);

  const value = useMemo<AppContextValue>(
    () => ({
      hydrated,
      lang,
      setLang,
      t,
      user,
      login,
      demoLogin,
      signup,
      completeOnboarding,
      updateUser,
      logout,
      crops,
      addCrop,
      updateCrop,
      deleteCrop,
      listings,
      addListing,
      savedListingIds,
      toggleSaveListing,
      notifications,
      markAllNotificationsRead,
      markNotificationRead,
      consultations,
      addConsultation,
      rentals,
      addRental,
      shipments,
      addShipment,
      toasts,
      toast,
      dismissToast,
    }),
    [
      hydrated, lang, setLang, t, user, login, demoLogin, signup, completeOnboarding,
      updateUser, logout, crops, addCrop, updateCrop, deleteCrop, listings, addListing,
      savedListingIds, toggleSaveListing, notifications, markAllNotificationsRead,
      markNotificationRead, consultations, addConsultation, rentals, addRental,
      shipments, addShipment, toasts, toast, dismissToast,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within <AppProvider>");
  return ctx;
}
