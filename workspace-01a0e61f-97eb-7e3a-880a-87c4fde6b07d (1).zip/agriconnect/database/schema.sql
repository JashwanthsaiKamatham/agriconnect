-- ============================================================================
-- AgriConnect — database-ready schema (PostgreSQL)
-- ----------------------------------------------------------------------------
-- This schema mirrors the TypeScript models in `lib/types.ts` 1:1 so the mock
-- service layer (`lib/services`) can be swapped for real queries without any
-- component changes. Works with Supabase / Neon / RDS Postgres on Vercel.
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto"; -- gen_random_uuid()

-- ------------------------------- enum types ---------------------------------
CREATE TYPE user_role AS ENUM ('farmer', 'buyer', 'expert', 'supplier', 'logistics', 'admin');
CREATE TYPE growth_stage AS ENUM ('planned', 'seedling', 'vegetative', 'flowering', 'fruiting', 'ready_for_harvest', 'harvested');
CREATE TYPE quality_grade AS ENUM ('A', 'B');
CREATE TYPE consultation_mode AS ENUM ('video_call', 'phone_call', 'farm_visit');
CREATE TYPE consultation_status AS ENUM ('upcoming', 'completed', 'cancelled');
CREATE TYPE rental_status AS ENUM ('requested', 'confirmed', 'completed', 'cancelled');
CREATE TYPE shipment_status AS ENUM ('request_created', 'provider_assigned', 'pickup_scheduled', 'in_transit', 'delivered');
CREATE TYPE benefit_type AS ENUM ('income_support', 'insurance', 'credit', 'subsidy', 'market_access', 'training');

-- --------------------------------- users ------------------------------------
CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT NOT NULL,
  role          user_role NOT NULL DEFAULT 'farmer',
  phone         TEXT UNIQUE,
  email         TEXT UNIQUE,
  password_hash TEXT,                          -- set when real auth is wired up
  language      TEXT NOT NULL DEFAULT 'en',    -- en | te | kn | hi
  onboarded     BOOLEAN NOT NULL DEFAULT FALSE,
  photo_url     TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------- farms -----------------------------------
CREATE TABLE farms (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name             TEXT,
  village          TEXT NOT NULL,
  district         TEXT NOT NULL,
  state            TEXT NOT NULL,
  pincode          TEXT NOT NULL,
  latitude         NUMERIC(9, 6),
  longitude        NUMERIC(9, 6),
  area             NUMERIC(8, 2) NOT NULL,
  area_unit        TEXT NOT NULL DEFAULT 'acres',   -- acres | hectares
  soil_type        TEXT,
  irrigation_type  TEXT,
  experience_years INTEGER,
  preferred_market TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_farms_user ON farms(user_id);

-- ---------------------------------- crops -----------------------------------
CREATE TABLE crops (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farm_id          UUID NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
  name             TEXT NOT NULL,
  variety          TEXT,
  image_url        TEXT,
  area             NUMERIC(8, 2) NOT NULL,
  area_unit        TEXT NOT NULL DEFAULT 'acres',
  planting_date    DATE,
  harvest_date     DATE,
  stage            growth_stage NOT NULL DEFAULT 'planned',
  irrigation_type  TEXT,
  soil_type        TEXT,
  estimated_yield  NUMERIC(10, 2),               -- tonnes
  notes            TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_crops_farm ON crops(farm_id);
CREATE INDEX idx_crops_stage ON crops(stage);

-- ------------------------------ market prices -------------------------------
CREATE TABLE market_prices (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  crop        TEXT NOT NULL,
  variety     TEXT,
  market      TEXT NOT NULL,
  district    TEXT NOT NULL,
  state       TEXT NOT NULL,
  price_date  DATE NOT NULL,
  min_price   NUMERIC(12, 2) NOT NULL,           -- ₹ / quintal
  max_price   NUMERIC(12, 2) NOT NULL,
  modal_price NUMERIC(12, 2) NOT NULL,
  source      TEXT NOT NULL DEFAULT 'demo',      -- swap to 'agmarknet' when live
  fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (crop, market, price_date)
);
CREATE INDEX idx_prices_crop_date ON market_prices(crop, price_date DESC);

-- ---------------------------- marketplace listings --------------------------
CREATE TABLE marketplace_listings (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  crop          TEXT NOT NULL,
  variety       TEXT,
  image_url     TEXT,
  quantity      NUMERIC(12, 2) NOT NULL,
  unit          TEXT NOT NULL DEFAULT 'quintals',
  price         NUMERIC(12, 2) NOT NULL,         -- ₹ / quintal
  grade         quality_grade NOT NULL DEFAULT 'A',
  is_organic    BOOLEAN NOT NULL DEFAULT FALSE,
  harvest_date  DATE,
  location      TEXT NOT NULL,
  district      TEXT NOT NULL,
  state         TEXT NOT NULL,
  description   TEXT,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_listings_crop ON marketplace_listings(crop);
CREATE INDEX idx_listings_district ON marketplace_listings(district);

CREATE TABLE saved_listings (
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  listing_id  UUID NOT NULL REFERENCES marketplace_listings(id) ON DELETE CASCADE,
  saved_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, listing_id)
);

-- -------------------------------- equipment ---------------------------------
CREATE TABLE equipment (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name          TEXT NOT NULL,
  category      TEXT NOT NULL,                   -- tractor | rotavator | seed_drill | sprayer | harvester
  image_url     TEXT,
  price_per_day NUMERIC(10, 2) NOT NULL,
  location      TEXT NOT NULL,
  district      TEXT NOT NULL,
  state         TEXT NOT NULL,
  is_available  BOOLEAN NOT NULL DEFAULT TRUE,
  delivery      BOOLEAN NOT NULL DEFAULT FALSE,
  specs         TEXT,
  rating        NUMERIC(3, 2) DEFAULT 0
);

CREATE TABLE equipment_rentals (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  equipment_id  UUID NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
  renter_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  start_date    DATE NOT NULL,
  end_date      DATE NOT NULL,
  total_estimate NUMERIC(12, 2) NOT NULL,
  status        rental_status NOT NULL DEFAULT 'requested',
  message       TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- --------------------------------- experts ----------------------------------
CREATE TABLE experts (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        UUID REFERENCES users(id) ON DELETE SET NULL,
  name           TEXT NOT NULL,
  specialization TEXT NOT NULL,
  qualification  TEXT,
  experience     INTEGER NOT NULL DEFAULT 0,
  languages      TEXT[] NOT NULL DEFAULT '{}',
  rating         NUMERIC(3, 2) NOT NULL DEFAULT 0,
  reviews        INTEGER NOT NULL DEFAULT 0,
  fee            NUMERIC(10, 2) NOT NULL,
  is_available   BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE consultations (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  expert_id  UUID NOT NULL REFERENCES experts(id) ON DELETE CASCADE,
  farmer_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  crop       TEXT NOT NULL,
  topic      TEXT NOT NULL,
  image_url  TEXT,
  date       DATE NOT NULL,
  time       TEXT NOT NULL,
  mode       consultation_mode NOT NULL DEFAULT 'video_call',
  status     consultation_status NOT NULL DEFAULT 'upcoming',
  fee        NUMERIC(10, 2) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_consultations_farmer ON consultations(farmer_id);

-- ---------------------------- government schemes ----------------------------
CREATE TABLE government_schemes (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  description TEXT NOT NULL,
  department  TEXT NOT NULL,
  state       TEXT NOT NULL DEFAULT 'All India',
  eligibility TEXT NOT NULL,
  benefits    TEXT[] NOT NULL DEFAULT '{}',
  documents   TEXT[] NOT NULL DEFAULT '{}',
  deadline    TEXT,
  crops       TEXT[] NOT NULL DEFAULT '{}',
  categories  TEXT[] NOT NULL DEFAULT '{}',
  benefit_type benefit_type NOT NULL,
  official_url TEXT
);

CREATE TABLE scheme_bookmarks (
  user_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  scheme_id UUID NOT NULL REFERENCES government_schemes(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, scheme_id)
);

-- -------------------------------- logistics ---------------------------------
CREATE TABLE logistics_providers (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID REFERENCES users(id) ON DELETE SET NULL,
  name          TEXT NOT NULL,
  vehicle       TEXT NOT NULL,
  capacity      TEXT NOT NULL,
  service_area  TEXT[] NOT NULL DEFAULT '{}',
  price_estimate TEXT NOT NULL,
  is_available  BOOLEAN NOT NULL DEFAULT TRUE,
  rating        NUMERIC(3, 2) DEFAULT 0,
  trips         INTEGER DEFAULT 0
);

CREATE TABLE shipments (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider_id UUID REFERENCES logistics_providers(id) ON DELETE SET NULL,
  goods      TEXT NOT NULL,
  quantity   TEXT NOT NULL,
  pickup     TEXT NOT NULL,
  drop_location TEXT NOT NULL,
  vehicle    TEXT,
  ship_date  DATE NOT NULL,
  eta        TEXT,
  status     shipment_status NOT NULL DEFAULT 'request_created',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------ notifications -------------------------------
CREATE TABLE notifications (
  id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type    TEXT NOT NULL,                         -- weather | price | market | scheme | expert
  title   TEXT NOT NULL,
  body    TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user ON notifications(user_id, created_at DESC);
